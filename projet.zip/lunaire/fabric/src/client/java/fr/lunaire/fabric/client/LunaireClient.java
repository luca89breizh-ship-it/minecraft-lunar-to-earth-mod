package fr.lunaire.fabric.client;

import fr.lunaire.Lunaire;
import fr.lunaire.fabric.ModAttachments;
import fr.lunaire.fabric.Moon;
import fr.lunaire.fabric.content.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.ModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.player.LocalPlayer;
import fr.lunaire.fabric.content.ModMobs;
import net.minecraft.resources.Identifier;

public final class LunaireClient implements ClientModInitializer {
    public static final ModelLayerLocation SELENITE_LAYER = new ModelLayerLocation(Lunaire.id("selenite"), "main");
    public static final ModelLayerLocation GOLEM_LAYER = new ModelLayerLocation(Lunaire.id("dust_golem"), "main");

    @Override
    public void onInitializeClient() {
        ModelLayerRegistry.registerModelLayer(SELENITE_LAYER,
                () -> LayerDefinition.create(HumanoidModel.createMesh(CubeDeformation.NONE, 0.0F), 64, 64));
        ModelLayerRegistry.registerModelLayer(GOLEM_LAYER,
                () -> LayerDefinition.create(HumanoidModel.createMesh(new CubeDeformation(0.45F), 0.0F), 64, 64));
        EntityRendererRegistry.register(ModEntities.SELENITE, SeleniteRenderer::new);
        EntityRendererRegistry.register(ModEntities.DUST_GOLEM, DustGolemRenderer::new);
        registerMobs();

        HudElementRegistry.attachElementAfter(VanillaHudElements.INFO_BAR_FOREGROUND,
                Lunaire.id("oxygen_gauge"), LunaireClient::renderOxygen);

        // Tremblement d'écran pendant le décollage
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            LocalPlayer p = mc.player;
            if (p == null) {
                return;
            }
            int shake = p.getAttachedOrCreate(ModAttachments.SHAKE);
            if (shake > 0) {
                float amp = 0.4F + shake * 0.15F;
                p.setYRot(p.getYRot() + (p.getRandom().nextFloat() - 0.5F) * amp);
                p.setXRot(p.getXRot() + (p.getRandom().nextFloat() - 0.5F) * amp);
            }
        });
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static void registerMobs() {
        java.util.Map<String, ModelLayerLocation> layers = new java.util.HashMap<>();
        for (var en : ModMobs.SHAPES.entrySet()) {
            ModelLayerLocation loc = new ModelLayerLocation(Lunaire.id("mob_" + en.getKey()), "main");
            layers.put(en.getKey(), loc);
            var sh = en.getValue().getAsJsonObject();
            ModelLayerRegistry.registerModelLayer(loc, () -> buildShape(sh));
        }
        for (var c : ModMobs.CFG.values()) {
            var type = ModMobs.TYPES.get(c.name());
            var layer = layers.get(c.shape());
            String name = c.name();
            EntityRendererRegistry.register((net.minecraft.world.entity.EntityType) type,
                    (net.minecraft.client.renderer.entity.EntityRendererProvider) ctx -> new LunarMobRenderer(ctx, name, layer));
        }
    }

    private static float f(com.google.gson.JsonArray a, int i) {
        return a.get(i).getAsFloat();
    }

    private static net.minecraft.client.model.geom.PartPose pose(com.google.gson.JsonObject p) {
        var pos = p.getAsJsonArray("pos");
        if (p.has("rot")) {
            var r = p.getAsJsonArray("rot");
            return net.minecraft.client.model.geom.PartPose.offsetAndRotation(f(pos, 0), f(pos, 1), f(pos, 2), f(r, 0), f(r, 1), f(r, 2));
        }
        return net.minecraft.client.model.geom.PartPose.offset(f(pos, 0), f(pos, 1), f(pos, 2));
    }

    private static net.minecraft.client.model.geom.builders.CubeListBuilder cube(com.google.gson.JsonObject p, boolean mirror, CubeDeformation def) {
        var b = p.getAsJsonArray("box");
        var t = p.getAsJsonArray("tex");
        var cb = net.minecraft.client.model.geom.builders.CubeListBuilder.create();
        if (mirror) {
            cb = cb.mirror();
        }
        return cb.texOffs(t.get(0).getAsInt(), t.get(1).getAsInt()).addBox(f(b, 0), f(b, 1), f(b, 2), f(b, 3), f(b, 4), f(b, 5), def);
    }

    private static LayerDefinition buildShape(com.google.gson.JsonObject sh) {
        net.minecraft.client.model.geom.builders.MeshDefinition md = HumanoidModel.createMesh(CubeDeformation.NONE, 0.0F);
        var root = md.getRoot();
        var parts = sh.getAsJsonObject("parts");
        net.minecraft.client.model.geom.builders.PartDefinition headDef = null;
        for (String key : new String[]{"head", "body", "right_arm", "left_arm", "right_leg", "left_leg"}) {
            var p = parts.getAsJsonObject(key);
            var def = root.addOrReplaceChild(key, cube(p, key.startsWith("left"), CubeDeformation.NONE), pose(p));
            if (key.equals("head")) {
                headDef = def;
                var ht = sh.getAsJsonArray("hat_tex");
                var hp = new com.google.gson.JsonObject();
                hp.add("box", p.getAsJsonArray("box"));
                hp.add("tex", ht);
                def.addOrReplaceChild("hat", cube(hp, false, new CubeDeformation(0.5F)), net.minecraft.client.model.geom.PartPose.ZERO);
            }
        }
        if (sh.has("extras")) {
            for (var el : sh.getAsJsonArray("extras")) {
                var e = el.getAsJsonObject();
                var parent = e.get("parent").getAsString().equals("head") ? headDef : root;
                parent.addOrReplaceChild(e.get("key").getAsString(), cube(e, false, CubeDeformation.NONE), pose(e));
            }
        }
        int ts = sh.get("tex_size").getAsInt();
        return LayerDefinition.create(md, ts, ts);
    }

    private static int argb(int a, int r, int g, int b) {
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private static void renderOxygen(GuiGraphicsExtractor g, DeltaTracker tracker) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || !Moon.isMoon(p)) {
            return;
        }
        int o2 = p.getAttachedOrCreate(ModAttachments.OXYGEN);
        float ratio = Math.max(0F, Math.min(1F, o2 / (float) ModAttachments.O2_MAX));
        int w = 81, h = 7;
        int x = g.guiWidth() / 2 + 10;
        int y = g.guiHeight() - 52;
        g.fill(x - 1, y - 1, x + w + 1, y + h + 1, argb(255, 20, 20, 30));
        int color = ratio > 0.25F ? argb(255, 80, 200, 255) : argb(255, 255, 70, 70);
        g.fill(x, y, x + (int) (w * ratio), y + h, color);
        g.text(mc.font, "O2 " + (int) (ratio * 100) + "%", x, y - 10, argb(255, 255, 255, 255));
    }
}
