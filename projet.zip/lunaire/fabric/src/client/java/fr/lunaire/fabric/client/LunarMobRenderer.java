package fr.lunaire.fabric.client;

import fr.lunaire.Lunaire;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.state.HumanoidRenderState;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Mob;

/** Rendu générique des créatures de Lunaire (modèle humanoïde recomposé par forme, texture par créature). */
public class LunarMobRenderer extends MobRenderer<Mob, HumanoidRenderState, LunarModel> {
    private final Identifier texture;

    public LunarMobRenderer(EntityRendererProvider.Context context, String name, ModelLayerLocation layer) {
        super(context, new LunarModel(context.bakeLayer(layer)), 0.5F);
        this.texture = Lunaire.id("textures/entity/" + name + ".png");
    }

    @Override
    public Identifier getTextureLocation(HumanoidRenderState state) {
        return texture;
    }

    @Override
    public HumanoidRenderState createRenderState() {
        return new HumanoidRenderState();
    }
}
