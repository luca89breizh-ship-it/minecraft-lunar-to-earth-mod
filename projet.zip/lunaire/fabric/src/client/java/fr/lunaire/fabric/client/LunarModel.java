package fr.lunaire.fabric.client;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.entity.state.HumanoidRenderState;

/** Modèle des créatures : pose initiale conservée (corps couché, pattes décalées) et marche simple bras/jambes. */
public class LunarModel extends HumanoidModel<HumanoidRenderState> {
    public LunarModel(ModelPart root) {
        super(root);
    }

    @Override
    public void setupAnim(HumanoidRenderState state) {
        super.setupAnim(state);
        head.resetPose();
        body.resetPose();
        rightArm.resetPose();
        leftArm.resetPose();
        rightLeg.resetPose();
        leftLeg.resetPose();
        float pos = state.walkAnimationPos;
        float speed = Math.min(1.0F, state.walkAnimationSpeed);
        head.yRot = (float) Math.toRadians(state.yRot);
        head.xRot = (float) Math.toRadians(state.xRot);
        rightLeg.xRot = (float) Math.cos(pos * 0.6662F) * 1.4F * speed;
        leftLeg.xRot = (float) Math.cos(pos * 0.6662F + Math.PI) * 1.4F * speed;
        rightArm.xRot = (float) Math.cos(pos * 0.6662F + Math.PI) * 1.2F * speed;
        leftArm.xRot = (float) Math.cos(pos * 0.6662F) * 1.2F * speed;
    }
}
