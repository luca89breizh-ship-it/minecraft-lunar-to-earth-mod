package fr.lunaire.fabric.client;

import fr.lunaire.fabric.Moon;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import javax.imageio.ImageIO;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Dessine la Terre et les planètes dans le ciel de la Lune (projection selon la direction du regard). */
public final class SkyBodies {
    private SkyBodies() {}

    private record Body(String file, double azimuth, double elevation, int[][] px, int w, int h) {}

    private static Body[] bodies;

    private static Body load(String name, double az, double el) {
        try (InputStream in = SkyBodies.class.getResourceAsStream("/lunaire_sky/" + name + ".png")) {
            if (in == null) {
                return null;
            }
            BufferedImage img = ImageIO.read(in);
            int[][] px = new int[img.getHeight()][img.getWidth()];
            for (int y = 0; y < img.getHeight(); y++) {
                for (int x = 0; x < img.getWidth(); x++) {
                    px[y][x] = img.getRGB(x, y);
                }
            }
            return new Body(name, az, el, px, img.getWidth(), img.getHeight());
        } catch (Exception e) {
            return null;
        }
    }

    private static void init() {
        bodies = new Body[]{
                load("earth", 200, 38),
                load("jupiter", 55, 52),
                load("saturn", 305, 30),
                load("mars", 120, 24),
                load("venus", 15, 14),
                load("mercury", 85, 7),
                load("neptune", 255, 62),
        };
    }

    public static void render(GuiGraphicsExtractor g, DeltaTracker tracker) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || !Moon.isMoon(p)) {
            return;
        }
        if (bodies == null) {
            init();
        }
        double yaw = Math.toRadians(p.getYRot());
        double pitch = Math.toRadians(p.getXRot());
        Vec3 f = new Vec3(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch));
        Vec3 right = new Vec3(-Math.cos(yaw), 0, -Math.sin(yaw));
        Vec3 up = right.cross(f);
        double fov = Math.toRadians(mc.options.fov().get());
        double k = (g.guiHeight() / 2.0) / Math.tan(fov / 2.0);
        Vec3 eye = p.getEyePosition();
        for (Body b : bodies) {
            if (b == null) {
                continue;
            }
            double a = Math.toRadians(b.azimuth());
            double e = Math.toRadians(b.elevation());
            Vec3 d = new Vec3(-Math.sin(a) * Math.cos(e), Math.sin(e), Math.cos(a) * Math.cos(e));
            double depth = d.dot(f);
            if (depth <= 0.05) {
                continue;
            }
            double sx = g.guiWidth() / 2.0 + d.dot(right) / depth * k;
            double sy = g.guiHeight() / 2.0 - d.dot(up) / depth * k;
            if (sx < -60 || sy < -60 || sx > g.guiWidth() + 60 || sy > g.guiHeight() + 60) {
                continue;
            }
            // caché par le relief ou un plafond ?
            var hit = mc.level.clip(new ClipContext(eye, eye.add(d.scale(96.0)), ClipContext.Block.COLLIDER,
                    ClipContext.Fluid.NONE, p));
            if (hit.getType() != HitResult.Type.MISS) {
                continue;
            }
            int x0 = (int) Math.round(sx) - b.w() / 2;
            int y0 = (int) Math.round(sy) - b.h() / 2;
            for (int y = 0; y < b.h(); y++) {
                for (int x = 0; x < b.w(); x++) {
                    int c = b.px()[y][x];
                    if ((c >>> 24) != 0) {
                        g.fill(x0 + x, y0 + y, x0 + x + 1, y0 + y + 1, c);
                    }
                }
            }
        }
    }
}
