package fr.lunaire.fabric;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import fr.lunaire.fabric.content.ModItems;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/** Clic droit sur un objet : recharge d'O₂, soins, nourriture, scanner, propulseur… (décrit dans le JSON). */
public final class ItemUse {
    private ItemUse() {}

    public static void init() {
        UseItemCallback.EVENT.register((player, level, hand) -> {
            ItemStack stack = player.getItemInHand(hand);
            JsonObject use = ModItems.USE.get(stack.getItem());
            if (use == null) {
                return InteractionResult.PASS;
            }
            if (level.isClientSide() || !(player instanceof ServerPlayer sp)) {
                return InteractionResult.SUCCESS;
            }
            ServerLevel sl = (ServerLevel) level;
            if (use.has("scan")) {
                int o2 = sp.getAttachedOrCreate(ModAttachments.OXYGEN);
                boolean hab = Habitat.isPressurized(sl, sp.blockPosition().above());
                sp.sendSystemMessage(Component.literal("O₂ : " + (o2 * 100 / ModAttachments.O2_MAX) + " %  |  "
                        + (hab ? "pièce pressurisée" : "vide") + "  |  " + (Machines.isDay(sl) ? "jour" : "nuit")));
                return InteractionResult.SUCCESS;
            }
            if (use.has("pos")) {
                var b = sp.blockPosition();
                sp.sendSystemMessage(Component.literal("Position : " + b.getX() + " " + b.getY() + " " + b.getZ()
                       ));
                return InteractionResult.SUCCESS;
            }
            if (use.has("o2")) {
                int o2 = sp.getAttachedOrCreate(ModAttachments.OXYGEN);
                sp.setAttached(ModAttachments.OXYGEN, Math.min(ModAttachments.O2_MAX, o2 + use.get("o2").getAsInt()));
            }
            if (use.has("warm")) {
                sp.setAttached(ModAttachments.WARM, use.get("warm").getAsInt());
            }
            if (use.has("cool")) {
                sp.setAttached(ModAttachments.COOL, use.get("cool").getAsInt());
            }
            if (use.has("cmds")) {
                var server = sl.getServer();
                var src = server.createCommandSourceStack().withSuppressedOutput();
                for (JsonElement c : use.getAsJsonArray("cmds")) {
                    server.getCommands().performPrefixedCommand(src, c.getAsString().replace("%p", sp.getStringUUID()));
                }
            }
            if (use.has("msg")) {
                sp.sendSystemMessage(Component.literal(use.get("msg").getAsString()), true);
            }
            boolean keep = use.has("keep") && use.get("keep").getAsBoolean();
            if (!keep) {
                stack.shrink(1);
                if (use.has("returns")) {
                    String name = use.get("returns").getAsString();
                    Item back = ModItems.get(name.substring(name.indexOf(':') + 1));
                    sp.getInventory().add(new ItemStack(back));
                }
            }
            return InteractionResult.SUCCESS;
        });
    }
}
