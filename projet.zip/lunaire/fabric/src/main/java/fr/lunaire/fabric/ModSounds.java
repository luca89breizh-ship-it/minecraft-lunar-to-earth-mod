package fr.lunaire.fabric;

import fr.lunaire.Lunaire;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.sounds.SoundEvent;

/** Musique de la Lune (référencée par le type de dimension). */
public final class ModSounds {
    private ModSounds() {}

    public static final SoundEvent MUSIC_MOON = Registry.register(BuiltInRegistries.SOUND_EVENT,
            Lunaire.id("music.moon"), SoundEvent.createVariableRangeEvent(Lunaire.id("music.moon")));

    public static void init() {}
}
