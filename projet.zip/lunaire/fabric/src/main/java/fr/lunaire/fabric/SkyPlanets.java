package fr.lunaire.fabric;

import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/**
 * Planètes dans le ciel lunaire : de vraies entités « item_display » (billboard, pleine lumière) placées sur la sphère céleste
 * autour du joueur. Elles sont cachées par le relief et se déplacent avec le temps.
 */
public final class SkyPlanets {
    private SkyPlanets() {}

    private record P(String name, double az, double el, double rate, double amp, float size) {}

    private static final P[] LIST = {
            new P("earth", 205, 40, 0.0, 0.0, 38),
            new P("jupiter", 40, 38, 0.0140, 24, 30),
            new P("saturn", 300, 34, 0.0110, 22, 38),
            new P("mars", 120, 36, 0.0170, 20, 18),
            new P("venus", 20, 32, 0.0210, 16, 17),
            new P("mercury", 80, 28, 0.0250, 14, 12),
            new P("neptune", 250, 46, 0.0095, 18, 17),
    };
    private static final double DIST = 64.0;
    private static final Set<UUID> ACTIVE = new HashSet<>();

    private static UUID uid(ServerPlayer sp, int i) {
        UUID u = sp.getUUID();
        return new UUID(u.getMostSignificantBits() ^ 0x5A17E0000L, u.getLeastSignificantBits() + 101 + i);
    }

    public static void tick(MinecraftServer server, ServerPlayer sp, int t) {
        ServerLevel level = (ServerLevel) sp.level();
        ACTIVE.add(sp.getUUID());
        double time = level.getGameTime();
        Vec3 eye = sp.getEyePosition();
        for (int i = 0; i < LIST.length; i++) {
            P p = LIST[i];
            UUID id = uid(sp, i);
            Entity e = level.getEntity(id);
            if (e == null) {
                if (t % 40 == i) {
                    summon(server, sp, p, id);
                }
                continue;
            }
            double az = Math.toRadians(p.az() + time * p.rate());
            double el = Math.toRadians(p.el() + p.amp() * Math.sin(Math.toRadians(p.az() + time * p.rate())));
            Vec3 d = new Vec3(-Math.sin(az) * Math.cos(el), Math.sin(el), Math.cos(az) * Math.cos(el));
            Vec3 pos = eye.add(d.scale(DIST));
            e.setPos(pos.x, pos.y - p.size() * 0.5 * 0.0, pos.z);
        }
    }

    public static void cleanup(MinecraftServer server, ServerPlayer sp) {
        if (!ACTIVE.remove(sp.getUUID())) {
            return;
        }
        for (ServerLevel l : server.getAllLevels()) {
            for (int i = 0; i < LIST.length; i++) {
                Entity e = l.getEntity(uid(sp, i));
                if (e != null) {
                    e.discard();
                }
            }
        }
    }

    private static void summon(MinecraftServer server, ServerPlayer sp, P p, UUID id) {
        long m = id.getMostSignificantBits();
        long l = id.getLeastSignificantBits();
        String s = String.format(Locale.ROOT, "%.1f", p.size() * 2.0F);
        String uu = "[I;" + (int) (m >> 32) + "," + (int) m + "," + (int) (l >> 32) + "," + (int) l + "]";
        String nbt = "{UUID:" + uu + ",item:{id:\"minecraft:paper\",count:1,components:{\"minecraft:item_model\":\"lunaire:planet_"
                + p.name() + "\"}},item_display:\"fixed\",billboard:\"center\",brightness:{sky:15,block:15},view_range:4.0f,"
                + "teleport_duration:2,transformation:{left_translation:[0.0f,0.0f,0.0f],left_rotation:[0.0f,0.0f,0.0f,1.0f],"
                + "scale:[" + s + "f," + s + "f," + s + "f],right_rotation:[0.0f,0.0f,0.0f,1.0f]}}";
        server.getCommands().performPrefixedCommand(server.createCommandSourceStack().withSuppressedOutput(),
                "execute as " + sp.getStringUUID() + " at @s run summon minecraft:item_display ~ ~ ~ " + nbt);
    }
}
