package fr.lunaire.fabric;

import fr.lunaire.fabric.content.ModItems;
import fr.lunaire.fabric.content.ModMobs;
import fr.lunaire.fabric.entity.LunarPassive;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** Adoption : chat lunaire (poisson) et chien astro (os). Une chance sur trois à chaque offrande. */
public final class Taming {
    private Taming() {}

    public static void init() {
        UseEntityCallback.EVENT.register((player, level, hand, entity, hit) -> {
            if (!(entity instanceof LunarPassive pet)) {
                return InteractionResult.PASS;
            }
            ModMobs.Cfg cfg = ModMobs.of(pet.getType());
            if (cfg == null) {
                return InteractionResult.PASS;
            }
            boolean cat = cfg.name().equals("moon_cat");
            boolean dog = cfg.name().equals("astro_pup");
            if (!cat && !dog) {
                return InteractionResult.PASS;
            }
            ItemStack stack = player.getItemInHand(hand);
            boolean good = cat
                    ? (stack.is(ModItems.get("moon_fish")) || stack.is(ModItems.get("cooked_moon_fish"))
                            || stack.is(Items.COD) || stack.is(Items.SALMON))
                    : stack.is(Items.BONE);
            if (!good) {
                return InteractionResult.PASS;
            }
            if (level.isClientSide() || !(player instanceof ServerPlayer sp)) {
                return InteractionResult.SUCCESS;
            }
            if (pet.ownerId() != null) {
                return InteractionResult.SUCCESS;
            }
            var server = ((net.minecraft.server.level.ServerLevel) sp.level()).getServer();
            var src = server.createCommandSourceStack().withSuppressedOutput();
            if (!sp.isCreative()) {
                stack.shrink(1);
            }
            if (level.getRandom().nextInt(3) == 0) {
                pet.setOwner(sp.getUUID());
                server.getCommands().performPrefixedCommand(src, "execute as " + pet.getStringUUID()
                        + " at @s run particle minecraft:heart ~ ~1 ~ 0.4 0.4 0.4 0 8");
                sp.sendSystemMessage(Component.translatable("lunaire.tamed", pet.getName()));
            } else {
                server.getCommands().performPrefixedCommand(src, "execute as " + pet.getStringUUID()
                        + " at @s run particle minecraft:smoke ~ ~1 ~ 0.3 0.3 0.3 0.01 6");
                sp.sendSystemMessage(Component.translatable("lunaire.tame_fail", pet.getName()));
            }
            return InteractionResult.SUCCESS;
        });
    }
}
