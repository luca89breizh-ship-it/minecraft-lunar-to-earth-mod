package fr.lunaire.fabric.content;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import fr.lunaire.Lunaire;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.material.MapColor;

/** Les blocs sont décrits dans lunaire_content.json (généré par tools/gen_all.py). */
public final class ModBlocks {
    private ModBlocks() {}

    public static final List<Item> BLOCK_ITEMS = new ArrayList<>();
    public static final Map<String, Block> MAP = new HashMap<>();

    static {
        load();
    }

    public static final Block REGOLITH = get("regolith");
    public static final Block HYDRATED_REGOLITH = get("hydrated_regolith");
    public static final Block LUNAR_ICE = get("lunar_ice");
    public static final Block SOLAR_PANEL = get("solar_panel");
    public static final Block ATMOSPHERE_SEALER = get("atmosphere_sealer");
    public static final Block ELECTROLYZER = get("electrolyzer");
    public static final Block OXYGEN_COMPRESSOR = get("oxygen_compressor");
    public static final Block HYDROGEN_GENERATOR = get("hydrogen_generator");
    public static final Block RADIATOR = get("radiator");
    public static final Block LAUNCH_PLATFORM = get("launch_platform");

    public static Block get(String name) {
        Block b = MAP.get(name);
        if (b == null) {
            throw new IllegalStateException("Bloc Lunaire inconnu : " + name);
        }
        return b;
    }

    private static SoundType sound(String s) {
        return switch (s) {
            case "metal" -> SoundType.METAL;
            case "glass" -> SoundType.GLASS;
            case "gravel" -> SoundType.GRAVEL;
            default -> SoundType.STONE;
        };
    }

    private static void load() {
        JsonObject root;
        try (var in = new InputStreamReader(Lunaire.class.getResourceAsStream("/lunaire_content.json"), StandardCharsets.UTF_8)) {
            root = JsonParser.parseReader(in).getAsJsonObject();
        } catch (Exception e) {
            throw new IllegalStateException("lunaire_content.json illisible", e);
        }
        JsonArray arr = root.getAsJsonArray("blocks");
        for (JsonElement el : arr) {
            JsonObject o = el.getAsJsonObject();
            String name = o.get("name").getAsString();
            String kind = o.get("kind").getAsString();
            float hard = o.get("hard").getAsFloat();
            boolean needTool = !o.get("need").isJsonNull();
            int light = o.get("light").getAsInt();
            boolean glass = o.get("glass").getAsBoolean();
            SoundType snd = sound(o.get("sound").getAsString());
            boolean fueled = kind.equals("lit") || kind.equals("radiator");

            ResourceKey<Block> key = ResourceKey.create(Registries.BLOCK, Lunaire.id(name));
            Properties p = Properties.of().mapColor(glass ? MapColor.NONE : MapColor.STONE)
                    .strength(hard, Math.max(hard * 2.0F, 0.6F)).sound(snd).setId(key);
            if (needTool) {
                p = p.requiresCorrectToolForDrops();
            }
            if (glass) {
                p = p.noOcclusion();
            }
            if (fueled) {
                p = p.lightLevel(s -> s.getValue(FueledBlock.LIT) ? light : 0);
            } else if (light > 0) {
                p = p.lightLevel(s -> light);
            }
            Block block = fueled ? new FueledBlock(p) : new Block(p);
            Registry.register(BuiltInRegistries.BLOCK, key, block);
            ResourceKey<Item> itemKey = ResourceKey.create(Registries.ITEM, Lunaire.id(name));
            Item item = new BlockItem(block, new Item.Properties().setId(itemKey).useBlockDescriptionPrefix());
            Registry.register(BuiltInRegistries.ITEM, itemKey, item);
            BLOCK_ITEMS.add(item);
            MAP.put(name, block);
        }
    }

    public static void init() {}
}
