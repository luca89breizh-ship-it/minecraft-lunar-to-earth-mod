package fr.lunaire.fabric.content;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import fr.lunaire.Lunaire;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.item.equipment.EquipmentAsset;
import net.minecraft.world.item.equipment.EquipmentAssets;

/** Les objets sont décrits dans lunaire_content.json (généré par tools/gen_all.py). */
public final class ModItems {
    private ModItems() {}

    public static final List<Item> ALL = new ArrayList<>();
    public static final Map<String, Item> MAP = new HashMap<>();
    public static final Map<Item, String> NAMES = new HashMap<>();
    /** Comportement à l'utilisation (clic droit) : objet -> description JSON. */
    public static final Map<Item, JsonObject> USE = new HashMap<>();
    /** Pièces de combinaison : objet -> nom de la combinaison. */
    public static final Map<Item, String> SUIT = new HashMap<>();

    private static TagKey<Item> tag(String name) {
        return TagKey.create(Registries.ITEM, Lunaire.id(name));
    }

    private static JsonObject CFG;

    private static ToolMaterial toolMat(String m) {
        JsonObject o = CFG.getAsJsonObject("tool_mats").getAsJsonObject(m);
        TagKey<Block> bad = switch (o.get("tier").getAsString()) {
            case "iron" -> BlockTags.INCORRECT_FOR_IRON_TOOL;
            case "diamond" -> BlockTags.INCORRECT_FOR_DIAMOND_TOOL;
            default -> BlockTags.INCORRECT_FOR_STONE_TOOL;
        };
        return new ToolMaterial(bad, o.get("dur").getAsInt(), o.get("speed").getAsFloat(), o.get("dmg").getAsFloat(),
                o.get("ench").getAsInt(), tag(o.get("repair").getAsString()));
    }

    private static EnumMap<ArmorType, Integer> armorMap(int b, int l, int c, int h) {
        EnumMap<ArmorType, Integer> map = new EnumMap<>(ArmorType.class);
        map.put(ArmorType.BOOTS, b);
        map.put(ArmorType.LEGGINGS, l);
        map.put(ArmorType.CHESTPLATE, c);
        map.put(ArmorType.HELMET, h);
        map.put(ArmorType.BODY, c);
        return map;
    }

    private static ArmorMaterial armorMat(String suit) {
        ResourceKey<EquipmentAsset> asset = ResourceKey.create(EquipmentAssets.ROOT_ID, Lunaire.id(suit));
        JsonObject o = CFG.getAsJsonObject("armor_mats").getAsJsonObject(suit);
        var d = o.getAsJsonArray("defense");
        return new ArmorMaterial(o.get("dur").getAsInt(),
                armorMap(d.get(0).getAsInt(), d.get(1).getAsInt(), d.get(2).getAsInt(), d.get(3).getAsInt()),
                o.get("ench").getAsInt(), SoundEvents.ARMOR_EQUIP_IRON, o.get("tough").getAsFloat(), o.get("kb").getAsFloat(),
                tag(o.get("repair").getAsString()), asset);
    }

    private static ArmorType armorType(String s) {
        return switch (s) {
            case "helmet" -> ArmorType.HELMET;
            case "chestplate" -> ArmorType.CHESTPLATE;
            case "leggings" -> ArmorType.LEGGINGS;
            default -> ArmorType.BOOTS;
        };
    }

    private static final Map<String, ToolMaterial> TOOL_MATS = new HashMap<>();
    private static final Map<String, ArmorMaterial> ARMOR_MATS = new HashMap<>();

    static {
        load();
    }

    public static final Item AIR_PURIFIER = get("air_purifier");
    public static final Item OXYGEN_BOTTLE = get("oxygen_bottle");
    public static final Item OXYGEN_BOTTLE_FULL = get("oxygen_bottle_full");
    public static final Item OXYGEN_TANK = get("oxygen_tank");
    public static final Item OXYGEN_TANK_FULL = get("oxygen_tank_full");
    public static final Item HYDROGEN_CELL = get("hydrogen_cell");
    public static final Item ROCKET_BLUEPRINT = get("rocket_blueprint");
    public static final Item ROCKET_FUEL = get("rocket_fuel");
    public static final Item REENTRY_MODULE = get("reentry_module");

    public static Item get(String name) {
        Item i = MAP.get(name);
        if (i == null) {
            throw new IllegalStateException("Objet Lunaire inconnu : " + name);
        }
        return i;
    }

    private static void load() {
        JsonObject root;
        try (var in = new InputStreamReader(Lunaire.class.getResourceAsStream("/lunaire_content.json"), StandardCharsets.UTF_8)) {
            root = JsonParser.parseReader(in).getAsJsonObject();
        } catch (Exception e) {
            throw new IllegalStateException("lunaire_content.json illisible", e);
        }
        CFG = root;
        for (JsonElement el : root.getAsJsonArray("items")) {
            JsonObject o = el.getAsJsonObject();
            String name = o.get("name").getAsString();
            int stack = o.has("stack") ? o.get("stack").getAsInt() : 64;
            ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, Lunaire.id(name));
            Item.Properties p = new Item.Properties().setId(key);
            if (o.has("tool")) {
                ToolMaterial tm = TOOL_MATS.computeIfAbsent(o.get("mat").getAsString(), ModItems::toolMat);
                p = switch (o.get("tool").getAsString()) {
                    case "pickaxe" -> p.pickaxe(tm, 1.0F, -2.8F);
                    case "axe" -> p.axe(tm, 6.0F, -3.1F);
                    case "shovel" -> p.shovel(tm, 1.5F, -3.0F);
                    case "sword" -> p.sword(tm, 3.0F, -2.4F);
                    default -> p.hoe(tm, -1.0F, -1.0F);
                };
            } else if (o.has("armor")) {
                ArmorMaterial am = ARMOR_MATS.computeIfAbsent(o.get("suit").getAsString(), ModItems::armorMat);
                p = p.humanoidArmor(am, armorType(o.get("armor").getAsString()));
            } else {
                p = p.stacksTo(stack);
            }
            Item item = new Item(p);
            Registry.register(BuiltInRegistries.ITEM, key, item);
            ALL.add(item);
            MAP.put(name, item);
            NAMES.put(item, name);
            if (o.has("use")) {
                USE.put(item, o.getAsJsonObject("use"));
            }
            if (o.has("suit")) {
                SUIT.put(item, o.get("suit").getAsString());
            }
        }
    }

    public static void init() {}
}
