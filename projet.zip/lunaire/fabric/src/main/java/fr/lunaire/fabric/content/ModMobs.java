package fr.lunaire.fabric.content;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import fr.lunaire.Lunaire;
import fr.lunaire.fabric.entity.LunarHostile;
import fr.lunaire.fabric.entity.LunarPassive;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

/** Les créatures sont décrites dans lunaire_content.json (« mobs » et « mob_shapes »). */
public final class ModMobs {
    private ModMobs() {}

    public record Cfg(String name, String shape, String beh, double hp, double dmg, double speed, String effect,
                      boolean ignite, boolean sun, boolean boss, float width, float height) {}

    public static final Map<String, Cfg> CFG = new LinkedHashMap<>();
    public static final Map<String, EntityType<?>> TYPES = new LinkedHashMap<>();
    public static JsonObject SHAPES;

    static {
        JsonObject root;
        try (var in = new InputStreamReader(Lunaire.class.getResourceAsStream("/lunaire_content.json"), StandardCharsets.UTF_8)) {
            root = JsonParser.parseReader(in).getAsJsonObject();
        } catch (Exception e) {
            throw new IllegalStateException("lunaire_content.json illisible", e);
        }
        SHAPES = root.getAsJsonObject("mob_shapes");
        for (var en : root.getAsJsonObject("mobs").entrySet()) {
            JsonObject o = en.getValue().getAsJsonObject();
            String n = en.getKey();
            CFG.put(n, new Cfg(n, o.get("shape").getAsString(), o.get("beh").getAsString(), o.get("hp").getAsDouble(),
                    o.get("dmg").getAsDouble(), o.get("speed").getAsDouble(), o.get("effect").getAsString(),
                    o.get("ignite").getAsBoolean(), o.get("sun").getAsBoolean(), o.get("boss").getAsBoolean(),
                    o.get("width").getAsFloat(), o.get("height").getAsFloat()));
        }
        for (Cfg c : CFG.values()) {
            ResourceKey<EntityType<?>> key = ResourceKey.create(Registries.ENTITY_TYPE, Lunaire.id(c.name()));
            if (c.beh().equals("passive")) {
                EntityType<LunarPassive> t = EntityType.Builder.of(LunarPassive::new, MobCategory.CREATURE)
                        .sized(c.width(), c.height()).clientTrackingRange(8).build(key);
                Registry.register(BuiltInRegistries.ENTITY_TYPE, key, t);
                TYPES.put(c.name(), t);
                FabricDefaultAttributeRegistry.register(t, LunarPassive.attributes(c));
            } else {
                EntityType<LunarHostile> t = EntityType.Builder.of(LunarHostile::new, MobCategory.MONSTER)
                        .sized(c.width(), c.height()).clientTrackingRange(c.boss() ? 12 : 8).build(key);
                Registry.register(BuiltInRegistries.ENTITY_TYPE, key, t);
                TYPES.put(c.name(), t);
                FabricDefaultAttributeRegistry.register(t, LunarHostile.attributes(c));
            }
        }
    }

    public static Cfg of(EntityType<?> type) {
        return CFG.get(BuiltInRegistries.ENTITY_TYPE.getKey(type).getPath());
    }

    public static void init() {}
}
