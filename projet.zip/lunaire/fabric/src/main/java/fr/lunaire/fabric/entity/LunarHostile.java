package fr.lunaire.fabric.entity;

import fr.lunaire.fabric.content.ModMobs;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/** Créature hostile / neutre / boss de Lunaire, entièrement décrite par sa configuration JSON. */
public class LunarHostile extends Monster {
    public LunarHostile(EntityType<? extends LunarHostile> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder attributes(ModMobs.Cfg c) {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, c.hp())
                .add(Attributes.MOVEMENT_SPEED, c.speed())
                .add(Attributes.ATTACK_DAMAGE, c.dmg())
                .add(Attributes.KNOCKBACK_RESISTANCE, c.boss() ? 0.8 : 0.1)
                .add(Attributes.FOLLOW_RANGE, 28.0);
    }

    private ModMobs.Cfg cfg() {
        return ModMobs.of(getType());
    }

    @Override
    protected void registerGoals() {
        ModMobs.Cfg c = cfg();
        boolean neutral = c != null && c.beh().equals("neutral");
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.1, false));
        goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        if (!neutral) {
            targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
        }
    }

    @Override
    public void aiStep() {
        super.aiStep();
        Level l = level();
        if (l.isClientSide()) {
            return;
        }
        ModMobs.Cfg c = cfg();
        if (c == null) {
            return;
        }
        if (c.sun() && tickCount % 10 == 0 && l.getGameTime() % 24000L < 12500L && l.canSeeSky(blockPosition())) {
            setRemainingFireTicks(100);
        }
        LivingEntity t = getTarget();
        if (t != null && tickCount % 20 == 0 && distanceToSqr(t) < 9.0 && l instanceof ServerLevel sl) {
            if (c.ignite()) {
                t.setRemainingFireTicks(60);
            }
            if (!c.effect().isEmpty()) {
                var server = sl.getServer();
                server.getCommands().performPrefixedCommand(server.createCommandSourceStack().withSuppressedOutput(),
                        "effect give " + t.getStringUUID() + " " + c.effect() + " true");
            }
        }
    }
}
