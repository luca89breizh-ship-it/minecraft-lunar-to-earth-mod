package fr.lunaire.fabric.entity;

import fr.lunaire.fabric.content.ModMobs;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/** Animal paisible de Lunaire : se promène, fuit quand on le frappe. */
public class LunarPassive extends PathfinderMob {
    public LunarPassive(EntityType<? extends LunarPassive> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder attributes(ModMobs.Cfg c) {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, c.hp())
                .add(Attributes.MOVEMENT_SPEED, c.speed());
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new PanicGoal(this, 1.5));
        goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.9));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 6.0F));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
    }
}
