package fr.lunaire.fabric.entity;

import fr.lunaire.fabric.ModAttachments;
import fr.lunaire.fabric.content.ModMobs;
import java.util.EnumSet;
import java.util.UUID;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/** Animal paisible de Lunaire : se promène, fuit quand on le frappe. */
public class LunarPassive extends PathfinderMob {
    public LunarPassive(EntityType<? extends LunarPassive> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder attributes(ModMobs.Cfg c) {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, c.hp())
                .add(Attributes.MOVEMENT_SPEED, c.speed());
    }

    /** Propriétaire (chat/chien adopté) : donnée attachée à l'entité, sauvegardée toute seule avec elle. */
    public UUID ownerId() {
        String s = getAttached(ModAttachments.OWNER);
        if (s == null || s.isEmpty()) {
            return null;
        }
        try {
            return UUID.fromString(s);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    public void setOwner(UUID id) {
        setAttached(ModAttachments.OWNER, id.toString());
    }

    ServerPlayer owner() {
        UUID id = ownerId();
        if (id == null || !(level() instanceof ServerLevel sl)) {
            return null;
        }
        return sl.getServer().getPlayerList().getPlayer(id);
    }

    /** L'animal adopté suit son maître (et le rejoint s'il est trop loin). */
    private static class FollowOwner extends Goal {
        private final LunarPassive mob;
        private int timer;

        FollowOwner(LunarPassive mob) {
            this.mob = mob;
            setFlags(EnumSet.of(Goal.Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            ServerPlayer o = mob.owner();
            return o != null && o.level() == mob.level() && mob.distanceToSqr(o) > 16.0;
        }

        @Override
        public boolean canContinueToUse() {
            ServerPlayer o = mob.owner();
            return o != null && o.level() == mob.level() && mob.distanceToSqr(o) > 6.25;
        }

        @Override
        public void start() {
            timer = 0;
        }

        @Override
        public void tick() {
            ServerPlayer o = mob.owner();
            if (o == null || --timer > 0) {
                return;
            }
            timer = 10;
            if (mob.distanceToSqr(o) > 400.0 && mob.level() instanceof ServerLevel sl) {
                var src = sl.getServer().createCommandSourceStack().withSuppressedOutput();
                sl.getServer().getCommands().performPrefixedCommand(src,
                        "tp " + mob.getStringUUID() + " " + o.getStringUUID());
            } else {
                mob.getNavigation().moveTo(o, 1.3);
            }
        }
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new PanicGoal(this, 1.5));
        goalSelector.addGoal(4, new FollowOwner(this));
        goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.9));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 6.0F));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
    }
}
