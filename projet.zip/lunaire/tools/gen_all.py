#!/usr/bin/env python3
"""Génère toutes les ressources de Lunaire (données, modèles, textures, structures).

Lancé automatiquement par GitHub Actions avant la compilation :  python3 tools/gen_all.py
"""
import json
import shutil
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from lg_core import *  # noqa
import lg_content as C
import lg_sprites as SP
import lg_blocks as BL
import lg_struct as ST
import lg_extra as X
import lg_sky as SKY
import lg_bulk as BK
import lg_mobs as MB
import lg_sprites2 as SP2
import lg_vanilla as VN
import lg_mobs_paint as PN
import lg_java as JV

TOOLS = Path(__file__).resolve().parent
LEVEL = int((TOOLS / 'level.txt').read_text().strip()) if (TOOLS / 'level.txt').exists() else 9
M = "lunaire:"
IT = ASSETS / "textures" / "item"

TOOL_COLOR = {"lunar_rock": (120, 120, 132), "steel": (125, 132, 145), "titanium": (130, 160, 215),
              "lunar_alloy": (80, 140, 200)}

EXTRA_FR = {
    "itemGroup.lunaire": "Lunaire", "entity.lunaire.selenite": "Sélénite de l'Ombre",
    "entity.lunaire.dust_golem": "Golem de poussière",
    "lunaire.intro1": "Vous vous réveillez dans les débris de votre capsule de secours...",
    "lunaire.intro2": "Il n'y a pas d'air ici. Fouillez le coffre : un épurateur, endommagé, mais réparable.",
    "lunaire.suffocate": "Plus d'oxygène !",
    "lunaire.no_blueprint": "Décollage impossible. Il faut : schéma de fusée (Tier 3), moteur de fusée, étage propulseur, grand réservoir, 3 carburants de fusée, et le module de rentrée en main.",
    "lunaire.guide": "Un Guide de Lunaire est dans votre inventaire : clic droit pour le recevoir en livre, puis relisez-le quand vous voulez.",
    "lunaire.tamed": "Vous avez adopté %s !", "lunaire.tame_fail": "%s se méfie encore...",
    "lunaire.powered": "Machine alimentée", "lunaire.no_power": "Pas d'énergie (panneau solaire de jour ou générateur à hydrogène allumé à proximité).",
    "lunaire.no_ice": "Il faut de la glace lunaire.", "lunaire.sealed": "Atmosphère scellée : %s blocs pressurisés.",
    "lunaire.leak": "Fuite : la pièce n'est pas étanche.", "lunaire.hydrated": "Régolithe hydratée !",
    "lunaire.launch": "Lancement dans 10 secondes !", "lunaire.fuelled": "Cellule insérée.",
    "lunaire.compressed": "Réservoir rempli.",
}
EXTRA_EN = {
    "itemGroup.lunaire": "Lunaire", "entity.lunaire.selenite": "Shadow Selenite",
    "entity.lunaire.dust_golem": "Dust Golem",
    "lunaire.intro1": "You wake up in the debris of your rescue capsule...",
    "lunaire.intro2": "There is no air here. Check the chest: a damaged but repairable purifier.",
    "lunaire.suffocate": "Out of oxygen!",
    "lunaire.no_blueprint": "Cannot launch. You need: Tier 3 blueprint, rocket engine, stage booster, large fuel tank, 3 rocket fuel, and the reentry module in hand.",
    "lunaire.guide": "A Lunaire Guide is in your inventory: right-click it to get the book.",
    "lunaire.tamed": "You adopted %s!", "lunaire.tame_fail": "%s is still wary...",
    "lunaire.powered": "Machine powered", "lunaire.no_power": "No power (solar panel in daylight or lit hydrogen generator nearby).",
    "lunaire.no_ice": "You need lunar ice.", "lunaire.sealed": "Atmosphere sealed: %s blocks pressurized.",
    "lunaire.leak": "Leak: the room is not airtight.", "lunaire.hydrated": "Hydrated regolith!",
    "lunaire.launch": "Launch in 10 seconds!", "lunaire.fuelled": "Cell inserted.",
    "lunaire.compressed": "Tank filled.",
}


# ============================================================================ ASSETS

MOB_TEX = {}


def mob_head_face(name):
    """Visage (tête + calque de chapeau) d'un mob, lu dans sa texture : liste de lignes de pixels RGBA."""
    m = next(x for x in MB.MOBS if x[0] == name)
    tex = MOB_TEX[name]
    shp = MB.java_shapes()[m[3]]
    head = shp["parts"]["head"]
    w, h, d = (int(round(v)) for v in head["box"][3:6])
    u, v = head["tex"]
    face = [[tuple(tex.get(u + d + x, v + d + y)) for x in range(w)] for y in range(h)]
    hu, hv = shp["hat_tex"]
    for y in range(h):
        for x in range(w):
            px = tex.get(hu + d + x, hv + d + y)
            if px[3] > 200:
                face[y][x] = tuple(px)
    return face, w, h


EARS = {"moon_rabbit": "rabbit", "moon_cat": "cat", "astro_pup": "dog", "space_goat": "goat"}


def mob_egg(name):
    face, w, h = mob_head_face(name)
    cfg = MB.java_config()[name]
    H = max(11, min(15, int(round(11 + min(1.0, cfg["height"] / 2.0) * 4))))
    W = max(10, min(14, int(round(9 + min(1.0, max(cfg["width"], cfg["height"] * 0.5) / 0.9) * 4))))
    return VN.face_egg(face, w, h, W, H, EARS.get(name))


def item_sprite(it):
    n = it["name"]
    use = it.get("use")
    if isinstance(use, dict) and "egg" in use and use["egg"].split(":")[1] in MOB_TEX:
        return mob_egg(use["egg"].split(":")[1])
    P = SP.painters()
    if n in P:
        return P[n]()
    if "shape" in it:
        return SP2.paint(it["shape"], it["color"], it.get("color2", it["color"]))
    if "tool" in it:
        col = BK.TOOL_MATS[it["mat"]][6]
        return VN.tool(it["tool"], col)
    if "armor" in it:
        main, dark, glow = BL.SUITS[it["suit"]]
        return VN.armor(it["armor"], main, glow)
    ex = SP.sprite_extra(it)
    if ex is not None:
        return ex
    f = it.get("form")
    col = (C.MAT[it["mat"]] if "mat" in it else it["color"]) + (255,)
    if f == "ingot":
        return VN.ingot(col)
    return {"ingot": SP.ingot, "plate": SP.plate, "gear": SP.gear, "wire": SP.wire, "rod": SP.rod,
            "gem": SP.gem, "pile": SP.pile}[f](col)


def gen_shaped_block(b):
    name, kind, base = b["name"], b["kind"], b["base"]
    tex = JV.block_tex(base, f"{M}block/{base}")
    MD = ASSETS / "models" / "block"
    bs = ASSETS / "blockstates" / f"{name}.json"
    item_model = f"{M}block/{name}"
    if kind == "stairs":
        for suf, parent in (("", "stairs"), ("_inner", "inner_stairs"), ("_outer", "outer_stairs")):
            write_json(MD / f"{name}{suf}.json", {"parent": f"minecraft:block/{parent}",
                                                  "textures": {"bottom": tex, "top": tex, "side": tex}})
        v = {}
        for fi, face in enumerate(("east", "south", "west", "north")):
            fy = fi * 90
            for half in ("bottom", "top"):
                for shape in ("straight", "inner_left", "inner_right", "outer_left", "outer_right"):
                    m = {"straight": "", "inner": "_inner", "outer": "_outer"}[shape.split("_")[0]]
                    d = {"model": f"{M}block/{name}{m}"}
                    y = fy
                    if shape.endswith("left"):
                        y += 270 if half == "bottom" else 0
                    elif shape.endswith("right"):
                        y += 0 if half == "bottom" else 90
                    y %= 360
                    if half == "top":
                        d["x"] = 180
                    if y:
                        d["y"] = y
                    if d.get("x") or d.get("y"):
                        d["uvlock"] = True
                    v[f"facing={face},half={half},shape={shape}"] = d
        write_json(bs, {"variants": v})
    elif kind == "slab":
        write_json(MD / f"{name}.json", {"parent": "minecraft:block/slab", "textures": {"bottom": tex, "top": tex, "side": tex}})
        write_json(MD / f"{name}_top.json", {"parent": "minecraft:block/slab_top", "textures": {"bottom": tex, "top": tex, "side": tex}})
        write_json(bs, {"variants": {"type=bottom": {"model": f"{M}block/{name}"}, "type=top": {"model": f"{M}block/{name}_top"},
                                     "type=double": {"model": f"{M}block/{base}"}}})
    else:
        for suf, parent in (("_post", "template_wall_post"), ("_side", "template_wall_side"), ("_side_tall", "template_wall_side_tall")):
            write_json(MD / f"{name}{suf}.json", {"parent": f"minecraft:block/{parent}", "textures": {"wall": tex}})
        write_json(MD / f"{name}_inventory.json", {"parent": "minecraft:block/wall_inventory", "textures": {"wall": tex}})
        mp = [{"when": {"up": "true"}, "apply": {"model": f"{M}block/{name}_post"}}]
        for i, face in enumerate(("north", "east", "south", "west")):
            for h, suf in (("low", "_side"), ("tall", "_side_tall")):
                a = {"model": f"{M}block/{name}{suf}", "uvlock": True}
                if i:
                    a["y"] = i * 90
                mp.append({"when": {face: h}, "apply": a})
        write_json(bs, {"multipart": mp})
        item_model = f"{M}block/{name}_inventory"
    write_json(ASSETS / "items" / f"{name}.json", {"model": {"type": "minecraft:model", "model": item_model}})


def gen_mob_assets():
    ET = ASSETS / "textures" / "entity"
    ET.mkdir(parents=True, exist_ok=True)
    for m in MB.MOBS:
        img = PN.paint(m, m[3])
        MOB_TEX[m[0]] = img
        img.save(ET / f"{m[0]}.png")


def gen_mob_loot():
    names = {i["name"] for i in C.ITEMS} | {b["name"] for b in C.BLOCKS}
    for m in MB.MOBS:
        name, drops = m[0], m[10]
        pools = []
        for (it, lo, hi) in drops:
            if ":" in it:
                pools.append({"rolls": 1, "entries": [entry(it, lo, hi)]})
                continue
            assert it in names, (name, it)
            pools.append({"rolls": 1, "entries": [entry(M + it, lo, hi)]})
        if m[5] == "boss":
            pools.append({"rolls": 1, "entries": [entry(M + "ancient_core", 1, 2)]})
        if name in ("moon_rabbit", "lunar_hare", "space_goat", "moon_sheep", "lunar_tortoise"):
            pools.append({"rolls": 1, "entries": [entry(M + "moon_meat", 1, 2)]})
        write_json(DATA / "loot_table" / "entities" / f"{name}.json", {
            "type": "minecraft:entity", "random_sequence": f"{M}entities/{name}", "pools": pools})


def gen_assets():
    BL.draw_blocks([b for b in C.BLOCKS if not JV.has_block(b["name"])])  # les autres reprennent les textures du jeu
    BL.creatures()
    gen_mob_assets()
    for it in C.ITEMS:
        if JV.item_ref(it, BL.SUITS) is None:
            item_sprite(it).save(IT / f"{it['name']}.png")
    SKY.gen_all()  # Terre et planètes : dessinées par le client (lunaire_sky/*.png)

    for b in C.BLOCKS:
        name, kind = b["name"], b["kind"]
        bs = ASSETS / "blockstates" / f"{name}.json"
        if kind in ("stairs", "slab", "wall"):
            gen_shaped_block(b)
            continue
        if kind in ("lit", "radiator"):
            write_json(bs, {"variants": {"lit=false": {"model": f"{M}block/{name}"},
                                         "lit=true": {"model": f"{M}block/{name}_lit"}}})
            for suffix in ("", "_lit"):
                if kind == "lit":
                    model = {"parent": "minecraft:block/cube_column",
                             "textures": {"end": f"{M}block/{name}_top", "side": f"{M}block/{name}_side{suffix}"}}
                else:
                    model = {"parent": "minecraft:block/cube_all", "textures": {"all": f"{M}block/{name}{suffix}"}}
                write_json(ASSETS / "models" / "block" / f"{name}{suffix}.json", model)
        else:
            write_json(bs, {"variants": {"": {"model": f"{M}block/{name}"}}})
            if kind == "column":
                model = {"parent": "minecraft:block/cube_column",
                         "textures": {"end": f"{M}block/{name}_top", "side": f"{M}block/{name}_side"}}
            else:
                model = {"parent": "minecraft:block/cube_all",
                         "textures": {"all": JV.block_tex(name, f"{M}block/{name}")}}
            write_json(ASSETS / "models" / "block" / f"{name}.json", model)
        write_json(ASSETS / "items" / f"{name}.json",
                   {"model": {"type": "minecraft:model", "model": f"{M}block/{name}"}})

    for it in C.ITEMS:
        name = it["name"]
        ref = JV.item_ref(it, BL.SUITS)
        if ref:  # texture du jeu de base (teintée si besoin)
            write_json(ASSETS / "models" / "item" / f"{name}.json",
                       {"parent": ref["parent"], "textures": ref["textures"]})
            model = {"type": "minecraft:model", "model": f"{M}item/{name}"}
            if ref["tints"]:
                model["tints"] = [{"type": "minecraft:constant", "value": t} for t in ref["tints"]]
            write_json(ASSETS / "items" / f"{name}.json", {"model": model})
            continue
        parent = "minecraft:item/handheld" if "tool" in it else "minecraft:item/generated"
        write_json(ASSETS / "models" / "item" / f"{name}.json",
                   {"parent": parent, "textures": {"layer0": f"{M}item/{name}"}})
        write_json(ASSETS / "items" / f"{name}.json",
                   {"model": {"type": "minecraft:model", "model": f"{M}item/{name}"}})

    for suit, cols in BL.SUITS.items():  # armures portées : textures du jeu (cuir teint / métal teinté)
        write_json(ASSETS / "equipment" / f"{suit}.json", JV.equipment(suit, cols[0]))

    fr = {f"block.lunaire.{b['name']}": b["fr"] for b in C.BLOCKS}
    en = {f"block.lunaire.{b['name']}": b["en"] for b in C.BLOCKS}
    fr.update({f"item.lunaire.{i['name']}": i["fr"] for i in C.ITEMS})
    en.update({f"item.lunaire.{i['name']}": i["en"] for i in C.ITEMS})
    fr.update(EXTRA_FR), en.update(EXTRA_EN)
    for m in MB.MOBS:
        fr[f"entity.lunaire.{m[0]}"] = m[1]
        en[f"entity.lunaire.{m[0]}"] = m[2]
    for nm, bf, be, *_r in MOON_BIOMES:
        fr[f"biome.lunaire.{nm}"] = bf
        en[f"biome.lunaire.{nm}"] = be
    xf, xe = X.lang()
    fr.update(xf), en.update(xe)
    fr["generator.lunaire.lunaire"] = "Lunaire (la Lune)"
    en["generator.lunaire.lunaire"] = "Lunaire (the Moon)"
    fr["generator.lunaire.lunaire_flat"] = "Lunaire (la Lune, superflat)"
    en["generator.lunaire.lunaire_flat"] = "Lunaire (the Moon, superflat)"
    write_json(ASSETS / "lang" / "fr_fr.json", fr)
    write_json(ASSETS / "lang" / "en_us.json", en)


def gen_java_content():
    items = []
    for i in C.ITEMS:
        d = {"name": i["name"], "stack": i.get("stack", 64)}
        for k in ("tool", "mat", "armor", "suit", "use"):
            if k in i:
                d[k] = i[k]
        items.append(d)
    blocks = []
    for b in C.BLOCKS:
        d = {k: b[k] for k in ("name", "kind", "tool", "hard", "need", "light", "glass", "sound")}
        if b.get("base") and b["kind"] in ("stairs", "slab", "wall"):
            d["base"] = b["base"]
        blocks.append(d)
    mats = {k: dict(tier=v[0], dur=v[1], speed=v[2], dmg=v[3], ench=v[4], repair=v[5]) for k, v in BK.TOOL_MATS.items()}
    armors = {k: dict(dur=v[0], defense=v[1], ench=v[2], tough=v[3], kb=v[4], repair=v[5]) for k, v in BK.ARMOR_MATS.items()}
    write_json(RES / "lunaire_content.json", {"items": items, "blocks": blocks, "tool_mats": mats, "armor_mats": armors,
                                              "mobs": MB.java_config(), "mob_shapes": MB.java_shapes()})


# ============================================================================ DONNÉES : LOOT, TAGS, RECETTES

def setcount(lo, hi):
    return {"type": "minecraft:set_count", "count": {"type": "minecraft:uniform", "min": lo, "max": hi}}


def entry(item, lo=None, hi=None, weight=None):
    e = {"type": "minecraft:item", "name": item}
    if lo is not None:
        e["modifier"] = setcount(lo, hi)
    if weight:
        e["weight"] = weight
    return e


def chest(name, pools):
    write_json(DATA / "loot_table" / "chests" / f"{name}.json",
               {"type": "minecraft:chest", "random_sequence": f"{M}chests/{name}", "pools": pools})


def gen_loot():
    for b in C.BLOCKS:
        e = {"type": "minecraft:item", "name": b["drop"] or f"{M}{b['name']}"}
        if b["count"]:
            e["modifier"] = setcount(*b["count"])
        if b["kind"] == "slab":
            e["modifier"] = [{"type": "minecraft:set_count", "count": 2, "condition": {
                "type": "minecraft:match_block", "blocks": f"{M}{b['name']}", "state": {"type": "double"}}}]
        pool = {"rolls": 1, "condition": {"type": "minecraft:survives_explosion"}, "entries": [e]}
        write_json(DATA / "loot_table" / "blocks" / f"{b['name']}.json", {
            "type": "minecraft:block", "pools": [pool], "random_sequence": f"{M}blocks/{b['name']}"})
    I = lambda n: M + n
    chest("capsule", [
        {"rolls": 1, "entries": [entry(I("damaged_air_purifier"))]},
        {"rolls": 1, "entries": [entry(I("oxygen_bottle_full"), 2, 3)]},
        {"rolls": 1, "entries": [entry(I("iron_scrap"), 3, 5)]},
        {"rolls": 1, "entries": [entry(I("circuit_board"), 1, 2)]},
        {"rolls": 1, "entries": [entry(I("protein_ration"), 2, 3)]},
        {"rolls": 1, "entries": [entry(I("blueprint_tier1"))]}])
    chest("lab", [{"rolls": {"type": "minecraft:uniform", "min": 4, "max": 7}, "entries": [
        entry(I("circuit_board"), 1, 3, 25), entry(I("iron_scrap"), 2, 6, 25), entry("minecraft:iron_ingot", 1, 3, 12),
        entry(I("oxygen_bottle_full"), 1, 2, 15), entry(I("hydrogen_cell"), 1, 2, 12), entry(I("aluminum_ingot"), 1, 3, 10),
        entry(I("copper_ingot"), 2, 4, 10), entry(I("tin_ingot"), 1, 3, 8), entry(I("lithium_battery"), 1, 1, 5),
        entry(I("silicon"), 2, 5, 10), entry(I("insulation"), 1, 2, 8), entry(I("nutrient_paste"), 1, 3, 8),
        entry(I("oxygen_tank_full"), 1, 1, 5), entry(I("medkit"), 1, 1, 4), entry(I("blueprint_tier2"), 1, 1, 3)]}])
    chest("lab_rare", [{"rolls": {"type": "minecraft:uniform", "min": 2, "max": 4}, "entries": [
        entry(I("advanced_circuit"), 1, 2, 15), entry(I("titanium_ingot"), 1, 3, 12), entry(I("lithium_battery"), 1, 2, 10),
        entry(I("pressure_valve"), 1, 1, 10), entry(I("solar_cell"), 1, 2, 10), entry(I("helium3_crystal"), 1, 1, 6),
        entry(I("oxygen_scanner"), 1, 1, 4), entry(I("steel_ingot"), 2, 4, 10), entry(I("processor"), 1, 1, 3),
        entry(I("moonstone"), 1, 1, 4)]}])
    chest("temple", [
        {"rolls": 1, "entries": [entry(I("rocket_blueprint"))]},
        {"rolls": {"type": "minecraft:uniform", "min": 3, "max": 5}, "entries": [
            entry(I("titanium_ingot"), 1, 3, 20), entry(I("aluminum_ingot"), 2, 4, 20), entry(I("meteorite_shard"), 1, 3, 15),
            entry(I("circuit_board"), 1, 2, 15), entry(I("hydrogen_cell"), 1, 2, 10), entry(I("moonstone"), 1, 2, 8),
            entry(I("olivine"), 1, 2, 8), entry(I("lunar_alloy_ingot"), 1, 1, 4), entry(I("power_core"), 1, 1, 3)]}])
    chest("temple_minor", [{"rolls": {"type": "minecraft:uniform", "min": 2, "max": 3}, "entries": [
        entry(I("meteorite_shard"), 1, 2, 20), entry(I("moonstone"), 1, 1, 10), entry(I("olivine"), 1, 1, 10),
        entry(I("silver_ingot"), 1, 3, 10), entry(I("nickel_ingot"), 1, 3, 10), entry(I("lithium_ingot"), 1, 2, 8)]}])
    chest("outpost", [{"rolls": {"type": "minecraft:uniform", "min": 3, "max": 5}, "entries": [
        entry(I("iron_scrap"), 2, 5, 20), entry(I("oxygen_bottle_full"), 1, 2, 15), entry(I("circuit_board"), 1, 2, 15),
        entry(I("algae_bar"), 2, 4, 12), entry(I("energy_gel"), 1, 2, 10), entry(I("thermal_pack"), 1, 1, 5),
        entry(I("cooling_pack"), 1, 1, 5), entry(I("copper_ingot"), 2, 4, 10), entry(I("steel_ingot"), 1, 2, 6)]}])
    write_json(DATA / "loot_table" / "entities" / "dust_golem.json", {
        "type": "minecraft:entity", "random_sequence": f"{M}entities/dust_golem", "pools": [
            {"rolls": 1, "entries": [entry(I("meteorite_shard"), 1, 3)]},
            {"rolls": 1, "entries": [entry(I("iron_scrap"), 0, 2)]},
            {"rolls": 1, "entries": [entry(I("silicon"), 0, 2)]}]})
    write_json(DATA / "loot_table" / "entities" / "selenite.json", {
        "type": "minecraft:entity", "random_sequence": f"{M}entities/selenite", "pools": [
            {"rolls": 1, "entries": [entry(I("oxygen_bottle"), 0, 1)]},
            {"rolls": 1, "entries": [entry(I("moonstone"), 0, 1)]}]})


def tag(path, values):
    write_json(path, {"values": values})


def gen_tags():
    T = VANILLA_DATA / "tags" / "block"
    by = {"pickaxe": [], "shovel": []}
    needs = {"stone": [], "iron": [], "diamond": []}
    for b in C.BLOCKS:
        by[b["tool"]].append(M + b["name"])
        if b["need"] in needs:
            needs[b["need"]].append(M + b["name"])
    tag(T / "mineable" / "pickaxe.json", by["pickaxe"])
    tag(T / "mineable" / "shovel.json", by["shovel"])
    for k, v in needs.items():
        tag(T / f"needs_{k}_tool.json", v)
    tag(T / "supports_vegetation.json", [M + "hydrated_regolith"])
    tag(T / "dirt.json", [M + "hydrated_regolith"])
    IT_ = DATA / "tags" / "item"
    tag(IT_ / "lunar_tool_materials.json", [M + "lunar_rock"])
    tag(IT_ / "steel_repair.json", [M + "steel_ingot"])
    tag(IT_ / "titanium_repair.json", [M + "titanium_ingot"])
    tag(IT_ / "alloy_repair.json", [M + "lunar_alloy_ingot"])
    tag(IT_ / "aluminum_repair.json", [M + "aluminum_ingot"])
    rep = {"bronze": "bronze_ingot", "nickel": "nickel_ingot", "silver": "silver_ingot", "olivine": "olivine",
           "moonstone": "moonstone", "meteorite": "meteorite_shard", "tektite": "tektite"}
    for k, v in rep.items():
        tag(IT_ / f"{k}_repair.json", [M + v])
    for s in (("lab", "temple", "outpost", "crater", "pond") if LEVEL >= 1 else ()):
        tag(DATA / "tags" / "worldgen" / "biome" / "has_structure" / f"{s}.json", [M + b[0] for b in MOON_BIOMES])
    if LEVEL >= 2:
        tag(VANILLA_DATA / "tags" / "worldgen" / "world_preset" / "normal.json", [M + "lunaire", M + "lunaire_flat"])


# (nom, FR, EN, surface, température, humidité, continentalité, érosion, étrangeté)
MOON_BIOMES = [
    ("lunar_plains", "Plaines lunaires", "Lunar Plains", "regolith", (-0.45, 0.55), (-1, 0.3), (-0.1, 0.45), (-1, 1), (-0.5, 1)),
    ("lunar_highlands", "Hautes terres lunaires", "Lunar Highlands", "anorthosite", (-0.45, 0.55), (-1, 1), (0.45, 1.2), (-1, 1), (-1, 1)),
    ("lunar_maria", "Mer de basalte", "Basalt Sea", "mare_basalt", (-0.45, 0.55), (-1, 1), (-1.2, -0.1), (-1, 1), (-1, 1)),
    ("polar_ice_cap", "Calotte glaciaire", "Polar Ice Cap", "frozen_regolith", (-1, -0.45), (-1, 1), (-1.2, 1.2), (-1, 1), (-1, 1)),
    ("olivine_fields", "Champs d'olivine", "Olivine Fields", "olivine_gravel", (-0.45, 0.55), (0.3, 1), (-0.1, 0.45), (-1, 1), (-1, 1)),
    ("meteorite_field", "Champ de météorites", "Meteorite Field", "tektite", (-0.45, 0.55), (-1, 0.3), (-0.1, 0.45), (-1, 1), (-1, -0.5)),
    ("dust_dunes", "Dunes de poussière", "Dust Dunes", "lunar_dust", (0.55, 1), (-1, 1), (-1.2, 1.2), (-1, 1), (-1, 1)),
]
WATER_COLOR = "#6f8ea8"  # eau gris-bleuté


def gen_recipes():
    for r in C.RECIPES:
        rid = r["result"].split(":")[1]
        res = {"id": r["result"], "count": r["n"]}
        if r["type"] == "cooking":
            data = {"type": "minecraft:smelting", "category": r["cat"], "cookingtime": r["time"], "experience": r["xp"],
                    "ingredient": r["ingredient"], "result": {"id": r["result"]}}
        elif r["type"] == "shaped":
            used = set("".join(r["pattern"])) - {" "}
            data = {"type": "minecraft:crafting_shaped", "category": "misc", "pattern": r["pattern"],
                    "key": {k: v for k, v in r["key"].items() if k in used}, "result": res}
        else:
            data = {"type": "minecraft:crafting_shapeless", "category": "misc", "ingredients": r["ingredients"], "result": res}
        # un même résultat peut avoir plusieurs recettes (ex: lingot <- bloc) : nom unique
        name = rid
        p = DATA / "recipe" / f"{name}.json"
        k = 2
        while p.exists():
            name = f"{rid}_{k}"
            p = DATA / "recipe" / f"{name}.json"
            k += 1
        write_json(p, data)


# ============================================================================ MONDE

def sky_dimension_type():
    dt = json.loads((TOOLS / "overworld_dimtype.json").read_text(encoding="utf-8"))
    a = dt["attributes"]
    a["minecraft:visual/sky_color"] = "#000000"
    a["minecraft:visual/fog_color"] = "#020205"
    a["minecraft:visual/ambient_light_color"] = "#22252b"
    for k in ("minecraft:visual/cloud_color", "minecraft:visual/cloud_height"):
        a.pop(k, None)
    if LEVEL >= 3:
        mus = {"sound": "lunaire:music.moon", "min_delay": 1200, "max_delay": 4800}
        a["minecraft:audio/background_music"] = {"default": dict(mus), "creative": dict(mus)}
    a["minecraft:gameplay/bed_rule"] = {"can_set_spawn": "never", "can_sleep": "never", "destroy_on_use": False}
    dt["ambient_light"] = 0.08
    dt["timelines"] = "#lunaire:in_moon" if LEVEL >= 2 else "#minecraft:in_overworld"
    dt["monster_spawn_light_level"] = 15
    write_json(DATA / "dimension_type" / "moon.json", dt)


def sky_timeline():
    tl = json.loads((TOOLS / "day_timeline.json").read_text(encoding="utf-8"))
    tl.pop("time_markers", None)
    tracks = tl["tracks"]
    for k in ("minecraft:visual/sky_color", "minecraft:visual/fog_color", "minecraft:visual/cloud_color",
              "minecraft:visual/sunrise_sunset_color", "minecraft:visual/star_brightness", "minecraft:visual/moon_angle"):
        tracks.pop(k, None)
    tracks["minecraft:visual/star_brightness"] = {"keyframes": [{"ticks": 0, "value": 1.0}, {"ticks": 12000, "value": 1.0}]}
    tracks["minecraft:visual/sunrise_sunset_color"] = {"keyframes": [{"ticks": 0, "value": "#00000000"}, {"ticks": 12000, "value": "#00000000"}]}
    # la « lune » du ciel est la Terre : toujours pleine, fixe et haute dans le ciel
    tracks["minecraft:visual/moon_angle"] = {"keyframes": [{"ticks": 0, "value": 180.0}, {"ticks": 12000, "value": 180.0}]}
    tracks["minecraft:visual/moon_phase"] = {"keyframes": [{"ticks": 0, "value": "full_moon"}, {"ticks": 12000, "value": "full_moon"}]}
    write_json(DATA / "timeline" / "moon_day.json", tl)
    tag(DATA / "tags" / "timeline" / "in_moon.json", [M + "moon_day"])


def moon_world():
    sky_dimension_type()
    if LEVEL >= 2:
        sky_timeline()
    ns = json.loads((TOOLS / "overworld_noise_settings.json").read_text(encoding="utf-8"))
    ns["default_block"] = M + "lunar_rock"
    ns["default_fluid"] = "minecraft:air"
    ns["sea_level"] = -64
    ns["material_rule"] = M + "moon"
    write_json(DATA / "worldgen" / "noise_settings" / "moon.json", ns)
    def surf(block):
        return {"type": "minecraft:condition", "if_true": "minecraft:under_floor",
                "then_run": {"type": "minecraft:block", "result_state": M + block}}
    per_biome = []
    for nm, _f, _e, top, *_r in (MOON_BIOMES if LEVEL >= 3 else []):
        if nm == "lunar_plains":
            continue
        per_biome.append({"type": "minecraft:condition", "if_true": {"type": "minecraft:biome", "biome_is": M + nm},
                          "then_run": surf(top)})
    write_json(DATA / "worldgen" / "material_rule" / "moon.json", {
        "type": "minecraft:sequence", "sequence": [
            "minecraft:bedrock_floor",
            {"type": "minecraft:condition", "if_true": {"type": "minecraft:above_preliminary_surface"},
             "then_run": {"type": "minecraft:sequence", "sequence": per_biome + [surf("regolith")]}}]})

    ore_names = []

    def ore_feature(name, block, size, count, lo, hi):
        ore_names.append(M + name)
        write_json(DATA / "worldgen" / "feature" / f"{name}.json", {
            "type": "minecraft:ore", "discard_chance_on_air_exposure": 0.0, "size": size, "targets": [{
                "state": M + block,
                "target": {"predicate_type": "minecraft:block_match", "block": M + "lunar_rock"}}]})
        write_json(DATA / "worldgen" / "placed_feature" / f"{name}.json", {
            "feature": M + name, "placement": [
                {"type": "minecraft:count", "count": count}, {"type": "minecraft:in_square"},
                {"type": "minecraft:height_range", "height": {
                    "type": "minecraft:uniform", "min_inclusive": {"absolute": lo}, "max_inclusive": {"absolute": hi}}},
                {"type": "minecraft:biome"}]})

    for b in (C.BLOCKS if LEVEL >= 3 else []):
        if "ore" in b:
            o = b["ore"]
            ore_feature(b["name"], b["name"], o["size"], o["per_chunk"], o["y_min"], o["y_max"])
    if LEVEL >= 3:
        ore_feature("ore_lunar_ice", "lunar_ice", 12, 8, 30, 120)
        ore_feature("ice_surface", "lunar_ice", 5, 2, 40, 120)

    spawns = {k: [] for k in ("ambient", "axolotls", "creature", "misc", "monster", "underground_water_creature",
                              "water_ambient", "water_creature")}
    features = [[] for _ in range(11)]
    features[6] = ore_names
    for nm, *_r in (MOON_BIOMES if LEVEL >= 3 else MOON_BIOMES[:1]):
        write_json(DATA / "worldgen" / "biome" / f"{nm}.json", {
            "attributes": {"minecraft:gameplay/natural_mob_spawns": {
                "argument": {"spawn_costs": {}, "spawns_by_category": spawns}, "modifier": "overlay"},
                "minecraft:visual/sky_color": "#000000", "minecraft:visual/fog_color": "#020205"},
            "carvers": [], "downfall": 0.0, "effects": {"water_color": WATER_COLOR}, "features": features,
            "has_precipitation": False, "temperature": 0.0})

    if LEVEL >= 3:
        bsrc = {"type": "minecraft:multi_noise", "biomes": [
            {"biome": M + nm, "parameters": {"temperature": list(t), "humidity": list(h), "continentalness": list(c),
                                              "erosion": list(e), "depth": [-1.0, 1.0], "weirdness": list(w),
                                              "offset": 0.0}}
            for nm, _f, _e, _top, t, h, c, e, w in MOON_BIOMES]}
    else:
        bsrc = {"type": "minecraft:fixed", "biome": M + "lunar_plains"}
    noise = {"type": M + "moon", "generator": {"type": "minecraft:noise", "settings": M + "moon", "biome_source": bsrc}}
    flat = {"type": M + "moon", "generator": {"type": "minecraft:flat", "settings": {
        "biome": M + "lunar_plains", "features": False, "lakes": False,
        "layers": [{"block": "minecraft:bedrock", "height": 1}, {"block": M + "lunar_rock", "height": 59},
                   {"block": M + "regolith", "height": 4}],
        "structure_overrides": [M + "lab", M + "temple", M + "outpost", M + "crater", M + "pond"] if LEVEL >= 5 else []}}}
    write_json(DATA / "dimension" / "moon.json", noise)
    write_json(DATA / "dimension" / "moon_flat.json", flat)
    write_json(DATA / "dimension" / "earth.json", {
        "type": "minecraft:overworld",
        "generator": {"type": "minecraft:noise", "settings": "minecraft:overworld",
                      "biome_source": {"type": "minecraft:multi_noise", "preset": "minecraft:overworld"}}})

    def preset(overworld):
        return {"dimensions": {
            "minecraft:overworld": overworld,
            "minecraft:the_nether": {"type": "minecraft:the_nether", "generator": {
                "type": "minecraft:noise", "settings": "minecraft:nether",
                "biome_source": {"type": "minecraft:multi_noise", "preset": "minecraft:nether"}}},
            "minecraft:the_end": {"type": "minecraft:the_end", "generator": {
                "type": "minecraft:noise", "settings": "minecraft:end", "biome_source": {"type": "minecraft:the_end"}}}}}
    if LEVEL >= 2:
        write_json(DATA / "worldgen" / "world_preset" / "lunaire.json", preset(noise))
        write_json(DATA / "worldgen" / "world_preset" / "lunaire_flat.json", preset(flat))


def structure(name, step, start_h, adapt, salt, spacing, sep):
    write_json(DATA / "worldgen" / "template_pool" / f"{name}.json", {
        "elements": [{"element": {"element_type": "minecraft:single_pool_element", "location": f"{M}{name}",
                                  "processors": "minecraft:empty", "projection": "rigid"}, "weight": 1}],
        "fallback": "minecraft:empty"})
    write_json(DATA / "worldgen" / "structure" / f"{name}.json", {
        "type": "minecraft:jigsaw", "biomes": f"#{M}has_structure/{name}", "max_distance_from_center": 80,
        "project_start_to_heightmap": "WORLD_SURFACE_WG", "size": 1, "spawn_overrides": {},
        "start_height": {"absolute": start_h}, "start_pool": f"{M}{name}", "step": step,
        "terrain_adaptation": adapt, "use_expansion_hack": False})
    write_json(DATA / "worldgen" / "structure_set" / f"{name}.json", {
        "placement": {"type": "minecraft:random_spread", "salt": salt, "separation": sep, "spacing": spacing},
        "structures": [{"structure": f"{M}{name}", "weight": 1}]})


def gen_structures():
    ST.build_all()
    # start_height : décalage par rapport à la surface (fondations enterrées)
    F = ST.FOUND
    structure("lab", "surface_structures", -F["lab"], "none", 91731, 44, 18)
    structure("temple", "underground_structures", -F["temple"], "none", 52817, 52, 20)
    structure("outpost", "surface_structures", -F["outpost"], "none", 33119, 36, 14)
    structure("crater", "surface_structures", -F["crater"], "none", 77413, 30, 12)
    structure("pond", "surface_structures", -F["pond"], "none", 20211, 13, 5)


# ============================================================================ MAIN

def gen_fishing():
    """Pêche : sur la Lune on remonte des poissons lunaires (au lieu de la morue/du saumon)."""
    moon = {"type": "minecraft:location_check", "predicate": {"dimension": M + "moon"}}
    write_json(VANILLA_DATA / "loot_table" / "gameplay" / "fishing.json", {
        "type": "minecraft:fishing", "random_sequence": "minecraft:gameplay/fishing",
        "pools": [{"rolls": 1, "entries": [
            {"type": "minecraft:loot_table", "value": "minecraft:gameplay/fishing/junk", "weight": 10, "quality": -2},
            {"type": "minecraft:loot_table", "value": "minecraft:gameplay/fishing/treasure", "weight": 5, "quality": 2,
             "condition": {"type": "minecraft:entity_properties", "entity": "this", "predicate": {
                 "minecraft:type_specific/fishing_hook": {"in_open_water": True}}}},
            {"type": "minecraft:loot_table", "value": "minecraft:gameplay/fishing/fish", "weight": 85, "quality": -1,
             "condition": {"type": "minecraft:inverted", "term": moon}},
            {"type": "minecraft:item", "name": M + "moon_fish", "weight": 85, "quality": -1, "condition": moon}]}]})


def main():
    BK.build()
    bad = C.validate()
    if bad:
        raise SystemExit(f"Ingrédients inconnus : {bad}")
    for p in (RES / "assets", RES / "data", RES / "lunaire_content.json"):
        if p.is_dir():
            shutil.rmtree(p)
        elif p.exists():
            p.unlink()
    gen_assets()
    gen_java_content()
    X.gen_sun()
    if LEVEL >= 3:
        gen_loot()
        gen_mob_loot()
        X.gen_advancements(structures=LEVEL >= 5)
        (ASSETS / "sounds" / "music").mkdir(parents=True, exist_ok=True)
        shutil.copy(TOOLS / "moon_drift.ogg", ASSETS / "sounds" / "music" / "moon_drift.ogg")
        write_json(ASSETS / "sounds.json", {"music.moon": {"sounds": [{"name": "lunaire:music/moon_drift", "stream": True}]}})
    gen_tags()
    if LEVEL >= 4:
        gen_recipes()
    if LEVEL >= 1:
        moon_world()
    if LEVEL >= 5:
        gen_structures()
        gen_fishing()
    n = sum(1 for _ in RES.rglob("*") if _.is_file())
    print(f"Lunaire : {n} fichiers générés ({len(C.ITEMS)} objets, {len(C.BLOCKS)} blocs, {len(C.RECIPES)} recettes)")


if __name__ == "__main__":
    main()
