#!/usr/bin/env python3
"""Génère toutes les ressources de Lunaire (données, modèles, textures, structures).

Lancé automatiquement par GitHub Actions avant la compilation :  python3 tools/gen_all.py
"""
import json
import shutil
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from lg_core import *  # noqa
import lg_content as C
import lg_sprites as SP
import lg_blocks as BL
import lg_struct as ST
import lg_extra as X
import lg_sky as SKY

TOOLS = Path(__file__).resolve().parent
LEVEL = int((TOOLS / 'level.txt').read_text().strip()) if (TOOLS / 'level.txt').exists() else 9
M = "lunaire:"
IT = ASSETS / "textures" / "item"

TOOL_COLOR = {"lunar_rock": (120, 120, 132), "steel": (125, 132, 145), "titanium": (130, 160, 215),
              "lunar_alloy": (80, 140, 200)}

EXTRA_FR = {
    "itemGroup.lunaire": "Lunaire", "entity.lunaire.selenite": "Sélénite de l'Ombre",
    "entity.lunaire.dust_golem": "Golem de poussière",
    "lunaire.intro1": "Vous vous réveillez dans les débris de votre capsule de secours...",
    "lunaire.intro2": "Il n'y a pas d'air ici. Fouillez le coffre : un épurateur, endommagé, mais réparable.",
    "lunaire.suffocate": "Plus d'oxygène !",
    "lunaire.no_blueprint": "Il vous faut le schéma de fusée (Tier 3), un module de rentrée et du carburant de fusée.",
    "lunaire.powered": "Machine alimentée", "lunaire.no_power": "Pas d'énergie (panneau solaire de jour ou générateur à hydrogène allumé à proximité).",
    "lunaire.no_ice": "Il faut de la glace lunaire.", "lunaire.sealed": "Atmosphère scellée : %s blocs pressurisés.",
    "lunaire.leak": "Fuite : la pièce n'est pas étanche.", "lunaire.hydrated": "Régolithe hydratée !",
    "lunaire.launch": "Lancement dans 10 secondes !", "lunaire.fuelled": "Cellule insérée.",
    "lunaire.compressed": "Réservoir rempli.",
}
EXTRA_EN = {
    "itemGroup.lunaire": "Lunaire", "entity.lunaire.selenite": "Shadow Selenite",
    "entity.lunaire.dust_golem": "Dust Golem",
    "lunaire.intro1": "You wake up in the debris of your rescue capsule...",
    "lunaire.intro2": "There is no air here. Check the chest: a damaged but repairable purifier.",
    "lunaire.suffocate": "Out of oxygen!",
    "lunaire.no_blueprint": "You need the Tier 3 rocket blueprint, a reentry module and rocket fuel.",
    "lunaire.powered": "Machine powered", "lunaire.no_power": "No power (solar panel in daylight or lit hydrogen generator nearby).",
    "lunaire.no_ice": "You need lunar ice.", "lunaire.sealed": "Atmosphere sealed: %s blocks pressurized.",
    "lunaire.leak": "Leak: the room is not airtight.", "lunaire.hydrated": "Hydrated regolith!",
    "lunaire.launch": "Launch in 10 seconds!", "lunaire.fuelled": "Cell inserted.",
    "lunaire.compressed": "Tank filled.",
}


# ============================================================================ ASSETS

def item_sprite(it):
    n = it["name"]
    P = SP.painters()
    if n in P:
        return P[n]()
    if "tool" in it:
        return SP.tool(it["tool"], TOOL_COLOR[it["mat"]] + (255,))
    if "armor" in it:
        main, dark, glow = BL.SUITS[it["suit"]]
        return SP.armor(it["armor"], main + (255,), glow + (255,))
    ex = SP.sprite_extra(it)
    if ex is not None:
        return ex
    f = it.get("form")
    col = (C.MAT[it["mat"]] if "mat" in it else it["color"]) + (255,)
    return {"ingot": SP.ingot, "plate": SP.plate, "gear": SP.gear, "wire": SP.wire, "rod": SP.rod,
            "gem": SP.gem, "pile": SP.pile}[f](col)


def gen_assets():
    BL.draw_blocks(C.BLOCKS)
    BL.armor_layers()
    BL.creatures()
    for it in C.ITEMS:
        item_sprite(it).save(IT / f"{it['name']}.png")
    SKY.gen_all()  # Terre et planètes : dessinées par le client (lunaire_sky/*.png)

    for b in C.BLOCKS:
        name, kind = b["name"], b["kind"]
        bs = ASSETS / "blockstates" / f"{name}.json"
        if kind in ("lit", "radiator"):
            write_json(bs, {"variants": {"lit=false": {"model": f"{M}block/{name}"},
                                         "lit=true": {"model": f"{M}block/{name}_lit"}}})
            for suffix in ("", "_lit"):
                if kind == "lit":
                    model = {"parent": "minecraft:block/cube_column",
                             "textures": {"end": f"{M}block/{name}_top", "side": f"{M}block/{name}_side{suffix}"}}
                else:
                    model = {"parent": "minecraft:block/cube_all", "textures": {"all": f"{M}block/{name}{suffix}"}}
                write_json(ASSETS / "models" / "block" / f"{name}{suffix}.json", model)
        else:
            write_json(bs, {"variants": {"": {"model": f"{M}block/{name}"}}})
            if kind == "column":
                model = {"parent": "minecraft:block/cube_column",
                         "textures": {"end": f"{M}block/{name}_top", "side": f"{M}block/{name}_side"}}
            else:
                model = {"parent": "minecraft:block/cube_all", "textures": {"all": f"{M}block/{name}"}}
            write_json(ASSETS / "models" / "block" / f"{name}.json", model)
        write_json(ASSETS / "items" / f"{name}.json",
                   {"model": {"type": "minecraft:model", "model": f"{M}block/{name}"}})

    for it in C.ITEMS:
        name = it["name"]
        parent = "minecraft:item/handheld" if "tool" in it else "minecraft:item/generated"
        write_json(ASSETS / "models" / "item" / f"{name}.json",
                   {"parent": parent, "textures": {"layer0": f"{M}item/{name}"}})
        write_json(ASSETS / "items" / f"{name}.json",
                   {"model": {"type": "minecraft:model", "model": f"{M}item/{name}"}})

    for suit in BL.SUITS:
        write_json(ASSETS / "equipment" / f"{suit}.json", {
            "layers": {"humanoid": [{"texture": f"{M}{suit}"}], "humanoid_leggings": [{"texture": f"{M}{suit}"}]}})

    fr = {f"block.lunaire.{b['name']}": b["fr"] for b in C.BLOCKS}
    en = {f"block.lunaire.{b['name']}": b["en"] for b in C.BLOCKS}
    fr.update({f"item.lunaire.{i['name']}": i["fr"] for i in C.ITEMS})
    en.update({f"item.lunaire.{i['name']}": i["en"] for i in C.ITEMS})
    fr.update(EXTRA_FR), en.update(EXTRA_EN)
    xf, xe = X.lang()
    fr.update(xf), en.update(xe)
    fr["generator.lunaire.lunaire"] = "Lunaire (la Lune)"
    en["generator.lunaire.lunaire"] = "Lunaire (the Moon)"
    fr["generator.lunaire.lunaire_flat"] = "Lunaire (la Lune, superflat)"
    en["generator.lunaire.lunaire_flat"] = "Lunaire (the Moon, superflat)"
    write_json(ASSETS / "lang" / "fr_fr.json", fr)
    write_json(ASSETS / "lang" / "en_us.json", en)


def gen_java_content():
    items = []
    for i in C.ITEMS:
        d = {"name": i["name"], "stack": i.get("stack", 64)}
        for k in ("tool", "mat", "armor", "suit", "use"):
            if k in i:
                d[k] = i[k]
        items.append(d)
    blocks = [{k: b[k] for k in ("name", "kind", "tool", "hard", "need", "light", "glass", "sound")} for b in C.BLOCKS]
    write_json(RES / "lunaire_content.json", {"items": items, "blocks": blocks})


# ============================================================================ DONNÉES : LOOT, TAGS, RECETTES

def setcount(lo, hi):
    return {"type": "minecraft:set_count", "count": {"type": "minecraft:uniform", "min": lo, "max": hi}}


def entry(item, lo=None, hi=None, weight=None):
    e = {"type": "minecraft:item", "name": item}
    if lo is not None:
        e["modifier"] = setcount(lo, hi)
    if weight:
        e["weight"] = weight
    return e


def chest(name, pools):
    write_json(DATA / "loot_table" / "chests" / f"{name}.json",
               {"type": "minecraft:chest", "random_sequence": f"{M}chests/{name}", "pools": pools})


def gen_loot():
    for b in C.BLOCKS:
        e = {"type": "minecraft:item", "name": b["drop"] or f"{M}{b['name']}"}
        if b["count"]:
            e["modifier"] = setcount(*b["count"])
        pool = {"rolls": 1, "condition": {"type": "minecraft:survives_explosion"}, "entries": [e]}
        write_json(DATA / "loot_table" / "blocks" / f"{b['name']}.json", {
            "type": "minecraft:block", "pools": [pool], "random_sequence": f"{M}blocks/{b['name']}"})
    I = lambda n: M + n
    chest("capsule", [
        {"rolls": 1, "entries": [entry(I("damaged_air_purifier"))]},
        {"rolls": 1, "entries": [entry(I("oxygen_bottle_full"), 2, 3)]},
        {"rolls": 1, "entries": [entry(I("iron_scrap"), 3, 5)]},
        {"rolls": 1, "entries": [entry(I("circuit_board"), 1, 2)]},
        {"rolls": 1, "entries": [entry(I("protein_ration"), 2, 3)]},
        {"rolls": 1, "entries": [entry(I("blueprint_tier1"))]}])
    chest("lab", [{"rolls": {"type": "minecraft:uniform", "min": 4, "max": 7}, "entries": [
        entry(I("circuit_board"), 1, 3, 25), entry(I("iron_scrap"), 2, 6, 25), entry("minecraft:iron_ingot", 1, 3, 12),
        entry(I("oxygen_bottle_full"), 1, 2, 15), entry(I("hydrogen_cell"), 1, 2, 12), entry(I("aluminum_ingot"), 1, 3, 10),
        entry(I("copper_ingot"), 2, 4, 10), entry(I("tin_ingot"), 1, 3, 8), entry(I("lithium_battery"), 1, 1, 5),
        entry(I("silicon"), 2, 5, 10), entry(I("insulation"), 1, 2, 8), entry(I("nutrient_paste"), 1, 3, 8),
        entry(I("oxygen_tank_full"), 1, 1, 5), entry(I("medkit"), 1, 1, 4), entry(I("blueprint_tier2"), 1, 1, 3)]}])
    chest("lab_rare", [{"rolls": {"type": "minecraft:uniform", "min": 2, "max": 4}, "entries": [
        entry(I("advanced_circuit"), 1, 2, 15), entry(I("titanium_ingot"), 1, 3, 12), entry(I("lithium_battery"), 1, 2, 10),
        entry(I("pressure_valve"), 1, 1, 10), entry(I("solar_cell"), 1, 2, 10), entry(I("helium3_crystal"), 1, 1, 6),
        entry(I("oxygen_scanner"), 1, 1, 4), entry(I("steel_ingot"), 2, 4, 10), entry(I("processor"), 1, 1, 3),
        entry(I("moonstone"), 1, 1, 4)]}])
    chest("temple", [
        {"rolls": 1, "entries": [entry(I("rocket_blueprint"))]},
        {"rolls": {"type": "minecraft:uniform", "min": 3, "max": 5}, "entries": [
            entry(I("titanium_ingot"), 1, 3, 20), entry(I("aluminum_ingot"), 2, 4, 20), entry(I("meteorite_shard"), 1, 3, 15),
            entry(I("circuit_board"), 1, 2, 15), entry(I("hydrogen_cell"), 1, 2, 10), entry(I("moonstone"), 1, 2, 8),
            entry(I("olivine"), 1, 2, 8), entry(I("lunar_alloy_ingot"), 1, 1, 4), entry(I("power_core"), 1, 1, 3)]}])
    chest("temple_minor", [{"rolls": {"type": "minecraft:uniform", "min": 2, "max": 3}, "entries": [
        entry(I("meteorite_shard"), 1, 2, 20), entry(I("moonstone"), 1, 1, 10), entry(I("olivine"), 1, 1, 10),
        entry(I("silver_ingot"), 1, 3, 10), entry(I("nickel_ingot"), 1, 3, 10), entry(I("lithium_ingot"), 1, 2, 8)]}])
    chest("outpost", [{"rolls": {"type": "minecraft:uniform", "min": 3, "max": 5}, "entries": [
        entry(I("iron_scrap"), 2, 5, 20), entry(I("oxygen_bottle_full"), 1, 2, 15), entry(I("circuit_board"), 1, 2, 15),
        entry(I("algae_bar"), 2, 4, 12), entry(I("energy_gel"), 1, 2, 10), entry(I("thermal_pack"), 1, 1, 5),
        entry(I("cooling_pack"), 1, 1, 5), entry(I("copper_ingot"), 2, 4, 10), entry(I("steel_ingot"), 1, 2, 6)]}])
    write_json(DATA / "loot_table" / "entities" / "dust_golem.json", {
        "type": "minecraft:entity", "random_sequence": f"{M}entities/dust_golem", "pools": [
            {"rolls": 1, "entries": [entry(I("meteorite_shard"), 1, 3)]},
            {"rolls": 1, "entries": [entry(I("iron_scrap"), 0, 2)]},
            {"rolls": 1, "entries": [entry(I("silicon"), 0, 2)]}]})
    write_json(DATA / "loot_table" / "entities" / "selenite.json", {
        "type": "minecraft:entity", "random_sequence": f"{M}entities/selenite", "pools": [
            {"rolls": 1, "entries": [entry(I("oxygen_bottle"), 0, 1)]},
            {"rolls": 1, "entries": [entry(I("moonstone"), 0, 1)]}]})


def tag(path, values):
    write_json(path, {"values": values})


def gen_tags():
    T = VANILLA_DATA / "tags" / "block"
    by = {"pickaxe": [], "shovel": []}
    needs = {"stone": [], "iron": [], "diamond": []}
    for b in C.BLOCKS:
        by[b["tool"]].append(M + b["name"])
        if b["need"] in needs:
            needs[b["need"]].append(M + b["name"])
    tag(T / "mineable" / "pickaxe.json", by["pickaxe"])
    tag(T / "mineable" / "shovel.json", by["shovel"])
    for k, v in needs.items():
        tag(T / f"needs_{k}_tool.json", v)
    tag(T / "supports_vegetation.json", [M + "hydrated_regolith"])
    tag(T / "dirt.json", [M + "hydrated_regolith"])
    IT_ = DATA / "tags" / "item"
    tag(IT_ / "lunar_tool_materials.json", [M + "lunar_rock"])
    tag(IT_ / "steel_repair.json", [M + "steel_ingot"])
    tag(IT_ / "titanium_repair.json", [M + "titanium_ingot"])
    tag(IT_ / "alloy_repair.json", [M + "lunar_alloy_ingot"])
    tag(IT_ / "aluminum_repair.json", [M + "aluminum_ingot"])
    for s in (("lab", "temple", "outpost", "crater") if LEVEL >= 1 else ()):
        tag(DATA / "tags" / "worldgen" / "biome" / "has_structure" / f"{s}.json", [M + "lunar_plains"])
    if LEVEL >= 2:
        tag(VANILLA_DATA / "tags" / "worldgen" / "world_preset" / "normal.json", [M + "lunaire", M + "lunaire_flat"])


def gen_recipes():
    for r in C.RECIPES:
        rid = r["result"].split(":")[1]
        res = {"id": r["result"], "count": r["n"]}
        if r["type"] == "shaped":
            used = set("".join(r["pattern"])) - {" "}
            data = {"type": "minecraft:crafting_shaped", "category": "misc", "pattern": r["pattern"],
                    "key": {k: v for k, v in r["key"].items() if k in used}, "result": res}
        else:
            data = {"type": "minecraft:crafting_shapeless", "category": "misc", "ingredients": r["ingredients"], "result": res}
        # un même résultat peut avoir plusieurs recettes (ex: lingot <- bloc) : nom unique
        name = rid
        p = DATA / "recipe" / f"{name}.json"
        k = 2
        while p.exists():
            name = f"{rid}_{k}"
            p = DATA / "recipe" / f"{name}.json"
            k += 1
        write_json(p, data)


# ============================================================================ MONDE

def sky_dimension_type():
    dt = json.loads((TOOLS / "overworld_dimtype.json").read_text(encoding="utf-8"))
    a = dt["attributes"]
    a["minecraft:visual/sky_color"] = "#000000"
    a["minecraft:visual/fog_color"] = "#020205"
    a["minecraft:visual/ambient_light_color"] = "#22252b"
    for k in ("minecraft:visual/cloud_color", "minecraft:visual/cloud_height"):
        a.pop(k, None)
    if LEVEL >= 3:
        mus = {"sound": "lunaire:music.moon", "min_delay": 1200, "max_delay": 4800}
        a["minecraft:audio/background_music"] = {"default": dict(mus), "creative": dict(mus)}
    a["minecraft:gameplay/bed_rule"] = {"can_set_spawn": "never", "can_sleep": "never", "destroy_on_use": False}
    dt["ambient_light"] = 0.08
    dt["timelines"] = "#lunaire:in_moon" if LEVEL >= 2 else "#minecraft:in_overworld"
    dt["monster_spawn_light_level"] = 15
    write_json(DATA / "dimension_type" / "moon.json", dt)


def sky_timeline():
    tl = json.loads((TOOLS / "day_timeline.json").read_text(encoding="utf-8"))
    tl.pop("time_markers", None)
    tracks = tl["tracks"]
    for k in ("minecraft:visual/sky_color", "minecraft:visual/fog_color", "minecraft:visual/cloud_color",
              "minecraft:visual/sunrise_sunset_color", "minecraft:visual/star_brightness", "minecraft:visual/moon_angle"):
        tracks.pop(k, None)
    tracks["minecraft:visual/star_brightness"] = {"keyframes": [{"ticks": 0, "value": 1.0}, {"ticks": 12000, "value": 1.0}]}
    tracks["minecraft:visual/sunrise_sunset_color"] = {"keyframes": [{"ticks": 0, "value": "#00000000"}, {"ticks": 12000, "value": "#00000000"}]}
    # la « lune » du ciel est la Terre : toujours pleine, fixe et haute dans le ciel
    tracks["minecraft:visual/moon_angle"] = {"keyframes": [{"ticks": 0, "value": 180.0}, {"ticks": 12000, "value": 180.0}]}
    tracks["minecraft:visual/moon_phase"] = {"keyframes": [{"ticks": 0, "value": "full_moon"}, {"ticks": 12000, "value": "full_moon"}]}
    write_json(DATA / "timeline" / "moon_day.json", tl)
    tag(DATA / "tags" / "timeline" / "in_moon.json", [M + "moon_day"])


def moon_world():
    sky_dimension_type()
    if LEVEL >= 2:
        sky_timeline()
    ns = json.loads((TOOLS / "overworld_noise_settings.json").read_text(encoding="utf-8"))
    ns["default_block"] = M + "lunar_rock"
    ns["default_fluid"] = "minecraft:air"
    ns["sea_level"] = -64
    ns["material_rule"] = M + "moon"
    write_json(DATA / "worldgen" / "noise_settings" / "moon.json", ns)
    write_json(DATA / "worldgen" / "material_rule" / "moon.json", {
        "type": "minecraft:sequence", "sequence": [
            "minecraft:bedrock_floor",
            {"type": "minecraft:condition", "if_true": {"type": "minecraft:above_preliminary_surface"},
             "then_run": {"type": "minecraft:condition", "if_true": "minecraft:under_floor",
                          "then_run": {"type": "minecraft:block", "result_state": M + "regolith"}}}]})

    ore_names = []

    def ore_feature(name, block, size, count, lo, hi):
        ore_names.append(M + name)
        write_json(DATA / "worldgen" / "feature" / f"{name}.json", {
            "type": "minecraft:ore", "discard_chance_on_air_exposure": 0.0, "size": size, "targets": [{
                "state": M + block,
                "target": {"predicate_type": "minecraft:block_match", "block": M + "lunar_rock"}}]})
        write_json(DATA / "worldgen" / "placed_feature" / f"{name}.json", {
            "feature": M + name, "placement": [
                {"type": "minecraft:count", "count": count}, {"type": "minecraft:in_square"},
                {"type": "minecraft:height_range", "height": {
                    "type": "minecraft:uniform", "min_inclusive": {"absolute": lo}, "max_inclusive": {"absolute": hi}}},
                {"type": "minecraft:biome"}]})

    for b in (C.BLOCKS if LEVEL >= 3 else []):
        if "ore" in b:
            o = b["ore"]
            ore_feature(b["name"], b["name"], o["size"], o["per_chunk"], o["y_min"], o["y_max"])
    if LEVEL >= 3:
        ore_feature("ore_lunar_ice", "lunar_ice", 12, 8, 30, 120)
        ore_feature("ice_surface", "lunar_ice", 5, 2, 40, 120)

    spawns = {k: [] for k in ("ambient", "axolotls", "creature", "misc", "monster", "underground_water_creature",
                              "water_ambient", "water_creature")}
    features = [[] for _ in range(11)]
    features[6] = ore_names
    write_json(DATA / "worldgen" / "biome" / "lunar_plains.json", {
        "attributes": {"minecraft:gameplay/natural_mob_spawns": {
            "argument": {"spawn_costs": {}, "spawns_by_category": spawns}, "modifier": "overlay"},
            "minecraft:visual/sky_color": "#000000", "minecraft:visual/fog_color": "#020205"},
        "carvers": [], "downfall": 0.0, "effects": {"water_color": "#3f76e4"}, "features": features,
        "has_precipitation": False, "temperature": 0.0})

    noise = {"type": M + "moon", "generator": {"type": "minecraft:noise", "settings": M + "moon",
                                               "biome_source": {"type": "minecraft:fixed", "biome": M + "lunar_plains"}}}
    flat = {"type": M + "moon", "generator": {"type": "minecraft:flat", "settings": {
        "biome": M + "lunar_plains", "features": False, "lakes": False,
        "layers": [{"block": "minecraft:bedrock", "height": 1}, {"block": M + "lunar_rock", "height": 59},
                   {"block": M + "regolith", "height": 4}],
        "structure_overrides": [M + "lab", M + "temple", M + "outpost", M + "crater"] if LEVEL >= 5 else []}}}
    write_json(DATA / "dimension" / "moon.json", noise)
    write_json(DATA / "dimension" / "moon_flat.json", flat)
    write_json(DATA / "dimension" / "earth.json", {
        "type": "minecraft:overworld",
        "generator": {"type": "minecraft:noise", "settings": "minecraft:overworld",
                      "biome_source": {"type": "minecraft:multi_noise", "preset": "minecraft:overworld"}}})

    def preset(overworld):
        return {"dimensions": {
            "minecraft:overworld": overworld,
            "minecraft:the_nether": {"type": "minecraft:the_nether", "generator": {
                "type": "minecraft:noise", "settings": "minecraft:nether",
                "biome_source": {"type": "minecraft:multi_noise", "preset": "minecraft:nether"}}},
            "minecraft:the_end": {"type": "minecraft:the_end", "generator": {
                "type": "minecraft:noise", "settings": "minecraft:end", "biome_source": {"type": "minecraft:the_end"}}}}}
    if LEVEL >= 2:
        write_json(DATA / "worldgen" / "world_preset" / "lunaire.json", preset(noise))
        write_json(DATA / "worldgen" / "world_preset" / "lunaire_flat.json", preset(flat))


def structure(name, step, start_h, adapt, salt, spacing, sep):
    write_json(DATA / "worldgen" / "template_pool" / f"{name}.json", {
        "elements": [{"element": {"element_type": "minecraft:single_pool_element", "location": f"{M}{name}",
                                  "processors": "minecraft:empty", "projection": "rigid"}, "weight": 1}],
        "fallback": "minecraft:empty"})
    write_json(DATA / "worldgen" / "structure" / f"{name}.json", {
        "type": "minecraft:jigsaw", "biomes": f"#{M}has_structure/{name}", "max_distance_from_center": 80,
        "project_start_to_heightmap": "WORLD_SURFACE_WG", "size": 1, "spawn_overrides": {},
        "start_height": {"absolute": start_h}, "start_pool": f"{M}{name}", "step": step,
        "terrain_adaptation": adapt, "use_expansion_hack": False})
    write_json(DATA / "worldgen" / "structure_set" / f"{name}.json", {
        "placement": {"type": "minecraft:random_spread", "salt": salt, "separation": sep, "spacing": spacing},
        "structures": [{"structure": f"{M}{name}", "weight": 1}]})


def gen_structures():
    ST.build_all()
    # start_height : décalage par rapport à la surface (fondations enterrées)
    structure("lab", "surface_structures", -2, "beard_thin", 91731, 9, 3)
    structure("temple", "underground_structures", -13, "none", 52817, 12, 4)
    structure("outpost", "surface_structures", -1, "beard_thin", 33119, 7, 2)
    structure("crater", "surface_structures", -5, "none", 77413, 6, 2)


# ============================================================================ MAIN

def main():
    bad = C.validate()
    if bad:
        raise SystemExit(f"Ingrédients inconnus : {bad}")
    for p in (RES / "assets", RES / "data", RES / "lunaire_content.json"):
        if p.is_dir():
            shutil.rmtree(p)
        elif p.exists():
            p.unlink()
    gen_assets()
    gen_java_content()
    X.gen_sun()
    if LEVEL >= 3:
        gen_loot()
        X.gen_advancements(structures=LEVEL >= 5)
        (ASSETS / "sounds" / "music").mkdir(parents=True, exist_ok=True)
        shutil.copy(TOOLS / "moon_drift.ogg", ASSETS / "sounds" / "music" / "moon_drift.ogg")
        write_json(ASSETS / "sounds.json", {"music.moon": {"sounds": [{"name": "lunaire:music/moon_drift", "stream": True}]}})
    gen_tags()
    if LEVEL >= 4:
        gen_recipes()
    if LEVEL >= 1:
        moon_world()
    if LEVEL >= 5:
        gen_structures()
    n = sum(1 for _ in RES.rglob("*") if _.is_file())
    print(f"Lunaire : {n} fichiers générés ({len(C.ITEMS)} objets, {len(C.BLOCKS)} blocs, {len(C.RECIPES)} recettes)")


if __name__ == "__main__":
    main()
