"""Textures de blocs, d'armures, de créatures et de la Terre (ciel)."""
import math
import random
from lg_core import Img, shade, noise_fill, ASSETS
from lg_tex import block_noise, craters, ore as _ore_old, panel, machine, solar_top, radiator

BT = ASSETS / "textures" / "block"
IT = ASSETS / "textures" / "item"
ET = ASSETS / "textures" / "entity"
ROCK = (88, 88, 96)
REGO = (176, 172, 166)


def ore_tex(color, seed, glow=False):
    img = block_noise("o", ROCK, 9, seed)
    craters(img, ROCK, seed, 1)
    rng = random.Random(seed * 13)
    for _ in range(7):
        cx, cy = rng.randint(1, 14), rng.randint(1, 14)
        for dx, dy in ((0, 0), (1, 0), (0, 1), (1, 1), (-1, 0), (0, -1)):
            if rng.random() < 0.8:
                c = shade(color, rng.randint(-20, 24))
                img.set(cx + dx, cy + dy, c)
        img.set(cx, cy, shade(color, 50))
    return img


def metal_block(c, seed):
    img = Img(16, 16)
    noise_fill(img, 0, 0, 16, 16, c, 6, seed)
    for i in range(16):
        for k in (0, 15):
            img.set(i, k, shade(c, -45)), img.set(k, i, shade(c, -45))
        img.set(i, 1, shade(c, 30)), img.set(1, i, shade(c, 25))
    for y in (4, 11):
        for x in range(2, 14):
            img.set(x, y, shade(c, -22))
    for p in ((3, 3), (12, 3), (3, 12), (12, 12)):
        img.set(*p, shade(c, 55))
    return img


def bricks(base, seed, mortar=(50, 50, 56)):
    img = Img(16, 16)
    noise_fill(img, 0, 0, 16, 16, base, 8, seed)
    for y in range(16):
        for x in range(16):
            if y % 4 == 3 or (x + (4 if (y // 4) % 2 else 0)) % 8 == 7:
                img.set(x, y, mortar)
    return img


def glass(tint, frame):
    img = Img(16, 16)
    for y in range(16):
        for x in range(16):
            edge = x in (0, 15) or y in (0, 15)
            if edge:
                img.set(x, y, frame)
            elif (x + y) % 7 == 0 and 2 <= x <= 7:
                img.set(x, y, (255, 255, 255, 140))
            else:
                img.set(x, y, tint)
    return img


def draw_blocks(blocks):
    def B(n, im):
        im.save(BT / f"{n}.png")

    for b in blocks:
        n, t = b["name"], b["texture"]
        seed = sum(map(ord, n))
        if t == "ore":
            B(n, ore_tex(b["color"], seed))
        elif t == "regolith":
            B(n, craters(_rich(REGO, 21, 9, ((205, 202, 196), 14), ((96, 92, 88), 14), 0, 7), REGO, 2, 2))
        elif t == "hydrated":
            h = block_noise("hr", (120, 112, 105), 12, 4)
            for i in range(0, 16, 3):
                h.set(i, (i * 5) % 16, (70, 150, 220))
            B(n, h)
        elif t == "rock":
            B(n, craters(_rich(ROCK, 31, 9, ((170, 168, 164), 10), ((70, 68, 66), 12), 0, 4), ROCK, 5, 2))
        elif t == "ice":
            ice = block_noise("i", (170, 215, 240), 14, 6)
            for i in range(16):
                ice.set(i, (i * 3 + 2) % 16, (235, 248, 255))
            B(n, ice)
        elif t == "polished":
            im = block_noise("p", (110, 110, 120), 4, 7)
            for i in range(16):
                im.set(i, 0, (150, 150, 160)), im.set(0, i, (150, 150, 160)), im.set(i, 15, (70, 70, 80)), im.set(15, i, (70, 70, 80))
            B(n, im)
        elif t == "bricks_rock":
            B(n, bricks(ROCK, 8))
        elif t == "bricks_rego":
            B(n, bricks((150, 146, 140), 9, (90, 86, 82)))
        elif t == "glass":
            B(n, glass((190, 225, 245, 70), (210, 225, 235, 255)))
        elif t == "glass_r":
            im = glass((170, 215, 245, 90), (110, 120, 140, 255))
            for i in range(16):
                im.set(i, 7, (110, 120, 140, 255)), im.set(7, i, (110, 120, 140, 255))
            B(n, im)
        elif t == "meteor":
            im = block_noise("m", (60, 40, 90), 12, 11)
            for i in range(10):
                im.set((i * 7) % 16, (i * 5 + 3) % 16, (190, 140, 255))
            B(n, im)
        elif t == "metal":
            from lg_content import MAT
            B(n, metal_block(MAT[b["mat"]], seed))
        elif t == "lab_plating":
            B(n, panel((205, 208, 214), (120, 124, 135)))
        elif t == "lab_floor":
            im = block_noise("f", (150, 156, 168), 4, 14)
            for i in range(16):
                im.set(i, 0, (100, 106, 118)), im.set(0, i, (100, 106, 118))
                if i % 4 == 0:
                    im.set(i, 8, (110, 116, 128)), im.set(8, i, (110, 116, 128))
            B(n, im)
        elif t == "lab_light":
            im = Img(16, 16)
            noise_fill(im, 0, 0, 16, 16, (250, 245, 210), 6, 15)
            for i in range(16):
                for k in (0, 15):
                    im.set(i, k, (150, 150, 160)), im.set(k, i, (150, 150, 160))
            B(n, im)
        elif t == "lab_vent":
            im = block_noise("v", (130, 135, 145), 4, 16)
            for y in range(2, 14, 2):
                im.rect(2, y, 12, 1, (40, 42, 50))
            B(n, im)
        elif t == "ancient":
            B(n, panel((120, 105, 90), (70, 60, 50), 5))
        elif t == "ancient_bricks":
            B(n, bricks((125, 108, 90), 17, (70, 58, 48)))
        elif t == "glyph":
            im = bricks((125, 108, 90), 18, (70, 58, 48))
            for (x, y) in ((6, 4), (7, 4), (8, 4), (6, 5), (8, 5), (7, 6), (6, 7), (7, 7), (8, 7), (7, 8), (7, 9), (6, 10), (8, 10)):
                im.set(x, y, (90, 230, 255))
            B(n, im)
        elif t == "launch":
            B(n, panel((70, 72, 80), (230, 190, 40), 6))
        elif t.startswith("st_"):
            B(n, stone_tex(t[3:], seed))
        elif t.startswith("m_"):
            machine_tex(n, t)
    return


# ------------------------------------------------------------------ v0.4 : pierres variées, textures plus riches

def _rich(base, seed, var=9, speck=None, dark=None, cracks=0, grain=0):
    """Pierre à plusieurs couches : bruit large + grain fin + éclats + fissures."""
    rng = random.Random(seed)
    img = Img(16, 16)
    coarse = _vnoise(16, 16, 5, seed)
    for y in range(16):
        for x in range(16):
            v = (coarse(x, y) - 0.5) * 2 * var + rng.uniform(-grain, grain) - 0
            img.set(x, y, tuple(max(0, min(255, base[i] + v + rng.uniform(-var / 3, var / 3))) for i in range(3)))
    for _ in range(int(speck[1]) if speck else 0):
        img.set(rng.randint(0, 15), rng.randint(0, 15), speck[0])
    for _ in range(int(dark[1]) if dark else 0):
        img.set(rng.randint(0, 15), rng.randint(0, 15), dark[0])
    for _ in range(cracks):
        x, y = rng.randint(2, 13), rng.randint(0, 5)
        for k in range(rng.randint(5, 10)):
            img.set(x, y, shade(base, -55))
            y += 1
            x += rng.choice((-1, 0, 0, 1))
    return img


def _frame(img, light, dark):
    for i in range(16):
        img.set(i, 0, light), img.set(0, i, light), img.set(i, 15, dark), img.set(15, i, dark)
    return img


def stone_tex(key, seed):
    if key == "anorthosite":
        return _rich((200, 200, 196), seed, 8, ((235, 235, 230), 10), ((150, 150, 150), 8), 0, 3)
    if key == "polished_anorthosite":
        return _frame(_rich((212, 212, 208), seed, 4, ((245, 245, 242), 6), None, 0, 1), (240, 240, 238), (165, 165, 165))
    if key == "anorthosite_bricks":
        return bricks((205, 205, 200), seed, (130, 130, 135))
    if key == "mare_basalt":
        return _rich((58, 62, 78), seed, 9, ((110, 125, 160), 7), ((28, 30, 40), 12), 0, 3)
    if key == "polished_mare_basalt":
        return _frame(_rich((66, 70, 88), seed, 4, ((125, 140, 175), 5), None, 0, 1), (110, 118, 145), (35, 37, 50))
    if key == "mare_basalt_bricks":
        return bricks((60, 64, 80), seed, (28, 30, 40))
    if key == "tektite":
        im = _rich((28, 44, 36), seed, 6, ((120, 230, 160), 9), ((10, 16, 12), 8), 0, 2)
        for i in range(0, 16, 5):
            im.set(i, (i * 3) % 16, (170, 255, 200))
        return im
    if key == "lunar_dust":
        return _rich((150, 145, 140), seed, 10, ((190, 186, 180), 24), ((100, 96, 92), 18), 0, 8)
    if key == "cracked":
        return _rich((118, 116, 112), seed, 8, None, ((60, 58, 56), 10), 3, 3)
    if key == "impact_glass":
        im = glass((170, 230, 190, 80), (60, 110, 85, 255))
        for i in range(2, 14, 4):
            im.set(i, i, (230, 255, 240, 200)), im.set(i + 1, i, (230, 255, 240, 140))
        return im
    if key == "lantern":
        im = Img(16, 16)
        noise_fill(im, 0, 0, 16, 16, (255, 236, 170), 10, seed)
        for y in range(16):
            for x in range(16):
                d = max(abs(x - 7.5), abs(y - 7.5))
                if d > 5.5:
                    im.set(x, y, (255, 250, 215))
        _frame(im, (120, 125, 140), (70, 74, 86))
        for i in (5, 10):
            for k in range(16):
                im.set(i, k, (120, 125, 140)), im.set(k, i, (120, 125, 140))
        return im
    if key == "olivine_block":
        im = _rich((95, 170, 70), seed, 12, ((190, 255, 130), 14), ((50, 100, 40), 10), 0, 3)
        return _frame(im, (160, 230, 110), (55, 110, 45))
    if key == "moonstone_block":
        im = _rich((150, 190, 245), seed, 10, ((245, 250, 255), 16), ((95, 135, 205), 10), 0, 3)
        return _frame(im, (225, 240, 255), (90, 125, 190))
    return _rich((128, 128, 128), seed)


def machine_tex(n, t):
    def B(name, im):
        im.save(BT / f"{name}.png")
    if t == "m_solar":
        B("solar_panel_top", solar_top())
        B("solar_panel_side", machine((170, 172, 180), (60, 90, 190), 12, "none"))
    elif t == "m_sealer":
        B("atmosphere_sealer_top", machine((150, 160, 170), (80, 200, 220), 13, "top"))
        B("atmosphere_sealer_side", machine((150, 160, 170), (80, 200, 220), 13, "front"))
    elif t == "m_electro":
        B("electrolyzer_top", machine((140, 140, 150), (70, 140, 230), 14, "top"))
        B("electrolyzer_side", machine((140, 140, 150), (70, 140, 230), 14, "front"))
    elif t == "m_compressor":
        B("oxygen_compressor_top", machine((135, 145, 155), (120, 220, 255), 19, "top"))
        B("oxygen_compressor_side", machine((135, 145, 155), (120, 220, 255), 19, "front"))
    elif t == "m_hydrogen":
        B("hydrogen_generator_top", machine((130, 130, 140), (200, 200, 90), 15, "top"))
        B("hydrogen_generator_side", machine((130, 130, 140), (90, 90, 90), 15, "front"))
        B("hydrogen_generator_side_lit", machine((130, 130, 140), (255, 200, 60), 15, "front"))
    elif t == "m_radiator":
        B("radiator", radiator(False))
        B("radiator_lit", radiator(True))


# ------------------------------------------------------------------ armures (calques 64x32)

SUITS = {
    "survival_suit": ((235, 140, 60), (250, 245, 235), (255, 230, 120)),
    "spacesuit": ((205, 210, 222), (120, 130, 150), (240, 190, 60)),
    "orbital_suit": ((235, 238, 245), (40, 48, 70), (90, 230, 255)),
}


def armor_layers():
    for suit, (main, dark, glow) in SUITS.items():
        for layer in ("humanoid", "humanoid_leggings"):
            img = Img(64, 32)
            noise_fill(img, 0, 0, 64, 32, main, 7, sum(map(ord, suit)))
            for x in range(64):
                for y in (7, 15, 23, 31):
                    img.set(x, y, dark)
            for x in range(0, 64, 8):
                for y in range(32):
                    if y % 3 == 0:
                        img.set(x, y, shade(main, -25))
            if layer == "humanoid":
                img.rect(9, 10, 6, 3, glow)       # visière
                img.rect(10, 11, 4, 1, shade(glow, 60))
                img.rect(20, 20, 8, 2, glow)      # plastron
                img.rect(22, 22, 4, 4, dark)
                img.rect(23, 23, 2, 2, glow)
            img.save(ET / "equipment" / layer / f"{suit}.png")


# ------------------------------------------------------------------ créatures

def creatures():
    img = Img(64, 64)
    noise_fill(img, 0, 0, 64, 64, (150, 215, 235), 18, 41)
    for x in range(0, 64, 4):
        for y in range(64):
            if (x + y) % 9 == 0:
                img.set(x, y, (235, 250, 255))
    img.rect(10, 12, 2, 2, (255, 255, 120))
    img.rect(13, 12, 2, 2, (255, 255, 120))
    img.rect(11, 14, 3, 1, (60, 100, 130))
    img.save(ET / "selenite.png")
    g = Img(64, 64)
    noise_fill(g, 0, 0, 64, 64, (110, 100, 92), 16, 42)
    for x in range(64):
        for y in range(64):
            if (x * 3 + y * 5) % 11 == 0:
                g.set(x, y, (75, 68, 62))
    g.rect(10, 12, 2, 2, (255, 150, 40))
    g.rect(13, 12, 2, 2, (255, 150, 40))
    g.rect(20, 22, 8, 4, (255, 140, 40))
    g.save(ET / "dust_golem.png")


# ------------------------------------------------------------------ la Terre dans le ciel

def _vnoise(w, h, cell, seed):
    rng = random.Random(seed)
    gw, gh = w // cell + 2, h // cell + 2
    grid = [[rng.random() for _ in range(gw)] for _ in range(gh)]

    def sm(t):
        return t * t * (3 - 2 * t)

    def f(x, y):
        gx, gy = max(0.0, min(x / cell, gw - 2.001)), max(0.0, min(y / cell, gh - 2.001))
        x0, y0 = int(gx), int(gy)
        tx, ty = sm(gx - x0), sm(gy - y0)
        a = grid[y0][x0] * (1 - tx) + grid[y0][x0 + 1] * tx
        b = grid[y0 + 1][x0] * (1 - tx) + grid[y0 + 1][x0 + 1] * tx
        return a * (1 - ty) + b * ty
    return f


def earth(size=128):
    img = Img(size, size)
    n1, n2, n3 = _vnoise(size, size, 32, 1), _vnoise(size, size, 16, 2), _vnoise(size, size, 8, 3)
    c1, c2 = _vnoise(size, size, 24, 7), _vnoise(size, size, 10, 8)
    r = size / 2 - 2
    for y in range(size):
        for x in range(size):
            dx, dy = (x - size / 2 + 0.5) / r, (y - size / 2 + 0.5) / r
            d2 = dx * dx + dy * dy
            if d2 > 1.0:
                continue
            z = math.sqrt(1 - d2)
            # coordonnées « sphériques » pour déformer les continents
            u, v = x + dx * dx * 6 * (1 if dx > 0 else -1), y
            h = 0.55 * n1(u, v) + 0.3 * n2(u, v) + 0.15 * n3(u, v)
            lat = abs(dy)
            if h > 0.52:
                t = (h - 0.52) / 0.3
                col = (60 + 70 * t, 140 - 30 * t, 60 + 10 * t)
                if lat < 0.35 and h > 0.62:
                    col = (200, 170, 100)
            else:
                t = h / 0.52
                col = (15 + 30 * t, 50 + 70 * t, 140 + 60 * t)
            if lat > 0.86:
                col = (240, 245, 250)
            cl = 0.6 * c1(u + 11, v + 5) + 0.4 * c2(u, v)
            if cl > 0.58:
                a = min(1.0, (cl - 0.58) / 0.15) * 0.85
                col = tuple(col[i] * (1 - a) + 250 * a for i in range(3))
            light = 0.55 + 0.45 * (z * 0.8 + (-dx * 0.35 + -dy * 0.35))
            col = tuple(c * min(1.15, max(0.35, light)) for c in col)
            rim = max(0.0, (math.sqrt(d2) - 0.85) / 0.15)
            col = (col[0] * (1 - rim * 0.5) + 120 * rim * 0.5, col[1] * (1 - rim * 0.5) + 170 * rim * 0.5, col[2] * (1 - rim * 0.5) + 255 * rim * 0.5)
            img.set(x, y, col)
    return img
