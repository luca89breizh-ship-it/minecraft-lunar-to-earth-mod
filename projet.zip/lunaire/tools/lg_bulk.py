"""Contenu en masse (v0.6) : matériaux d'outils/armures, composants de fusée, blocs de construction, couleurs, minerais,
nourriture, objets de mobs, œufs. Tout est généré par tables."""
import random
import lg_content as C
from lg_content import item, block, RECIPES, M, MAT
import lg_blocks as BL
import lg_mobs as MB
from lg_core import Img, shade

I = lambda x: M + x

# ---------------------------------------------------------------------------- matériaux d'outils / armures (lus par Java)
# mat: tier (stone/iron/diamond), durabilité, vitesse, dégâts, enchantement, objet de réparation, couleur du sprite, fr, en
TOOL_MATS = {
    "lunar_rock": ("stone", 131, 4.0, 1.0, 5, "lunar_tool_materials", (120, 120, 132), "roche lunaire", "Lunar Rock"),
    "steel": ("iron", 450, 6.5, 2.0, 12, "steel_repair", (125, 132, 145), "acier", "Steel"),
    "titanium": ("diamond", 1100, 8.0, 3.0, 14, "titanium_repair", (130, 160, 215), "titane", "Titanium"),
    "lunar_alloy": ("diamond", 2200, 9.5, 4.0, 18, "alloy_repair", (80, 140, 200), "alliage lunaire", "Lunar Alloy"),
    "bronze": ("iron", 280, 5.5, 2.0, 10, "bronze_repair", (195, 135, 60), "bronze", "Bronze"),
    "aluminum": ("stone", 190, 7.0, 1.5, 18, "aluminum_repair", (215, 222, 235), "aluminium", "Aluminum"),
    "nickel": ("iron", 320, 5.5, 2.0, 10, "nickel_repair", (170, 178, 150), "nickel", "Nickel"),
    "silver": ("stone", 100, 12.0, 0.5, 22, "silver_repair", (228, 232, 242), "argent", "Silver"),
    "olivine": ("diamond", 1000, 8.0, 3.0, 18, "olivine_repair", (110, 190, 80), "olivine", "Olivine"),
    "moonstone": ("diamond", 1350, 8.5, 3.5, 25, "moonstone_repair", (150, 190, 245), "pierre de lune", "Moonstone"),
    "meteorite": ("diamond", 2600, 9.5, 4.5, 15, "meteorite_repair", (150, 100, 220), "météorite", "Meteorite"),
    "tektite": ("iron", 700, 7.0, 2.5, 12, "tektite_repair", (50, 110, 80), "tectite", "Tektite"),
}
TOOL_REPAIR = {"bronze": "bronze_ingot", "aluminum": "aluminum_ingot", "nickel": "nickel_ingot", "silver": "silver_ingot",
               "olivine": "olivine", "moonstone": "moonstone", "meteorite": "meteorite_shard", "tektite": "tektite"}

# suit: durabilité, défense [bottes, jambières, plastron, casque], enchantement, robustesse, recul, réparation
ARMOR_MATS = {
    "survival_suit": (12, [1, 2, 3, 1], 8, 0.0, 0.0, "aluminum_repair"),
    "spacesuit": (26, [2, 5, 6, 2], 12, 1.0, 0.0, "steel_repair"),
    "orbital_suit": (38, [3, 6, 8, 3], 16, 2.5, 0.1, "titanium_repair"),
    "bronze_armor": (15, [2, 5, 6, 2], 9, 0.0, 0.0, "bronze_repair"),
    "aluminum_armor": (11, [1, 4, 5, 2], 18, 0.0, 0.0, "aluminum_repair"),
    "titanium_armor": (33, [3, 6, 8, 3], 14, 1.0, 0.0, "titanium_repair"),
    "olivine_armor": (36, [3, 6, 8, 3], 20, 1.5, 0.0, "olivine_repair"),
    "moonstone_armor": (38, [3, 6, 8, 3], 28, 1.0, 0.0, "moonstone_repair"),
    "tektite_armor": (30, [3, 6, 7, 3], 12, 0.5, 0.05, "tektite_repair"),
    "alloy_armor": (40, [3, 6, 8, 3], 18, 2.0, 0.0, "alloy_repair"),
    "meteorite_armor": (44, [4, 7, 9, 4], 15, 3.0, 0.1, "meteorite_repair"),
}
# (ingrédient, fr, en, couleurs sprite/skin (principal, sombre, lueur))
NEW_ARMOR = {
    "bronze_armor": ("bronze_ingot", "bronze", "Bronze", ((195, 135, 60), (120, 80, 30), (255, 210, 120))),
    "aluminum_armor": ("aluminum_plate", "aluminium", "Aluminum", ((215, 222, 235), (130, 140, 160), (170, 220, 255))),
    "titanium_armor": ("titanium_plate", "titane", "Titanium", ((125, 150, 195), (60, 80, 120), (190, 230, 255))),
    "olivine_armor": ("olivine", "olivine", "Olivine", ((110, 190, 80), (50, 110, 40), (210, 255, 130))),
    "moonstone_armor": ("moonstone", "pierre de lune", "Moonstone", ((150, 190, 245), (80, 110, 190), (255, 255, 255))),
    "tektite_armor": ("tektite", "tectite", "Tektite", ((40, 80, 60), (20, 44, 34), (120, 255, 170))),
    "alloy_armor": ("lunar_alloy_plate", "alliage lunaire", "Lunar Alloy", ((70, 120, 170), (30, 56, 90), (120, 220, 255))),
    "meteorite_armor": ("meteorite_shard", "météorite", "Meteorite", ((90, 60, 130), (40, 26, 66), (230, 150, 255))),
}

COLORS = [  # nom, fr, en, rgb, teinture vanille
    ("white", "blanc", "White", (235, 238, 240), "white"), ("orange", "orange", "Orange", (240, 130, 40), "orange"),
    ("magenta", "magenta", "Magenta", (200, 70, 200), "magenta"), ("light_blue", "bleu clair", "Light Blue", (90, 170, 235), "light_blue"),
    ("yellow", "jaune", "Yellow", (245, 215, 60), "yellow"), ("lime", "vert clair", "Lime", (130, 205, 50), "lime"),
    ("pink", "rose", "Pink", (240, 150, 185), "pink"), ("gray", "gris", "Gray", (90, 95, 100), "gray"),
    ("light_gray", "gris clair", "Light Gray", (160, 165, 170), "light_gray"), ("cyan", "cyan", "Cyan", (40, 150, 170), "cyan"),
    ("purple", "violet", "Purple", (130, 60, 180), "purple"), ("blue", "bleu", "Blue", (50, 75, 190), "blue"),
    ("brown", "marron", "Brown", (120, 80, 50), "brown"), ("green", "vert", "Green", (75, 120, 50), "green"),
    ("red", "rouge", "Red", (190, 50, 45), "red"), ("black", "noir", "Black", (30, 32, 38), "black"),
]

_PAGES = [
    "§lGuide de Lunaire§r\n\nBienvenue sur la Lune !\nIci : pas d'air, un soleil brûlant le jour, un froid glacial la nuit.\n\nBut : survivre, bâtir une base... et rentrer sur Terre en fusée.",
    "§lOxygène§r\n\nHors d'un habitat, votre O₂ baisse. Rechargez avec réservoirs, bouteilles ou surpresseur (clic droit). Le scanner d'oxygène indique votre niveau. L'épurateur d'air ralentit la perte.",
    "§lBase étanche§r\n\nFermez une pièce (verre renforcé, plaques de labo). Posez un régulateur d'atmosphère : il dit si la pièce est étanche. Dedans, l'oxygène remonte.",
    "§lCombinaisons§r\n\nSurvie, spatiale, orbitale : chaque pièce réduit la perte d'O₂ et la chaleur. Complète, elle protège du Soleil et du froid. Sinon : bouclier solaire ou cryogénique.",
    "§lSoleil et froid§r\n\nEn plein soleil sans protection vous brûlez (doucement). La nuit lunaire est glaciale. Bonne nouvelle : la gravité est faible, pas de dégâts de chute !",
    "§lLe ciel§r\n\nLa Terre brille, immense et immobile. Jupiter, Saturne, Mars, Vénus, Mercure et Neptune glissent lentement dans le ciel noir.",
    "§lBiomes§r\n\nPlaines lunaires, hautes terres claires, mer de basalte sombre, calotte glaciaire, champs d'olivine, champs de météorites, dunes de poussière.",
    "§lStructures§r\n\nLaboratoires abandonnés, avant-postes, temples anciens enterrés (cherchez l'obélisque), cratères à météorite et petits lacs gris-bleu. Les coffres cachent du butin.",
    "§lLacs et animaux§r\n\nPêchez dans les lacs : poisson lunaire. Donnez-en à un chat lunaire pour l'adopter. Un chien astro s'adopte avec un os. Les animaux adoptés vous suivent.",
    "§lOutils et armures§r\n\nPierre lunaire, acier, titane, alliage, bronze, olivine... Fondez les minerais, forgez plaques et tiges. Propulseur dorsal : clic droit pour voler droit devant.",
    "§lRentrer sur Terre§r\n\nIl faut : schéma de fusée (Tier 3), moteur de fusée, étage propulseur, grand réservoir, 3 carburants de fusée, et le module de rentrée EN MAIN. Clic droit sur la plateforme de lancement.",
    "§lAstuces§r\n\nRetour sur la Lune :\n/execute in lunaire:moon run tp @s 0 150 0\n\nRetour sur Terre :\n/execute in minecraft:overworld run tp @s 0 100 0",
]
GUIDE_NBT = '{title:"Guide de Lunaire",author:"Lunaire",pages:[' + ",".join('"' + p + '"' for p in _PAGES) + ']}'


def build():
    R = RECIPES

    def shaped(result, pattern, key, n=1):
        R.append(dict(type="shaped", result=result, pattern=pattern, key=key, n=n))

    def shapeless(result, ings, n=1):
        R.append(dict(type="shapeless", result=result, ingredients=ings, n=n))

    def cook(result, ingredient, xp=0.7, time=200, cat="misc"):
        R.append(dict(type="cooking", result=result, ingredient=ingredient, xp=xp, time=time, cat=cat, n=1))

    C.KNOWN_VANILLA.update({"minecraft:iron_ingot", "minecraft:book"} | {f"minecraft:{c[4]}_dye" for c in COLORS})

    # ================================================================ outils des nouveaux matériaux
    for mat, (tier, dur, spd, dmg, ench, repair, col, fr, en) in TOOL_MATS.items():
        if mat in ("lunar_rock", "steel", "titanium", "lunar_alloy"):
            continue
        ing = TOOL_REPAIR[mat]
        for t, tfr, ten, pat in (("pickaxe", "Pioche", "Pickaxe", ["III", " S ", " S "]), ("axe", "Hache", "Axe", ["II", "IS", " S"]),
                                 ("shovel", "Pelle", "Shovel", ["I", "S", "S"]), ("sword", "Épée", "Sword", ["I", "I", "S"]),
                                 ("hoe", "Houe", "Hoe", ["II", " S", " S"])):
            item(f"{mat}_{t}", f"{tfr} en {fr}", f"{en} {ten}", tool=t, mat=mat, stack=1)
            shaped(I(f"{mat}_{t}"), pat, {"I": I(ing), "S": I("steel_rod")})

    # ================================================================ armures des nouveaux matériaux
    for suit, (ing, fr, en, cols) in NEW_ARMOR.items():
        BL.SUITS[suit] = cols
        for slot, sfr, sen, pat in (("helmet", "Casque", "Helmet", ["III", "I I"]), ("chestplate", "Plastron", "Chestplate", ["I I", "III", "III"]),
                                    ("leggings", "Jambières", "Leggings", ["III", "I I", "I I"]), ("boots", "Bottes", "Boots", ["I I", "I I"])):
            item(f"{suit}_{slot}", f"{sfr} en {fr}", f"{en} {sen}", armor=slot, suit=suit, stack=1)
            shaped(I(f"{suit}_{slot}"), pat, {"I": I(ing)})

    # ================================================================ pépites, engrenages, tiges, fils
    for m, fr, en in (("copper", "cuivre", "Copper"), ("tin", "étain", "Tin"), ("aluminum", "aluminium", "Aluminum"),
                      ("titanium", "titane", "Titanium"), ("nickel", "nickel", "Nickel"), ("silver", "argent", "Silver"),
                      ("lithium", "lithium", "Lithium"), ("steel", "acier", "Steel"), ("bronze", "bronze", "Bronze"),
                      ("lunar_alloy", "alliage lunaire", "Lunar Alloy")):
        item(f"{m}_nugget", f"Pépite de {fr}", f"{en} Nugget", shape="nugget", color=MAT[m])
        shapeless(I(f"{m}_nugget"), [I(f"{m}_ingot")], 9)
        shaped(I(f"{m}_ingot"), ["NNN", "NNN", "NNN"], {"N": I(f"{m}_nugget")}) if m not in ("copper",) else None
        if m == "copper":
            shapeless(I("copper_ingot"), [I("copper_nugget")] * 9)
    for m, fr, en in (("nickel", "nickel", "Nickel"), ("silver", "argent", "Silver"), ("lunar_alloy", "alliage lunaire", "Lunar Alloy"),
                      ("tin", "étain", "Tin"), ("lithium", "lithium", "Lithium")):
        item(f"{m}_gear", f"Engrenage en {fr}", f"{en} Gear", form="gear", mat=m)
        shaped(I(f"{m}_gear"), [" I ", "I I", " I "], {"I": I(f"{m}_ingot")})
    for m, fr, en in (("lunar_alloy", "alliage lunaire", "Lunar Alloy"), ("bronze", "bronze", "Bronze"), ("copper", "cuivre", "Copper"),
                      ("nickel", "nickel", "Nickel"), ("tin", "étain", "Tin"), ("silver", "argent", "Silver")):
        item(f"{m}_rod", f"Tige de {fr}", f"{en} Rod", form="rod", mat=m)
        shaped(I(f"{m}_rod"), ["I", "I"], {"I": I(f"{m}_ingot")}, 2)
    for m, fr, en in (("tin", "étain", "Tin"), ("nickel", "nickel", "Nickel"), ("titanium", "titane", "Titanium"),
                      ("steel", "acier", "Steel"), ("bronze", "bronze", "Bronze")):
        item(f"{m}_wire", f"Fil de {fr}", f"{en} Wire", form="wire", mat=m)
        shaped(I(f"{m}_wire"), ["II"], {"I": I(f"{m}_plate")} if m in ("steel", "bronze", "titanium", "nickel") else {"I": I(f"{m}_ingot")}, 4) if m != "tin" else shaped(I("tin_wire"), ["II"], {"I": I("tin_ingot")}, 3)

    # ================================================================ drops de créatures
    DROPS = [
        ("selenite_shard", "Éclat de sélénite", "Selenite Shard", "crystal", (150, 215, 235), (255, 255, 200)),
        ("void_essence", "Essence du vide", "Void Essence", "orb", (110, 50, 200), (255, 150, 255)),
        ("chitin_plate", "Plaque de chitine", "Chitin Plate", "shell", (115, 104, 98), (60, 54, 50)),
        ("dust_core", "Noyau de poussière", "Dust Core", "core", (190, 180, 165), (255, 255, 255)),
        ("bot_scrap", "Débris de robot", "Bot Scrap", "chunk", (130, 134, 144), (255, 160, 50)),
        ("cryo_gel", "Gel cryogénique", "Cryo Gel", "jar", (140, 215, 250), (190, 230, 250)),
        ("sun_ember", "Braise solaire", "Sun Ember", "orb", (255, 160, 50), (255, 240, 120)),
        ("bio_sample", "Échantillon biologique", "Bio Sample", "jar", (110, 220, 110), (180, 190, 200)),
        ("ancient_core", "Noyau ancien", "Ancient Core", "core", (255, 200, 60), (120, 90, 30)),
        ("overseer_chip", "Puce du superviseur", "Overseer Chip", "chip", (60, 70, 100), (255, 60, 60)),
        ("moon_fluff", "Duvet lunaire", "Moon Fluff", "fluff", (240, 240, 250), (200, 200, 225)),
        ("glow_dust", "Poussière lumineuse", "Glow Dust", "dust", (140, 255, 170), (255, 255, 160)),
        ("crystal_shell", "Carapace de cristal", "Crystal Shell", "shell", (130, 180, 235), (230, 245, 255)),
        ("tortoise_shell", "Carapace de tortue", "Tortoise Shell", "shell", (110, 132, 100), (230, 210, 140)),
        ("geode_slime", "Gelée de géode", "Geode Slime", "jar", (190, 110, 210), (255, 200, 255)),
    ]
    for n, fr, en, shp, c1, c2 in DROPS:
        item(n, fr, en, shape=shp, color=c1, color2=c2)
    item("moon_meat", "Viande lunaire crue", "Raw Moon Meat", shape="meat", color=(200, 90, 100), color2=(235, 170, 170), stack=16,
         use=dict(cmds=["effect give %p minecraft:saturation 1 1 true", "effect give %p minecraft:nausea 6 0 true"], msg="Beurk, c'est cru."))
    item("cooked_moon_meat", "Steak lunaire", "Moon Steak", shape="meat", color=(150, 90, 55), color2=(90, 55, 30), stack=16,
         use=dict(cmds=["effect give %p minecraft:saturation 1 8 true"], msg="Délicieux."))
    cook(I("cooked_moon_meat"), I("moon_meat"), 0.35, 200, "food")
    # utilité des drops
    shapeless(I("iron_scrap"), [I("bot_scrap")] * 2, 2)
    shapeless(I("insulation"), [I("moon_fluff")] * 3, 2)
    shapeless(I("cooling_pack"), [I("cryo_gel")] * 2 + [I("aluminum_plate")])
    shapeless(I("thermal_pack"), [I("sun_ember")] * 2 + [I("insulation")])
    shapeless(I("moonstone"), [I("selenite_shard")] * 4)
    shapeless(I("night_vision_pill"), [I("glow_dust")] * 2 + [I("olivine")], 2)
    shaped(I("medkit"), ["BCB", "GMG"], {"B": I("bio_sample"), "C": I("circuit_board"), "G": I("geode_slime"), "M": I("steel_plate")})
    shapeless(I("impact_glass"), [I("crystal_shell"), I("tektite")], 2)
    item("ancient_seal", "Sceau ancien", "Ancient Seal", shape="ring", color=(255, 200, 60), color2=(120, 90, 30), stack=1,
         use=dict(cmds=["execute as %p at @s run summon lunaire:ancient_warden ~ ~ ~5"], msg="Le gardien s'éveille..."))
    shaped(I("ancient_seal"), ["MAM", "ACA", "MAM"], {"M": I("moonstone"), "A": I("ancient_bricks"), "C": I("ancient_core")})
    item("overseer_key", "Clé du superviseur", "Overseer Key", shape="card", color=(60, 70, 100), color2=(255, 60, 60), stack=1,
         use=dict(cmds=["execute as %p at @s run summon lunaire:lab_overseer ~ ~ ~5"], msg="Alerte : le superviseur se réveille."))
    shaped(I("overseer_key"), ["CPC", "AOA"], {"C": I("advanced_circuit"), "P": I("processor"), "A": I("lab_plating"), "O": I("overseer_chip")})

    # ================================================================ composants de fusée
    PARTS = [
        ("combustion_chamber", "Chambre de combustion", "Combustion Chamber", "gadget", (190, 190, 205), (255, 140, 40),
         ["TTT", "T T", "TST"], {"T": "titanium_plate", "S": "steel_gear"}, 1),
        ("nozzle_bell", "Tuyère", "Nozzle Bell", "nozzle", (160, 165, 180), (255, 120, 40),
         ["PTP", " P "], {"P": "lunar_alloy_plate", "T": "thruster"}, 1),
        ("fuel_pump", "Pompe à carburant", "Fuel Pump", "gadget", (150, 160, 175), (80, 200, 255),
         ["GSG", "PVP"], {"G": "steel_gear", "S": "steel_rod", "P": "steel_plate", "V": "pressure_valve"}, 1),
        ("cryo_tank", "Réservoir cryogénique", "Cryo Tank", "tank", (190, 225, 245), (100, 180, 240),
         ["PCP", "PFP", "PCP"], {"P": "aluminum_plate", "C": "coolant_canister", "F": "fuel_tank"}, 1),
        ("fuel_tank_large", "Grand réservoir de fusée", "Large Rocket Fuel Tank", "tank", (230, 230, 240), (255, 90, 60),
         ["PFP", "FKF", "PFP"], {"P": "titanium_plate", "F": "fuel_tank", "K": "cryo_tank"}, 1),
        ("ignition_system", "Système d'allumage", "Ignition System", "chip", (60, 90, 70), (255, 200, 60),
         ["WAW", "BSB"], {"W": "copper_wire", "A": "advanced_circuit", "B": "lithium_battery", "S": "silicon_wafer"}, 1),
        ("guidance_computer", "Ordinateur de guidage", "Guidance Computer", "chip", (50, 60, 100), (120, 220, 255),
         ["APA", "SPS", "APA"], {"A": "advanced_circuit", "P": "processor", "S": "silver_wire"}, 1),
        ("telemetry_module", "Module de télémétrie", "Telemetry Module", "gadget", (80, 90, 110), (120, 255, 160),
         ["WLW", "CPC"], {"W": "silver_wire", "L": "visor_lens", "C": "circuit_board", "P": "processor"}, 1),
        ("rocket_fin", "Aileron de fusée", "Rocket Fin", "fin", (210, 215, 230), (230, 60, 60),
         ["T ", "TT", "TT"], {"T": "lunar_alloy_plate"}, 2),
        ("fairing", "Coiffe", "Fairing", "capsule", (225, 228, 238), (160, 170, 190),
         ["HNH", "H H", "HHH"], {"H": "hull_panel", "N": "nose_cone"}, 1),
        ("heat_shield_plate", "Plaque de bouclier thermique", "Heat Shield Plate", "tile", (60, 55, 60), (255, 140, 60),
         ["TTT", "TIT", "TTT"], {"T": "heat_shield_tile", "I": "insulation"}, 1),
        ("landing_gear", "Train d'atterrissage", "Landing Gear", "gadget", (150, 150, 160), (240, 190, 60),
         ["P P", "SPS", "G G"], {"P": "steel_plate", "S": "steel_rod", "G": "steel_gear"}, 1),
        ("parachute_system", "Système de parachute", "Parachute System", "crate", (230, 120, 60), (255, 255, 255),
         ["PPP", "VCV"], {"P": "parachute", "V": "pressure_valve", "C": "circuit_board"}, 1),
        ("capsule_hull", "Coque de capsule", "Capsule Hull", "capsule", (210, 214, 226), (120, 130, 150),
         ["HHH", "HIH", "H H"], {"H": "hull_panel", "I": "insulation"}, 1),
        ("stage_booster", "Étage propulseur", "Stage Booster", "tank", (235, 235, 245), (255, 130, 50),
         ["CFC", "TKT", "N N"], {"C": "combustion_chamber", "F": "fuel_tank_large", "T": "thruster", "K": "ignition_system", "N": "nozzle_bell"}, 1),
    ]
    for n, fr, en, shp, c1, c2, pat, key, cnt in PARTS:
        item(n, fr, en, shape=shp, color=c1, color2=c2)
        shaped(I(n), pat, {k: I(v) for k, v in key.items()}, cnt)
    # nouvelle recette du module de rentrée (remplace l'ancienne)
    R[:] = [r for r in R if r["result"] != I("reentry_module")]
    shaped(I("reentry_module"), [" S ", "HCH", "PGL"], {"S": I("telemetry_module"), "H": I("heat_shield_plate"), "C": I("capsule_hull"),
                                                      "P": I("parachute_system"), "G": I("guidance_computer"), "L": I("life_support_unit")})
    item("rocket_assembly_manual", "Manuel d'assemblage de fusée", "Rocket Assembly Manual", shape="card", color=(240, 240, 250),
         color2=(230, 60, 60), stack=1, use=dict(msg="Il faut : schéma Tier 3, moteur, étage propulseur, grand réservoir, 3 carburants, module de rentrée.", keep=True))
    shapeless(I("rocket_assembly_manual"), [I("blueprint_tier2"), I("processor")])

    # ---- électronique & mécanique générale
    GEN = [
        ("capacitor", "Condensateur", "Capacitor", "can", (60, 120, 200), (200, 200, 210), ["C", "W"], {"C": "aluminum_plate", "W": "copper_wire"}, 2),
        ("transistor", "Transistor", "Transistor", "chip", (40, 40, 50), (200, 200, 90), ["S", "W"], {"S": "silicon", "W": "copper_wire"}, 4),
        ("led_panel", "Panneau LED", "LED Panel", "tile", (240, 240, 250), (255, 120, 120), ["SSS", "WCW"], {"S": "silicon", "W": "copper_wire", "C": "circuit_board"}, 1),
        ("antenna", "Antenne", "Antenna", "ring", (190, 195, 205), (255, 90, 90), ["R", "R", "P"], {"R": "aluminum_rod", "P": "steel_plate"}, 1),
        ("radio_module", "Module radio", "Radio Module", "gadget", (70, 80, 100), (120, 255, 120), ["AC", "PW"], {"A": "antenna", "C": "circuit_board", "P": "steel_plate", "W": "copper_wire"}, 1),
        ("sensor_array", "Réseau de capteurs", "Sensor Array", "lens", (120, 200, 255), (255, 255, 255), ["LLL", "CPC"], {"L": "visor_lens", "C": "circuit_board", "P": "processor"}, 1),
        ("gyroscope", "Gyroscope", "Gyroscope", "orb", (200, 205, 215), (60, 60, 70), ["BGB", "GPG", "BGB"], {"B": "bronze_plate", "G": "steel_gear", "P": "processor"}, 1),
        ("battery_pack", "Bloc batterie", "Battery Pack", "tank", (60, 170, 90), (230, 230, 80), ["BBB", "BCB"], {"B": "lithium_battery", "C": "circuit_board"}, 1),
        ("power_cable", "Câble d'alimentation", "Power Cable", "coil", (210, 130, 70), (80, 80, 90), ["WWW", "WIW", "WWW"], {"W": "copper_wire", "I": "insulation"}, 2),
        ("servo_motor", "Servomoteur", "Servo Motor", "gadget", (170, 175, 190), (255, 160, 60), ["GCG", "WPW"], {"G": "steel_gear", "C": "copper_wire", "W": "copper_wire", "P": "steel_plate"}, 1),
        ("hydraulic_piston", "Vérin hydraulique", "Hydraulic Piston", "tank", (170, 175, 190), (255, 160, 60), ["R", "V", "P"], {"R": "steel_rod", "V": "pressure_valve", "P": "steel_plate"}, 1),
        ("drill_head", "Tête de foreuse", "Drill Head", "nozzle", (150, 160, 175), (255, 220, 100), [" T ", "TST", "TTT"], {"T": "titanium_plate", "S": "steel_gear"}, 1),
        ("lens_array", "Matrice de lentilles", "Lens Array", "lens", (150, 230, 255), (255, 255, 255), ["LL", "LL"], {"L": "visor_lens"}, 1),
        ("thermal_regulator", "Régulateur thermique", "Thermal Regulator", "gadget", (230, 120, 80), (90, 190, 255), ["IVI", "CPC"], {"I": "insulation", "V": "pressure_valve", "C": "coolant_canister", "P": "circuit_board"}, 1),
        ("coolant_pump", "Pompe de refroidissement", "Coolant Pump", "gadget", (90, 170, 230), (230, 230, 240), ["GCG", "PVP"], {"G": "aluminum_gear", "C": "coolant_canister", "P": "aluminum_plate", "V": "pressure_valve"}, 1),
        ("vacuum_tube", "Tube à vide", "Vacuum Tube", "jar", (255, 220, 150), (160, 160, 170), ["G", "W", "P"], {"G": "regolith_glass", "W": "copper_wire", "P": "steel_plate"}, 2),
        ("carbon_fiber", "Fibre de carbone", "Carbon Fiber", "tile", (40, 42, 50), (90, 94, 110), ["II", "II"], {"I": "insulation"}, 2),
        ("ceramic_plate", "Plaque céramique", "Ceramic Plate", "tile", (235, 228, 215), (190, 180, 165), ["SS", "SS"], {"S": "silicon"}, 2),
        ("nano_coating", "Revêtement nano", "Nano Coating", "jar", (180, 200, 255), (110, 120, 170), ["S", "C", "I"], {"S": "silver_wire", "C": "ceramic_plate", "I": "insulation"}, 2),
        ("quantum_chip", "Puce quantique", "Quantum Chip", "chip", (40, 30, 80), (200, 120, 255), ["APA", "PLP", "APA"], {"A": "advanced_circuit", "P": "processor", "L": "lithium_battery"}, 1),
        ("fusion_cell", "Cellule de fusion", "Fusion Cell", "core", (120, 200, 255), (255, 255, 255), ["HPH", "PCP", "HPH"], {"H": "helium3_crystal", "P": "titanium_plate", "C": "power_core"}, 1),
        ("grav_stabilizer", "Stabilisateur de gravité", "Grav Stabilizer", "orb", (150, 100, 220), (255, 220, 255), ["MGM", "GQG", "MGM"], {"M": "moonstone", "G": "gyroscope", "Q": "quantum_chip"}, 1),
        ("solar_array", "Réseau solaire", "Solar Array", "tile", (40, 70, 160), (150, 190, 255), ["SSS", "SSS"], {"S": "solar_cell"}, 1),
        ("hazard_lamp", "Lampe d'alerte", "Hazard Lamp", "orb", (255, 190, 40), (255, 255, 200), ["G", "W", "B"], {"G": "regolith_glass", "W": "copper_wire", "B": "lithium_battery"}, 1),
    ]
    for n, fr, en, shp, c1, c2, pat, key, cnt in GEN:
        item(n, fr, en, shape=shp, color=c1, color2=c2)
        shaped(I(n), pat, {k: I(v) for k, v in key.items()}, cnt)

    # ---- objets utiles supplémentaires (clic droit)
    USE = [
        ("emp_grenade", "Grenade IEM", "EMP Grenade", "orb", (90, 160, 255), (255, 255, 255),
         dict(cmds=["execute as %p at @s run effect give @e[type=#minecraft:undead,distance=..16] minecraft:slowness 10 3 true",
                    "execute as %p at @s run effect give @e[distance=..10] minecraft:glowing 10 0 true"], msg="Impulsion électromagnétique !"), 8,
         ["PBP", "CIC"], {"P": "titanium_plate", "B": "battery_pack", "C": "copper_wire", "I": "circuit_board"}),
        ("grav_boots_charm", "Charme anti-gravité", "Anti-Grav Charm", "ring", (190, 140, 255), (255, 255, 255),
         dict(cmds=["effect give %p minecraft:jump_boost 300 3 true", "effect give %p minecraft:slow_falling 300 0 true"], msg="Gravité réduite pendant 5 minutes."), 4,
         [" G ", "MQM"], {"G": "grav_stabilizer", "M": "moonstone", "Q": "quantum_chip"}),
        ("solar_shield", "Bouclier solaire", "Solar Shield", "tile", (255, 220, 120), (255, 255, 255),
         dict(cool=12000, cmds=["effect give %p minecraft:fire_resistance 600 0 true"], msg="Protégé du Soleil pendant 10 minutes."), 4,
         ["CCC", "SIS"], {"C": "ceramic_plate", "S": "silver_wire", "I": "insulation"}),
        ("cryo_shield", "Bouclier cryogénique", "Cryo Shield", "tile", (150, 220, 255), (255, 255, 255),
         dict(warm=12000, msg="Protégé du froid pendant 10 minutes."), 4, ["CCC", "SIS"], {"C": "carbon_fiber", "S": "copper_wire", "I": "insulation"}),
        ("mining_charge", "Charge de forage", "Mining Charge", "crate", (230, 90, 60), (255, 230, 120),
         dict(cmds=["execute as %p at @s run effect give @s minecraft:haste 120 2 true"], msg="Forage accéléré pendant 2 minutes."), 8,
         ["SPS", "IFI"], {"S": "steel_plate", "P": "pressure_valve", "I": "iron_scrap", "F": "sun_ember"}),
        ("beacon_flare", "Balise de détresse", "Distress Beacon", "orb", (255, 80, 80), (255, 255, 255),
         dict(cmds=["execute as %p at @s run effect give @s minecraft:glowing 60 0 true", "execute as %p at @s run effect give @s minecraft:night_vision 60 0 true"], msg="Balise active."), 8,
         ["FRF"], {"F": "signal_flare", "R": "radio_module"}),
        ("oxygen_booster", "Surpresseur d'O₂", "Oxygen Booster", "tank", (120, 220, 255), (255, 255, 255),
         dict(o2=3000, msg="Réserve d'O₂ au maximum !"), 2, ["TOT", "VCV"], {"T": "oxygen_tank_large", "O": "oxygen_tank_full", "V": "pressure_valve", "C": "compressor_cap"} if False else {"T": "oxygen_tank_large", "O": "oxygen_tank_full", "V": "pressure_valve", "C": "circuit_board"}),
        ("regen_gel", "Gel régénérant", "Regen Gel", "jar", (255, 140, 190), (255, 255, 255),
         dict(cmds=["effect give %p minecraft:regeneration 30 2 true", "effect give %p minecraft:absorption 60 1 true"], msg="Régénération !"), 8,
         ["B", "G"], {"B": "bio_sample", "G": "geode_slime"}),
    ]
    for n, fr, en, shp, c1, c2, use, stack, pat, key in USE:
        item(n, fr, en, shape=shp, color=c1, color2=c2, stack=stack, use=use)
        shaped(I(n), pat, {k: I(v) for k, v in key.items()}, 1)

    # ---- propulseur dorsal : vrai vol (déplacement dans la direction du regard, 18 blocs max, s'arrête aux murs)
    jet = []
    for _ in range(18):
        jet.append("execute as %p at @s if block ^ ^ ^1 minecraft:air if block ^ ^1 ^1 minecraft:air run tp @s ^ ^ ^1")
    jet += ["execute as %p at @s run particle minecraft:flame ~ ~ ~ 0.3 0.1 0.3 0.05 40",
            "execute as %p at @s run particle minecraft:large_smoke ~ ~ ~ 0.3 0.1 0.3 0.02 15",
            "execute as %p at @s run playsound minecraft:entity.firework_rocket.launch player @a ~ ~ ~ 1 1",
            "effect give %p minecraft:slow_falling 8 0 true"]
    for it in C.ITEMS:
        if it["name"] == "jet_booster":
            it["fr"] = "Propulseur dorsal (clic droit : vol dans la direction du regard)"
            it["en"] = "Jet Booster (right-click: dash where you look)"
            it["use"] = dict(cmds=jet, msg="Propulsion !")
            it["stack"] = 16
    for r in RECIPES:
        if r["result"] == I("jet_booster"):
            r["n"] = 4

    # ---- poisson lunaire (pêche dans les lacs) et adoption des animaux
    item("moon_fish", "Poisson lunaire", "Moon Fish", shape="fish", color=(150, 165, 190), color2=(225, 230, 240), stack=64,
         use=dict(cmds=["effect give %p minecraft:saturation 1 3 true"], msg="Miam."))
    item("cooked_moon_fish", "Poisson lunaire grillé", "Cooked Moon Fish", shape="fish", color=(200, 150, 100), color2=(240, 215, 160),
         stack=64, use=dict(cmds=["effect give %p minecraft:saturation 1 7 true"], msg="Délicieux."))
    cook(I("cooked_moon_fish"), I("moon_fish"))

    # ---- livre guide (donné à l'arrivée ; recraftable)
    item("guide_book", "Guide de Lunaire", "Lunaire Guide", shape="book", color=(60, 80, 140), stack=1,
         use=dict(cmds=["give %p minecraft:written_book[minecraft:written_book_content=" + GUIDE_NBT + "]"],
                  msg="Le guide de Lunaire."))
    shapeless(I("guide_book"), ["minecraft:book", I("lunar_ice")])

    # ---- nourriture
    FOOD = [
        ("lunar_pie", "Tarte lunaire", "Lunar Pie", "bar", (235, 200, 130), (180, 120, 70), 8, "saturation 1 10", "regeneration 8 1"),
        ("algae_soup", "Soupe d'algues", "Algae Soup", "can", (90, 190, 110), (230, 230, 240), 6, "saturation 1 8", ""),
        ("regolith_cookie", "Biscuit au régolithe", "Regolith Cookie", "bar", (190, 170, 140), (120, 100, 80), 4, "saturation 1 3", ""),
        ("mineral_water", "Eau minérale", "Mineral Water", "jar", (120, 190, 255), (210, 230, 250), 1, "saturation 1 1", "speed 30 0"),
        ("star_candy", "Bonbon étoilé", "Star Candy", "nugget", (255, 120, 200), (255, 255, 255), 2, "saturation 1 2", "speed 20 1"),
        ("moon_stew", "Ragoût lunaire", "Moon Stew", "can", (180, 120, 80), (230, 230, 240), 6, "saturation 1 11", "resistance 40 0"),
        ("jelly_pack", "Pochon de gelée", "Jelly Pack", "jar", (200, 120, 255), (230, 200, 255), 4, "saturation 1 4", "jump_boost 60 0"),
        ("meteor_candy", "Sucre de météorite", "Meteor Candy", "chunk", (150, 100, 200), (240, 200, 255), 2, "saturation 1 2", "strength 30 0"),
        ("hot_cocoa_ration", "Ration chaude", "Hot Ration", "can", (150, 90, 60), (255, 120, 60), 4, "saturation 1 6", "fire_resistance 120 0"),
        ("frost_sorbet", "Sorbet givré", "Frost Sorbet", "jar", (190, 235, 255), (255, 255, 255), 4, "saturation 1 5", "regeneration 6 0"),
        ("crystal_honey", "Miel de cristal", "Crystal Honey", "jar", (255, 210, 90), (255, 240, 170), 4, "saturation 1 6", "absorption 60 0"),
        ("space_burger", "Burger spatial", "Space Burger", "bar", (210, 150, 80), (120, 70, 40), 8, "saturation 1 12", ""),
    ]
    for n, fr, en, shp, c1, c2, st, e1, e2 in FOOD:
        cmds = [f"effect give %p minecraft:{e1} true"] + ([f"effect give %p minecraft:{e2} true"] if e2 else [])
        item(n, fr, en, shape=shp, color=c1, color2=c2, stack=16, use=dict(cmds=cmds, msg="Miam."))
    shapeless(I("lunar_pie"), [I("algae_culture"), I("moon_fluff"), I("nutrient_paste")])
    shapeless(I("algae_soup"), [I("algae_culture")] * 2 + [I("lunar_ice")])
    shapeless(I("regolith_cookie"), [I("regolith"), I("algae_culture"), I("nutrient_paste")], 2)
    shapeless(I("mineral_water"), [I("lunar_ice"), I("olivine")], 2)
    shapeless(I("star_candy"), [I("glow_dust"), I("nutrient_paste")], 2)
    shapeless(I("moon_stew"), [I("cooked_moon_meat"), I("algae_culture"), I("lunar_ice")])
    shapeless(I("jelly_pack"), [I("geode_slime"), I("nutrient_paste")])
    shapeless(I("meteor_candy"), [I("meteorite_shard"), I("nutrient_paste")], 2)
    shapeless(I("hot_cocoa_ration"), [I("sun_ember"), I("protein_ration")])
    shapeless(I("frost_sorbet"), [I("cryo_gel"), I("nutrient_paste")])
    shapeless(I("crystal_honey"), [I("crystal_shell"), I("nutrient_paste")])
    shapeless(I("space_burger"), [I("cooked_moon_meat"), I("algae_bar"), I("moon_cheese")])

    # ---- œufs d'apparition
    for mob in MB.MOBS:
        name, fr, en, sh, style, beh, *_rest = mob
        main, dark, acc = mob[9]
        item(f"{name}_spawn_egg", f"Œuf d'apparition : {fr}", f"{en} Spawn Egg", shape="egg", color=main, color2=acc, stack=64,
             use=dict(egg=I(name)))
    build_blocks()


# ============================================================================ BLOCS

def tex(name, fn):
    """Enregistre une texture procédurale pour un bloc."""
    BL.EXTRA_TEX[name] = fn


def _tiles(base, seed, grout=None, size=8):
    img = BL._rich(base, seed, 6, ((255, 255, 255), 3), None, 0, 2)
    g = grout or shade(base, -50)
    for i in range(16):
        for k in range(0, 16, size):
            img.set(i, k, g), img.set(k, i, g)
        img.set(i, 15, g), img.set(15, i, g)
    for x in range(1, 16, size):
        for y in range(1, 16, size):
            img.set(x, y, shade(base, 25))
    return img


def _chiseled(base, seed):
    img = BL._rich(base, seed, 5, None, None, 0, 2)
    BL._frame(img, shade(base, 40), shade(base, -50))
    for i in range(3, 13):
        img.set(i, 3, shade(base, -40)), img.set(i, 12, shade(base, -40)), img.set(3, i, shade(base, -40)), img.set(12, i, shade(base, -40))
    for i in range(5, 11):
        img.set(i, 7, shade(base, 35)), img.set(i, 8, shade(base, 35)), img.set(7, i, shade(base, 35)), img.set(8, i, shade(base, 35))
    return img


def _hazard(seed):
    img = Img(16, 16)
    for y in range(16):
        for x in range(16):
            img.set(x, y, (245, 205, 40) if ((x + y) // 4) % 2 == 0 else (36, 36, 42))
    BL._frame(img, (255, 235, 120), (20, 20, 24))
    return img


def _rack(seed):
    rng = random.Random(seed)
    img = BL._rich((46, 50, 62), seed, 4, None, None, 0, 2)
    for y in range(2, 14, 3):
        for x in range(2, 14, 1):
            img.set(x, y, (28, 30, 38))
        for x in (3, 5, 8, 12):
            img.set(x, y, rng.choice([(90, 255, 130), (255, 200, 60), (90, 200, 255)]))
    BL._frame(img, (110, 116, 132), (24, 26, 32))
    return img


def _monitor(seed):
    img = Img(16, 16)
    for y in range(16):
        for x in range(16):
            img.set(x, y, (40, 44, 54))
    for y in range(2, 14):
        for x in range(2, 14):
            v = 0.5 + 0.5 * ((x * 3 + y * 5) % 7) / 7
            img.set(x, y, (int(30 + 40 * v), int(150 + 80 * v), int(170 + 70 * v)))
    for x in range(3, 12):
        img.set(x, 5, (230, 255, 255)), img.set(x, 9, (200, 250, 255))
    BL._frame(img, (90, 94, 110), (20, 22, 28))
    return img


def _pipe(seed):
    img = BL._rich((130, 138, 150), seed, 5, None, None, 0, 2)
    for y in (3, 8, 13):
        for x in range(16):
            img.set(x, y - 1, (170, 178, 190)), img.set(x, y, (110, 116, 128)), img.set(x, y + 1 if y + 1 < 16 else y, (80, 86, 98))
    for x in (2, 8, 14):
        for y in range(16):
            img.set(x, y, (200, 205, 215))
    return img


def _grate(seed):
    img = Img(16, 16)
    for y in range(16):
        for x in range(16):
            img.set(x, y, (24, 26, 32) if (x % 4 in (1, 2) and y % 4 in (1, 2)) else (120, 126, 138))
    BL._frame(img, (160, 166, 178), (70, 74, 84))
    return img


def _crate(seed):
    img = BL._rich((150, 120, 80), seed, 7, None, None, 0, 3)
    BL._frame(img, (100, 76, 48), (100, 76, 48))
    for i in range(2, 14):
        img.set(i, i, (100, 76, 48)), img.set(15 - i, i, (100, 76, 48))
    return img


def _neon(color, seed):
    img = BL._rich((30, 32, 40), seed, 3, None, None, 0, 1)
    for y in (3, 4, 7, 8, 11, 12):
        for x in range(1, 15):
            img.set(x, y, shade(color, 0 if y in (4, 8, 12) else 40))
    return img


def _lamp(color, seed):
    img = BL._rich(color, seed, 8, ((255, 255, 255), 8), None, 0, 3)
    for i in range(16):
        for k in (0, 15):
            img.set(i, k, shade(color, -70)), img.set(k, i, shade(color, -70))
    for i in range(2, 14):
        img.set(i, 7, shade(color, -40)), img.set(7, i, shade(color, -40))
    for (x, y) in ((4, 4), (11, 4), (4, 11), (11, 11)):
        img.set(x, y, (255, 255, 255))
    return img


def _glass(color):
    r, g, b = color
    im = BL.glass((r, g, b, 90), (int(r * .6), int(g * .6), int(b * .6), 255))
    for i in range(3, 12, 4):
        im.set(i, 2 + i // 4, (255, 255, 255, 170))
    return im


def _sand(base, seed, spec):
    return BL._rich(base, seed, 9, (spec, 16), None, 0, 7)


def _crystalblock(base, hi, seed):
    img = BL._rich(base, seed, 12, (hi, 12), None, 0, 3)
    for k in range(0, 16, 5):
        for d in range(8):
            img.set((k + d) % 16, d + 4, shade(hi, -20))
    BL._frame(img, shade(base, 60), shade(base, -50))
    return img


def build_blocks():
    R = RECIPES

    def shaped(result, pattern, key, n=1):
        R.append(dict(type="shaped", result=result, pattern=pattern, key=key, n=n))

    def shapeless(result, ings, n=1):
        R.append(dict(type="shapeless", result=result, ingredients=ings, n=n))

    # ---- couleurs : béton, verre, lampe, panneau, briques
    for (c, fr, en, rgb, dye) in COLORS:
        D = f"minecraft:{dye}_dye"
        tex(f"bk_concrete_{c}", lambda s, rgb=rgb: BL._rich(rgb, s, 4, None, None, 0, 2))
        block(f"lunar_concrete_{c}", f"Béton lunaire {fr}", f"{en} Lunar Concrete", hard=1.6, texture=f"bk_concrete_{c}", need=None)
        shapeless(I(f"lunar_concrete_{c}"), [I("regolith"), I("regolith"), D], 2)
        tex(f"bk_glass_{c}", lambda s, rgb=rgb: _glass(rgb))
        block(f"stained_glass_{c}", f"Verre teinté {fr}", f"{en} Stained Glass", hard=0.5, glass=True, sound="glass", need=None, texture=f"bk_glass_{c}")
        shapeless(I(f"stained_glass_{c}"), [I("impact_glass"), D])
        tex(f"bk_lamp_{c}", lambda s, rgb=rgb: _lamp(rgb, s))
        block(f"neon_lamp_{c}", f"Lampe néon {fr}", f"{en} Neon Lamp", hard=0.8, light=15, sound="glass", need=None, texture=f"bk_lamp_{c}")
        shapeless(I(f"neon_lamp_{c}"), [I("lab_light"), D])
        tex(f"bk_panel_{c}", lambda s, rgb=rgb: BL.panel(rgb, shade(rgb, -60), s))
        block(f"lab_panel_{c}", f"Panneau de labo {fr}", f"{en} Lab Panel", hard=2.0, sound="metal", texture=f"bk_panel_{c}")
        shapeless(I(f"lab_panel_{c}"), [I("lab_plating"), D])
        tex(f"bk_brick_{c}", lambda s, rgb=rgb: BL.bricks(rgb, s, shade(rgb, -70)))
        block(f"moon_bricks_{c}", f"Briques lunaires {fr}", f"{en} Moon Bricks", hard=1.8, texture=f"bk_brick_{c}")
        shapeless(I(f"moon_bricks_{c}"), [I("lunar_rock_bricks"), D])

    # ---- nouvelles pierres décoratives et de biome
    DECOR = [
        ("anorthosite_tiles", "Dalles d'anorthosite", "Anorthosite Tiles", lambda s: _tiles((205, 205, 200), s), 1.8, 0, "stone", dict(src=("polished_anorthosite", 1))),
        ("mare_basalt_tiles", "Dalles de basalte des mers", "Mare Basalt Tiles", lambda s: _tiles((62, 66, 82), s), 2.4, 0, "stone", dict(src=("polished_mare_basalt", 1))),
        ("lunar_rock_tiles", "Dalles de roche lunaire", "Lunar Rock Tiles", lambda s: _tiles((100, 100, 108), s), 1.8, 0, "stone", dict(src=("polished_lunar_rock", 1))),
        ("chiseled_anorthosite", "Anorthosite sculptée", "Chiseled Anorthosite", lambda s: _chiseled((205, 205, 200), s), 1.8, 0, "stone", dict(src=("anorthosite_bricks", 1))),
        ("chiseled_mare_basalt", "Basalte sculpté", "Chiseled Mare Basalt", lambda s: _chiseled((62, 66, 82), s), 2.4, 0, "stone", dict(src=("mare_basalt_bricks", 1))),
        ("chiseled_lunar_rock", "Roche lunaire sculptée", "Chiseled Lunar Rock", lambda s: _chiseled((100, 100, 108), s), 1.8, 0, "stone", dict(src=("lunar_rock_bricks", 1))),
        ("hazard_block", "Bloc de danger", "Hazard Block", _hazard, 2.0, 0, "metal", dict(src=("lab_plating", 1))),
        ("server_rack", "Baie de serveurs", "Server Rack", _rack, 2.5, 4, "metal", dict(rec=(["ICI", "CPC", "ICI"], {"I": "iron_scrap", "C": "circuit_board", "P": "processor"}))),
        ("monitor_block", "Écran de contrôle", "Monitor Block", _monitor, 2.0, 6, "glass", dict(rec=(["GGG", "GCG", "PPP"], {"G": "regolith_glass", "C": "circuit_board", "P": "steel_plate"}))),
        ("pipe_block", "Bloc de tuyauterie", "Pipe Block", _pipe, 2.0, 0, "metal", dict(rec=(["PPP", "V V", "PPP"], {"P": "steel_plate", "V": "pressure_valve"}))),
        ("vent_grate", "Grille d'aération", "Vent Grate", _grate, 1.5, 0, "metal", dict(rec=(["PPP", "P P", "PPP"], {"P": "steel_rod"}))),
        ("cargo_crate", "Caisse de fret", "Cargo Crate", _crate, 1.5, 0, "metal", dict(rec=(["PPP", "PSP", "PPP"], {"P": "aluminum_plate", "S": "steel_rod"}))),
        ("compressed_dust", "Poussière compressée", "Compressed Dust", lambda s: BL._rich((120, 116, 110), s, 5, None, None, 0, 3), 1.2, 0, "stone", dict(src=("lunar_dust", 1))),
        ("lunar_gravel", "Gravier lunaire", "Lunar Gravel", lambda s: BL._rich((130, 128, 126), s, 12, ((190, 188, 184), 22), ((60, 58, 56), 18), 0, 9), 0.6, 0, "gravel", dict(shovel=True)),
        ("crystal_sand", "Sable de cristal", "Crystal Sand", lambda s: _sand((205, 225, 245), s, (255, 255, 255)), 0.5, 0, "gravel", dict(shovel=True)),
        ("glowing_sand", "Sable luminescent", "Glowing Sand", lambda s: _sand((120, 230, 170), s, (230, 255, 210)), 0.5, 8, "gravel", dict(shovel=True)),
        ("volcanic_ash", "Cendre volcanique", "Volcanic Ash", lambda s: _sand((70, 66, 72), s, (140, 130, 140)), 0.5, 0, "gravel", dict(shovel=True)),
        ("frozen_regolith", "Régolithe gelé", "Frozen Regolith", lambda s: BL._rich((190, 215, 232), s, 8, ((255, 255, 255), 14), None, 0, 5), 0.8, 0, "gravel", dict(shovel=True)),
        ("highland_dust", "Poussière des hautes terres", "Highland Dust", lambda s: _sand((226, 224, 218), s, (255, 255, 250)), 0.5, 0, "gravel", dict(shovel=True)),
        ("olivine_gravel", "Gravier d'olivine", "Olivine Gravel", lambda s: _sand((120, 170, 90), s, (200, 255, 130)), 0.6, 0, "gravel", dict(shovel=True)),
        ("olivine_bricks", "Briques d'olivine", "Olivine Bricks", lambda s: BL.bricks((100, 170, 75), s, (50, 100, 40)), 2.0, 0, "stone", dict(src=("glowing_olivine_block", 4))),
        ("moonstone_bricks", "Briques de pierre de lune", "Moonstone Bricks", lambda s: BL.bricks((150, 190, 245), s, (80, 110, 190)), 2.0, 5, "stone", dict(src=("moonstone_block", 4))),
        ("tektite_bricks", "Briques de tectite", "Tektite Bricks", lambda s: BL.bricks((40, 70, 55), s, (15, 30, 22)), 2.0, 3, "stone", dict(src=("tektite", 4))),
        ("meteorite_bricks", "Briques de météorite", "Meteorite Bricks", lambda s: BL.bricks((85, 55, 120), s, (30, 18, 50)), 3.0, 4, "stone", dict(src=("meteorite_block", 4))),
        ("heavy_plating", "Blindage lourd", "Heavy Plating", lambda s: BL.panel((95, 100, 112), (45, 48, 58), s), 4.0, 0, "metal", dict(src=("steel_block", 4))),
        ("solar_tile", "Dalle solaire", "Solar Tile", lambda s: _tiles((36, 60, 140), s, (20, 30, 70), 4), 2.0, 0, "metal", dict(rec=(["SSS", "SPS", "SSS"], {"S": "solar_cell", "P": "steel_plate"}))),
        ("white_tile", "Dalle blanche", "White Tile", lambda s: _tiles((235, 238, 242), s, (170, 176, 188), 4), 1.5, 0, "stone", dict(src=("ceramic_plate", 2))),
        ("black_tile", "Dalle noire", "Black Tile", lambda s: _tiles((34, 36, 44), s, (14, 14, 20), 4), 1.5, 0, "stone", dict(src=("carbon_fiber", 2))),
        ("neon_strip_blue", "Néon bleu", "Blue Neon Strip", lambda s: _neon((90, 200, 255), s), 1.0, 12, "glass", dict(src=("neon_lamp_light_blue", 2))),
        ("neon_strip_red", "Néon rouge", "Red Neon Strip", lambda s: _neon((255, 80, 80), s), 1.0, 12, "glass", dict(src=("neon_lamp_red", 2))),
        ("neon_strip_green", "Néon vert", "Green Neon Strip", lambda s: _neon((100, 255, 130), s), 1.0, 12, "glass", dict(src=("neon_lamp_lime", 2))),
        ("neon_strip_purple", "Néon violet", "Purple Neon Strip", lambda s: _neon((200, 110, 255), s), 1.0, 12, "glass", dict(src=("neon_lamp_purple", 2))),
        ("crystal_cluster_blue", "Cristal bleu", "Blue Crystal Block", lambda s: _crystalblock((70, 120, 230), (200, 230, 255), s), 2.5, 9, "glass", dict(src=("stained_glass_blue", 1))),
        ("crystal_cluster_pink", "Cristal rose", "Pink Crystal Block", lambda s: _crystalblock((230, 100, 190), (255, 220, 245), s), 2.5, 9, "glass", dict(src=("stained_glass_pink", 1))),
        ("crystal_cluster_green", "Cristal vert", "Green Crystal Block", lambda s: _crystalblock((60, 200, 120), (210, 255, 220), s), 2.5, 9, "glass", dict(src=("stained_glass_green", 1))),
        ("lumen_block", "Bloc de lumière", "Lumen Block", lambda s: BL._rich((255, 240, 190), s, 12, ((255, 255, 255), 14), None, 0, 4), 1.0, 15, "glass", dict(src=("lab_light", 2))),
        ("airlock_frame", "Cadre de sas", "Airlock Frame", lambda s: BL.panel((200, 204, 214), (110, 116, 128), s), 3.0, 0, "metal", dict(rec=(["PPP", "P P", "PPP"], {"P": "titanium_plate"}))),
        ("bulkhead", "Cloison", "Bulkhead", lambda s: BL.panel((150, 156, 168), (80, 86, 98), s), 3.0, 0, "metal", dict(rec=(["PP", "PP"], {"P": "hull_panel"}))),
        ("grated_floor", "Sol grillagé", "Grated Floor", _grate, 1.5, 0, "metal", dict(src=("vent_grate", 1))),
        ("rivet_plate", "Plaque rivetée", "Rivet Plate", lambda s: BL.panel((120, 126, 138), (60, 64, 76), s), 2.5, 0, "metal", dict(src=("steel_plate", 1))),
    ]
    for name, fr, en, fn, hard, light, sound, extra in DECOR:
        tex(f"bk_{name}", fn)
        kw = dict(hard=hard, light=light, sound=sound, texture=f"bk_{name}", need=None)
        if sound == "glass":
            kw["glass"] = True
        if extra.get("shovel"):
            kw["tool"] = "shovel"
        block(name, fr, en, **kw)
        if "src" in extra:
            src, n = extra["src"]
            shaped(I(name), ["SS", "SS"], {"S": I(src)}, max(1, n)) if n > 1 else shapeless(I(name), [I(src)])
        if "rec" in extra:
            pat, key = extra["rec"]
            shaped(I(name), pat, {k: I(v) for k, v in key.items()}, 1)

    # ---- minerais dans l'anorthosite et le basalte
    for b in [dict(b) for b in C.BLOCKS if b["texture"] == "ore"]:
        base_name = b["name"]
        for stone, sfr, sen, col in (("anorthosite", "dans l'anorthosite", "in Anorthosite", (205, 205, 200)),
                                     ("mare_basalt", "dans le basalte", "in Mare Basalt", (62, 66, 82))):
            nm = f"{stone}_{base_name}"
            ore = dict(b)
            fr = b["fr"] + " " + sfr
            en = b["en"] + " " + sen
            block(nm, fr, en, color=b["color"], hard=b["hard"], need=b["need"], drop=b["drop"], count=b["count"],
                  light=b["light"], texture="ore", base=col)

    # ---- escaliers, dalles, murs
    BASES = ["lunar_rock", "polished_lunar_rock", "lunar_rock_bricks", "regolith_bricks", "anorthosite", "polished_anorthosite",
             "anorthosite_bricks", "mare_basalt", "polished_mare_basalt", "mare_basalt_bricks", "tektite", "ancient_stone",
             "ancient_bricks", "lab_plating", "lab_floor", "steel_block", "titanium_block", "copper_block", "aluminum_block",
             "bronze_block", "lunar_alloy_block", "anorthosite_tiles", "mare_basalt_tiles", "lunar_rock_tiles", "olivine_bricks",
             "moonstone_bricks", "tektite_bricks", "meteorite_bricks", "heavy_plating", "white_tile", "black_tile", "solar_tile",
             "cracked_lunar_rock", "compressed_dust"]
    BASES += [f"lunar_concrete_{c[0]}" for c in COLORS] + [f"moon_bricks_{c[0]}" for c in COLORS]
    byname = {b["name"]: b for b in C.BLOCKS}
    for base in BASES:
        bb = byname[base]
        for kind, sfx, sfr, sen, pat, n in (("stairs", "stairs", "Escalier", "Stairs", ["R  ", "RR ", "RRR"], 4),
                                            ("slab", "slab", "Dalle", "Slab", ["RRR"], 6),
                                            ("wall", "wall", "Muret", "Wall", ["RRR", "RRR"], 6)):
            if kind == "wall" and (base.startswith("lunar_concrete") is False and base.startswith("moon_bricks") is False and
                                   base not in ("lunar_rock", "lunar_rock_bricks", "anorthosite_bricks", "mare_basalt_bricks",
                                                "ancient_bricks", "regolith_bricks", "tektite_bricks", "olivine_bricks", "meteorite_bricks",
                                                "moonstone_bricks", "polished_lunar_rock", "anorthosite", "mare_basalt")):
                continue
            nm = f"{base}_{sfx}"
            block(nm, f"{sfr} : {bb['fr']}", f"{bb['en']} {sen}", kind=kind, base=base, hard=bb["hard"], need=bb["need"],
                  light=bb["light"], glass=False, sound=bb["sound"], tool=bb["tool"], texture="@" + base)
            shaped(I(nm), pat, {"R": I(base)}, n)
