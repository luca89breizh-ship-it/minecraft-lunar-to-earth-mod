"""Tables de contenu de Lunaire : objets, blocs, minerais, recettes. Source unique (Python -> JSON pour Java)."""
M = "lunaire:"

# ----------------------------------------------------------------------------- matériaux
MAT = {
    "copper": (205, 115, 70), "tin": (200, 205, 212), "aluminum": (215, 222, 235), "titanium": (125, 150, 195),
    "nickel": (170, 178, 150), "silver": (228, 232, 242), "lithium": (205, 185, 220), "steel": (105, 112, 125),
    "bronze": (195, 135, 60), "lunar_alloy": (70, 120, 170), "iron": (200, 200, 205),
}

ITEMS = []     # dicts : name, fr, en, + options Java
BLOCKS = []    # dicts
RECIPES = []   # dicts (voir gen_all)


def item(name, fr, en, **kw):
    ITEMS.append(dict(name=name, fr=fr, en=en, **kw))


def block(name, fr, en, **kw):
    d = dict(name=name, fr=fr, en=en, kind="all", tool="pickaxe", hard=3.0, need="wood", drop=None,
             light=0, glass=False, count=None, sound="stone")
    d.update(kw)
    BLOCKS.append(d)


FR_MAT = {"copper": "cuivre", "tin": "étain", "aluminum": "aluminium", "titanium": "titane", "nickel": "nickel",
          "silver": "argent", "lithium": "lithium", "steel": "acier", "bronze": "bronze", "lunar_alloy": "alliage lunaire",
          "iron": "fer"}
EN_MAT = {"copper": "Copper", "tin": "Tin", "aluminum": "Aluminum", "titanium": "Titanium", "nickel": "Nickel",
          "silver": "Silver", "lithium": "Lithium", "steel": "Steel", "bronze": "Bronze", "lunar_alloy": "Lunar Alloy",
          "iron": "Iron"}


def build():
    ITEMS.clear(), BLOCKS.clear(), RECIPES.clear()

    # ---------------------------------------------------------------- lingots, plaques, engrenages, fils, tiges
    for m in ("copper", "tin", "aluminum", "titanium", "nickel", "silver", "lithium", "steel", "bronze", "lunar_alloy"):
        item(f"{m}_ingot", f"Lingot de {FR_MAT[m]}", f"{EN_MAT[m]} Ingot", form="ingot", mat=m)
    for m in ("iron", "copper", "aluminum", "titanium", "steel", "bronze", "lunar_alloy", "nickel"):
        item(f"{m}_plate", f"Plaque de {FR_MAT[m]}", f"{EN_MAT[m]} Plate", form="plate", mat=m)
    for m in ("steel", "titanium", "bronze", "aluminum", "copper"):
        item(f"{m}_gear", f"Engrenage en {FR_MAT[m]}", f"{EN_MAT[m]} Gear", form="gear", mat=m)
    for m in ("copper", "aluminum", "silver"):
        item(f"{m}_wire", f"Fil de {FR_MAT[m]}", f"{EN_MAT[m]} Wire", form="wire", mat=m)
    for m in ("steel", "titanium", "aluminum"):
        item(f"{m}_rod", f"Tige de {FR_MAT[m]}", f"{EN_MAT[m]} Rod", form="rod", mat=m)

    # ---------------------------------------------------------------- gemmes et matières
    item("moonstone", "Pierre de lune", "Moonstone", form="gem", color=(170, 200, 255))
    item("olivine", "Olivine", "Olivine", form="gem", color=(120, 200, 70))
    item("helium3_crystal", "Cristal d'hélium-3", "Helium-3 Crystal", custom=True)
    item("meteorite_shard", "Éclat de météorite", "Meteorite Shard", custom=True)
    item("silicon", "Silicium", "Silicon", custom=True)
    item("silicon_wafer", "Plaquette de silicium", "Silicon Wafer", custom=True)
    item("iron_scrap", "Morceau de fer", "Iron Scrap", custom=True)
    item("algae_culture", "Culture d'algues", "Algae Culture", form="pile", color=(70, 170, 90))

    # ---------------------------------------------------------------- composants
    for n, fr, en in [
        ("circuit_board", "Circuit imprimé", "Circuit Board"), ("advanced_circuit", "Circuit avancé", "Advanced Circuit"),
        ("processor", "Processeur", "Processor"), ("lithium_battery", "Batterie au lithium", "Lithium Battery"),
        ("solar_cell", "Cellule solaire", "Solar Cell"), ("heat_shield_tile", "Tuile de bouclier thermique", "Heat Shield Tile"),
        ("insulation", "Isolant thermique", "Thermal Insulation"), ("thruster", "Propulseur", "Thruster"),
        ("fuel_tank", "Réservoir de carburant", "Fuel Tank"), ("rocket_engine", "Moteur de fusée", "Rocket Engine"),
        ("nose_cone", "Ogive", "Nose Cone"), ("hull_panel", "Panneau de coque", "Hull Panel"),
        ("parachute", "Parachute", "Parachute"), ("life_support_unit", "Unité de survie", "Life Support Unit"),
        ("power_core", "Noyau d'énergie", "Power Core"), ("pressure_valve", "Valve de pression", "Pressure Valve"),
        ("visor_lens", "Lentille de visière", "Visor Lens"), ("oxygen_tank", "Réservoir d'O₂ vide", "Empty O2 Tank"),
        ("oxygen_tank_large", "Grand réservoir d'O₂", "Large O2 Tank"), ("hydrogen_cell", "Cellule d'hydrogène", "Hydrogen Cell"),
        ("rocket_fuel", "Carburant de fusée", "Rocket Fuel"), ("coolant_canister", "Bidon de liquide de refroidissement", "Coolant Canister"),
        ("oxygen_bottle", "Bouteille d'O₂ vide", "Empty O2 Bottle"),
    ]:
        item(n, fr, en, custom=True)
    item("oxygen_tank_full", "Réservoir d'O₂ plein", "Full O2 Tank", custom=True, stack=4,
         use=dict(o2=2000, returns=M + "oxygen_tank", msg="+O₂"))
    item("oxygen_bottle_full", "Bouteille d'O₂ pleine", "Full O2 Bottle", custom=True, stack=16,
         use=dict(o2=1000, returns=M + "oxygen_bottle", msg="+O₂"))

    # ---------------------------------------------------------------- objets spéciaux
    item("damaged_air_purifier", "Épurateur d'air portatif endommagé", "Damaged Portable Air Purifier", custom=True, stack=1)
    item("air_purifier", "Épurateur d'air portatif", "Portable Air Purifier", custom=True, stack=1)
    item("blueprint_tier1", "Schéma de fusée (Tier 1)", "Rocket Blueprint (Tier 1)", custom=True, stack=1,
         use=dict(cmds=["xp add %p 3 levels"], msg="Vous étudiez le schéma : +3 niveaux."))
    item("blueprint_tier2", "Schéma de fusée (Tier 2)", "Rocket Blueprint (Tier 2)", custom=True, stack=1,
         use=dict(cmds=["xp add %p 6 levels"], msg="Vous étudiez le schéma : +6 niveaux."))
    item("rocket_blueprint", "Schéma de fusée (Tier 3)", "Rocket Blueprint (Tier 3)", custom=True, stack=1)
    item("reentry_module", "Module de rentrée atmosphérique", "Atmospheric Reentry Module", custom=True, stack=1)
    item("oxygen_scanner", "Scanner d'oxygène", "Oxygen Scanner", custom=True, stack=1, use=dict(scan=True, keep=True))
    item("jet_booster", "Propulseur dorsal (usage unique)", "Jet Booster (single use)", custom=True, stack=8,
         use=dict(cmds=["effect give %p minecraft:levitation 3 4 true", "effect give %p minecraft:slow_falling 20 0 true"],
                  msg="Propulsion !"))
    item("repair_kit", "Kit de réparation", "Repair Kit", custom=True, stack=8,
         use=dict(cmds=["effect give %p minecraft:resistance 90 1 true", "effect give %p minecraft:regeneration 10 1 true"],
                  msg="Combinaison renforcée pour 90 s."))
    item("medkit", "Trousse de soins", "Medkit", custom=True, stack=8,
         use=dict(cmds=["effect give %p minecraft:instant_health 1 3 true", "effect give %p minecraft:regeneration 20 2 true"],
                  msg="Soins appliqués."))
    item("thermal_pack", "Pack chauffant", "Thermal Pack", custom=True, stack=8,
         use=dict(warm=6000, msg="Protégé du froid pendant 5 minutes."))
    item("cooling_pack", "Pack de refroidissement", "Cooling Pack", custom=True, stack=8,
         use=dict(cool=6000, msg="Protégé de la chaleur pendant 5 minutes."))

    # ---------------------------------------------------------------- nourriture
    for n, fr, en, cmds in [
        ("algae_bar", "Barre d'algues", "Algae Bar", ["effect give %p minecraft:saturation 1 2 true"]),
        ("nutrient_paste", "Pâte nutritive", "Nutrient Paste", ["effect give %p minecraft:saturation 1 4 true"]),
        ("protein_ration", "Ration protéinée", "Protein Ration", ["effect give %p minecraft:saturation 1 7 true", "effect give %p minecraft:regeneration 5 0 true"]),
        ("energy_gel", "Gel énergétique", "Energy Gel", ["effect give %p minecraft:saturation 1 3 true", "effect give %p minecraft:speed 60 1 true"]),
        ("space_stew", "Ragoût spatial", "Space Stew", ["effect give %p minecraft:saturation 1 9 true", "effect give %p minecraft:resistance 60 0 true"]),
        ("hydroponic_salad", "Salade hydroponique", "Hydroponic Salad", ["effect give %p minecraft:saturation 1 6 true", "effect give %p minecraft:regeneration 10 1 true"]),
    ]:
        item(n, fr, en, custom=True, stack=16, use=dict(cmds=cmds, msg="Miam."))

    # ---------------------------------------------------------------- outils
    for mat, fr in (("lunar_rock", "roche lunaire"), ("steel", "acier"), ("titanium", "titane"), ("lunar_alloy", "alliage lunaire")):
        for t, tfr, ten in (("pickaxe", "Pioche", "Pickaxe"), ("axe", "Hache", "Axe"), ("shovel", "Pelle", "Shovel"),
                            ("sword", "Épée", "Sword"), ("hoe", "Houe", "Hoe")):
            en_m = {"lunar_rock": "Lunar Rock", "steel": "Steel", "titanium": "Titanium", "lunar_alloy": "Lunar Alloy"}[mat]
            item(f"{mat}_{t}", f"{tfr} en {fr}", f"{en_m} {ten}", tool=t, mat=mat, stack=1)

    # ---------------------------------------------------------------- armures
    for suit, fr, en in (("survival_suit", "combinaison de survie", "Survival Suit"),
                         ("spacesuit", "combinaison renforcée", "Reinforced Spacesuit"),
                         ("orbital_suit", "combinaison orbitale", "Orbital Suit")):
        for slot, sfr, sen in (("helmet", "Casque de", "Helmet"), ("chestplate", "Plastron de", "Chestplate"),
                               ("leggings", "Jambières de", "Leggings"), ("boots", "Bottes de", "Boots")):
            item(f"{suit}_{slot}", f"{sfr} {fr}", f"{en} {sen}", armor=slot, suit=suit, stack=1)

    # ================================================================ BLOCS
    # minerais : (nom, fr, en, couleur, dureté, outil requis, drop, nb min-max, taille, nombre/chunk, yMin, yMax, lumière)
    ORES = [
        ("lunar_iron_ore", "Minerai de fer lunaire", "Lunar Iron Ore", (205, 150, 120), 3.0, "stone", "minecraft:iron_ingot", None, 9, 20, -60, 120, 0),
        ("lunar_copper_ore", "Minerai de cuivre lunaire", "Lunar Copper Ore", (215, 120, 70), 3.0, "stone", M + "copper_ingot", (1, 3), 10, 16, -40, 110, 0),
        ("tin_ore", "Minerai d'étain", "Tin Ore", (200, 205, 212), 3.0, "stone", M + "tin_ingot", None, 8, 12, -30, 90, 0),
        ("aluminum_ore", "Minerai d'aluminium", "Aluminum Ore", (225, 232, 245), 3.0, "stone", M + "aluminum_ingot", None, 8, 12, -30, 100, 0),
        ("titanium_ore", "Minerai de titane", "Titanium Ore", (130, 160, 220), 4.0, "iron", M + "titanium_ingot", None, 6, 6, -64, 30, 0),
        ("nickel_ore", "Minerai de nickel", "Nickel Ore", (170, 185, 140), 3.5, "iron", M + "nickel_ingot", None, 7, 8, -50, 60, 0),
        ("silver_ore", "Minerai d'argent", "Silver Ore", (230, 235, 245), 3.5, "iron", M + "silver_ingot", None, 6, 6, -50, 40, 0),
        ("lithium_ore", "Minerai de lithium", "Lithium Ore", (215, 185, 235), 3.5, "iron", M + "lithium_ingot", None, 5, 6, -64, 20, 0),
        ("helium3_ore", "Minerai d'hélium-3", "Helium-3 Ore", (240, 215, 100), 4.0, "diamond", M + "helium3_crystal", (1, 2), 4, 3, -64, 0, 5),
        ("moonstone_ore", "Minerai de pierre de lune", "Moonstone Ore", (170, 205, 255), 4.0, "iron", M + "moonstone", (1, 2), 4, 2, -64, 16, 3),
        ("olivine_ore", "Minerai d'olivine", "Olivine Ore", (120, 205, 80), 3.5, "iron", M + "olivine", (1, 2), 3, 3, -64, 40, 0),
        ("meteorite_ore", "Minerai de météorite", "Meteorite Ore", (140, 80, 210), 4.5, "iron", M + "meteorite_shard", (1, 3), 4, 4, -20, 120, 2),
    ]
    for o in ORES:
        block(o[0], o[1], o[2], color=o[3], hard=o[4], need=o[5], drop=o[6], count=o[7], ore=dict(
            size=o[8], per_chunk=o[9], y_min=o[10], y_max=o[11]), light=o[12], texture="ore")
    # blocs de base
    block("regolith", "Régolithe", "Regolith", tool="shovel", hard=0.6, need=None, sound="gravel", texture="regolith")
    block("hydrated_regolith", "Régolithe hydratée", "Hydrated Regolith", tool="shovel", hard=0.6, need=None, sound="gravel", texture="hydrated")
    block("lunar_rock", "Roche lunaire", "Lunar Rock", hard=2.0, texture="rock")
    block("lunar_ice", "Glace lunaire", "Lunar Ice", hard=0.8, sound="glass", texture="ice")
    block("polished_lunar_rock", "Roche lunaire polie", "Polished Lunar Rock", hard=2.0, texture="polished")
    block("lunar_rock_bricks", "Briques de roche lunaire", "Lunar Rock Bricks", hard=2.0, texture="bricks_rock")
    block("regolith_bricks", "Briques de régolithe", "Regolith Bricks", hard=1.8, texture="bricks_rego")
    block("regolith_glass", "Verre de régolithe", "Regolith Glass", hard=0.5, glass=True, sound="glass", need=None, texture="glass")
    block("reinforced_glass", "Verre renforcé", "Reinforced Glass", hard=3.0, glass=True, sound="glass", texture="glass_r")
    block("meteorite_block", "Bloc de météorite", "Meteorite Block", hard=5.0, need="iron", light=3, texture="meteor")
    for m in ("copper", "tin", "aluminum", "titanium", "steel", "bronze", "lunar_alloy", "nickel", "silver"):
        block(f"{m}_block", f"Bloc de {FR_MAT[m]}", f"Block of {EN_MAT[m]}", hard=4.0, need="stone", texture="metal", mat=m, sound="metal")
    # laboratoires & ruines
    block("lab_plating", "Plaque de laboratoire", "Lab Plating", hard=3.0, sound="metal", texture="lab_plating")
    block("lab_floor", "Sol de laboratoire", "Lab Floor", hard=3.0, sound="metal", texture="lab_floor")
    block("lab_light", "Lampe de laboratoire", "Lab Light", hard=2.0, light=15, sound="glass", texture="lab_light")
    block("lab_vent", "Aération de laboratoire", "Lab Vent", hard=2.0, sound="metal", texture="lab_vent")
    block("ancient_stone", "Pierre ancienne", "Ancient Stone", hard=3.0, texture="ancient")
    block("ancient_bricks", "Briques anciennes", "Ancient Bricks", hard=3.0, texture="ancient_bricks")
    block("ancient_glyph", "Glyphe ancien", "Ancient Glyph", hard=3.0, light=9, texture="glyph")
    # machines
    block("solar_panel", "Panneau solaire", "Solar Panel", kind="column", hard=2.0, sound="metal", texture="m_solar")
    block("atmosphere_sealer", "Scelleur d'atmosphère", "Atmosphere Sealer", kind="column", hard=3.0, sound="metal", texture="m_sealer")
    block("electrolyzer", "Électrolyseur", "Electrolyzer", kind="column", hard=3.0, sound="metal", texture="m_electro")
    block("oxygen_compressor", "Compresseur d'O₂", "Oxygen Compressor", kind="column", hard=3.0, sound="metal", texture="m_compressor")
    block("hydrogen_generator", "Générateur à hydrogène", "Hydrogen Generator", kind="lit", hard=3.0, sound="metal", light=8, texture="m_hydrogen")
    block("radiator", "Radiateur", "Radiator", kind="radiator", hard=3.0, sound="metal", light=10, texture="m_radiator")
    block("launch_platform", "Plateforme de lancement", "Launch Platform", hard=5.0, sound="metal", texture="launch")

    # ================================================================ RECETTES (table de craft)
    R = RECIPES

    def shaped(result, pattern, key, n=1):
        R.append(dict(type="shaped", result=result, pattern=pattern, key=key, n=n))

    def shapeless(result, ings, n=1):
        R.append(dict(type="shapeless", result=result, ingredients=ings, n=n))

    I = lambda x: M + x
    # plaques / tiges / engrenages / fils
    for m in ("copper", "aluminum", "titanium", "steel", "bronze", "lunar_alloy", "nickel"):
        shaped(I(f"{m}_plate"), ["II"], {"I": I(f"{m}_ingot")})
    shaped(I("iron_plate"), ["II"], {"I": "minecraft:iron_ingot"})
    for m in ("steel", "titanium", "aluminum"):
        shaped(I(f"{m}_rod"), ["I", "I"], {"I": I(f"{m}_ingot")}, 2)
    for m, center in (("steel", I("steel_rod")), ("titanium", I("titanium_rod")), ("aluminum", I("aluminum_rod")),
                      ("bronze", I("bronze_ingot")), ("copper", I("copper_ingot"))):
        shaped(I(f"{m}_gear"), [" P ", "PRP", " P "], {"P": I(f"{m}_plate"), "R": center})
    for m in ("copper", "aluminum", "silver"):
        shapeless(I(f"{m}_wire"), [I(f"{m}_ingot")], 3)
    # alliages
    shapeless(I("steel_ingot"), ["minecraft:iron_ingot", "minecraft:iron_ingot", I("nickel_ingot")], 2)
    shapeless(I("bronze_ingot"), [I("copper_ingot")] * 3 + [I("tin_ingot")], 4)
    shapeless(I("lunar_alloy_ingot"), [I("titanium_ingot"), I("titanium_ingot"), I("steel_ingot"), I("meteorite_shard")], 2)
    # blocs de métal
    for m in ("copper", "tin", "aluminum", "titanium", "steel", "bronze", "lunar_alloy", "nickel", "silver"):
        shaped(I(f"{m}_block"), ["III", "III", "III"], {"I": I(f"{m}_ingot")})
        shapeless(I(f"{m}_ingot"), [I(f"{m}_block")], 9)
    shaped(I("meteorite_block"), ["SSS", "SSS", "SSS"], {"S": I("meteorite_shard")})
    shapeless(I("meteorite_shard"), [I("meteorite_block")], 9)
    # silicium, électronique
    shapeless(I("silicon"), [I("regolith")] * 4, 2)
    shaped(I("silicon_wafer"), ["SS", "SS"], {"S": I("silicon")})
    shaped(I("circuit_board"), ["WWW", "SSS"], {"W": I("copper_wire"), "S": I("silicon")}, 2)
    shaped(I("advanced_circuit"), ["WSW", "CCC", "WSW"], {"W": I("silver_wire"), "S": I("silicon_wafer"), "C": I("circuit_board")})
    shaped(I("processor"), ["ASA", "SDS", "ASA"], {"A": I("advanced_circuit"), "S": I("silicon_wafer"), "D": I("moonstone")})
    shaped(I("lithium_battery"), [" W ", "PLP", "PLP"], {"W": I("copper_wire"), "P": I("aluminum_plate"), "L": I("lithium_ingot")})
    shaped(I("solar_cell"), ["GGG", "SSS", "WWW"], {"G": I("regolith_glass"), "S": I("silicon_wafer"), "W": I("silver_wire")})
    shapeless(I("insulation"), [I("silicon"), I("silicon"), I("lunar_ice")], 2)
    shaped(I("heat_shield_tile"), ["RSR", "SIS", "RSR"], {"R": I("regolith_bricks"), "S": I("silicon"), "I": I("insulation")}, 2)
    shaped(I("hull_panel"), ["TPT", "PIP", "TPT"], {"T": I("titanium_plate"), "P": I("aluminum_plate"), "I": I("insulation")}, 2)
    shaped(I("pressure_valve"), [" R ", "PGP"], {"R": I("steel_rod"), "P": I("steel_plate"), "G": I("steel_gear")})
    shaped(I("oxygen_bottle"), ["A", "A"], {"A": I("aluminum_plate")}, 2)
    shaped(I("oxygen_tank"), ["PVP", "P P", "PPP"], {"P": I("aluminum_plate"), "V": I("pressure_valve")})
    shaped(I("oxygen_tank_large"), ["TVT", "T T", "TTT"], {"T": I("titanium_plate"), "V": I("pressure_valve")})
    shaped(I("hydrogen_cell"), ["PWP", "PBP", "PWP"], {"P": I("aluminum_plate"), "W": I("copper_wire"), "B": I("oxygen_bottle")}, 2)
    shapeless(I("rocket_fuel"), [I("hydrogen_cell")] * 3 + [I("oxygen_bottle_full")])
    shaped(I("coolant_canister"), ["APA", "ALA", "AAA"], {"A": I("aluminum_plate"), "P": I("pressure_valve"), "L": I("lunar_ice")})
    shaped(I("power_core"), ["BNB", "NHN", "BNB"], {"B": I("lithium_battery"), "N": I("nickel_plate"), "H": I("helium3_crystal")})
    shaped(I("visor_lens"), ["GGG", "GMG", "GGG"], {"G": I("reinforced_glass"), "M": I("moonstone")})
    shaped(I("life_support_unit"), [" T ", "VCV", "BPB"], {"T": I("oxygen_tank_large"), "V": I("pressure_valve"),
                                                       "C": I("advanced_circuit"), "B": I("lithium_battery"), "P": I("power_core")})
    shaped(I("parachute"), ["III", "I I", " R "], {"I": I("insulation"), "R": I("aluminum_rod")})
    # fusée
    shaped(I("thruster"), ["PVP", "PCP", "T T"], {"P": I("steel_plate"), "V": I("pressure_valve"), "C": I("coolant_canister"), "T": I("titanium_plate")})
    shaped(I("fuel_tank"), ["PVP", "PIP", "PPP"], {"P": I("steel_plate"), "V": I("pressure_valve"), "I": I("insulation")})
    shaped(I("rocket_engine"), ["TFT", "HHH", "P P"], {"T": I("titanium_plate"), "F": I("fuel_tank"), "H": I("thruster"), "P": I("steel_plate")})
    shaped(I("nose_cone"), [" H ", "HIH", "PPP"], {"H": I("heat_shield_tile"), "I": I("insulation"), "P": I("titanium_plate")})
    shaped(I("reentry_module"), [" N ", "HPH", "TCT"], {"N": I("nose_cone"), "H": I("hull_panel"), "P": I("parachute"),
                                                   "T": I("thruster"), "C": I("processor")})
    shaped(I("launch_platform"), ["TTT", "HPH", "SSS"], {"T": I("titanium_plate"), "H": I("hull_panel"), "P": I("processor"), "S": I("lunar_alloy_plate")})
    # utilitaires
    shaped(I("oxygen_scanner"), [" L ", "ACA", "ABA"], {"L": I("visor_lens"), "A": I("aluminum_plate"), "C": I("advanced_circuit"), "B": I("lithium_battery")})
    shaped(I("jet_booster"), ["PFP", "PTP", "T T"], {"P": I("steel_plate"), "F": I("rocket_fuel"), "T": I("thruster")})
    shaped(I("repair_kit"), ["SWS", "PCP", "SSS"], {"S": I("steel_plate"), "W": I("copper_wire"), "P": I("steel_gear"), "C": I("circuit_board")})
    shaped(I("medkit"), ["APA", "IMI", "AAA"], {"A": I("aluminum_plate"), "P": I("energy_gel"), "I": I("insulation"), "M": I("moonstone")})
    shaped(I("thermal_pack"), ["III", "IHI", "III"], {"I": I("insulation"), "H": I("hydrogen_cell")})
    shaped(I("cooling_pack"), ["III", "ICI", "III"], {"I": I("insulation"), "C": I("coolant_canister")})
    shapeless(I("air_purifier"), [I("damaged_air_purifier"), I("circuit_board"), I("iron_scrap")])
    # nourriture
    shapeless(I("algae_culture"), [I("lunar_ice"), I("hydrated_regolith")], 4)
    shapeless(I("algae_bar"), [I("algae_culture")] * 2, 2)
    shapeless(I("nutrient_paste"), [I("algae_culture")] * 3)
    shapeless(I("energy_gel"), [I("nutrient_paste")] * 2)
    shapeless(I("protein_ration"), [I("algae_bar"), I("algae_bar"), I("nutrient_paste")])
    shapeless(I("space_stew"), [I("protein_ration"), I("algae_culture"), I("lunar_ice")])
    shapeless(I("hydroponic_salad"), [I("algae_culture")] * 3 + [I("algae_bar")])
    # outils
    for t, pat in (("pickaxe", ["III", " R ", " R "]), ("axe", ["II", "IR", " R"]), ("shovel", ["I", "R", "R"]),
                   ("sword", ["I", "I", "R"]), ("hoe", ["II", " R", " R"])):
        shaped(I(f"lunar_rock_{t}"), [p.replace("I", "I") for p in pat], {"I": I("lunar_rock"), "R": I("iron_scrap")})
        shaped(I(f"steel_{t}"), pat, {"I": I("steel_ingot"), "R": I("steel_rod")})
        shaped(I(f"titanium_{t}"), pat, {"I": I("titanium_ingot"), "R": I("titanium_rod")})
        shaped(I(f"lunar_alloy_{t}"), pat, {"I": I("lunar_alloy_ingot"), "R": I("titanium_rod")})
    # armures
    for slot, pat in (("helmet", ["AAA", "ALA"]), ("chestplate", ["A A", "AIA", "AAA"]),
                      ("leggings", ["AIA", "A A", "A A"]), ("boots", ["A A", "I I"])):
        shaped(I(f"survival_suit_{slot}"), pat, {"A": I("aluminum_plate"), "L": I("visor_lens"), "I": I("insulation")})
        shaped(I(f"spacesuit_{slot}"), [" T ", "TST", " I "],
               {"T": I("titanium_plate"), "S": I(f"survival_suit_{slot}"), "I": I("insulation")})
    shaped(I("orbital_suit_helmet"), ["ALA", "XSX", "AVA"], {"A": I("lunar_alloy_plate"), "L": I("visor_lens"), "X": I("advanced_circuit"),
                                                           "S": I("spacesuit_helmet"), "V": I("pressure_valve")})
    shaped(I("orbital_suit_chestplate"), ["APA", "USU", "BCB"], {"A": I("lunar_alloy_plate"), "P": I("power_core"), "U": I("life_support_unit"),
                                                               "S": I("spacesuit_chestplate"), "B": I("lithium_battery"), "C": I("processor")})
    shaped(I("orbital_suit_leggings"), ["ABA", "XSX", "AVA"], {"A": I("lunar_alloy_plate"), "B": I("lithium_battery"), "X": I("advanced_circuit"),
                                                             "S": I("spacesuit_leggings"), "V": I("pressure_valve")})
    shaped(I("orbital_suit_boots"), ["AXA", "XSX", "H H"], {"A": I("lunar_alloy_plate"), "X": I("advanced_circuit"),
                                                          "S": I("spacesuit_boots"), "H": I("heat_shield_tile")})
    # blocs de construction
    shaped(I("polished_lunar_rock"), ["RR", "RR"], {"R": I("lunar_rock")}, 4)
    shaped(I("lunar_rock_bricks"), ["RR", "RR"], {"R": I("polished_lunar_rock")}, 4)
    shaped(I("regolith_bricks"), ["RR", "RR"], {"R": I("regolith")}, 4)
    shapeless(I("regolith_glass"), [I("regolith")] * 4 + [I("silicon")], 4)
    shaped(I("reinforced_glass"), ["GG", "GP"], {"G": I("regolith_glass"), "P": I("titanium_plate")}, 3)
    shaped(I("lab_plating"), ["SA", "AS"], {"S": I("steel_plate"), "A": I("aluminum_plate")}, 4)
    shaped(I("lab_floor"), ["PP", "PP"], {"P": I("lab_plating")}, 4)
    shapeless(I("lab_light"), [I("lab_plating"), I("copper_wire"), I("helium3_crystal")], 2)
    shapeless(I("lab_vent"), [I("lab_plating"), I("steel_gear")], 2)
    shaped(I("ancient_bricks"), ["AA", "AA"], {"A": I("ancient_stone")}, 4)
    shapeless(I("ancient_glyph"), [I("ancient_bricks"), I("meteorite_shard")])
    # machines
    shaped(I("solar_panel"), ["CCC", "ABA", "SSS"], {"C": I("solar_cell"), "A": I("aluminum_plate"), "B": I("lithium_battery"), "S": I("steel_plate")})
    shaped(I("atmosphere_sealer"), ["TVT", "AOA", "TLT"], {"T": I("titanium_plate"), "V": I("pressure_valve"), "A": I("advanced_circuit"),
                                                          "O": I("oxygen_tank_large"), "L": I("lab_plating")})
    shaped(I("electrolyzer"), ["SWS", "BTB", "SPS"], {"S": I("steel_plate"), "W": I("copper_wire"), "B": I("lithium_battery"),
                                                     "T": I("oxygen_tank"), "P": I("pressure_valve")})
    shaped(I("oxygen_compressor"), ["SGS", "VTV", "SCS"], {"S": I("steel_plate"), "G": I("steel_gear"), "V": I("pressure_valve"),
                                                          "T": I("oxygen_tank"), "C": I("circuit_board")})
    shaped(I("hydrogen_generator"), ["SVS", "GPG", "SBS"], {"S": I("steel_plate"), "V": I("pressure_valve"), "G": I("steel_gear"),
                                                           "P": I("hydrogen_cell"), "B": I("lithium_battery")})
    shaped(I("radiator"), ["AAA", "CPC", "AAA"], {"A": I("aluminum_plate"), "C": I("copper_plate"), "P": I("coolant_canister")})


build()


# ============================================================================ v0.4 : pierres, objets utiles, recettes
def build_extra():
    R = RECIPES
    I = lambda x: M + x

    def shaped(result, pattern, key, n=1):
        R.append(dict(type="shaped", result=result, pattern=pattern, key=key, n=n))

    def shapeless(result, ings, n=1):
        R.append(dict(type="shapeless", result=result, ingredients=ings, n=n))

    # --- nouvelles pierres (biomes lunaires : hautes terres claires, mers de basalte sombres)
    block("anorthosite", "Anorthosite", "Anorthosite", hard=1.8, texture="st_anorthosite")
    block("polished_anorthosite", "Anorthosite polie", "Polished Anorthosite", hard=1.8, texture="st_polished_anorthosite")
    block("anorthosite_bricks", "Briques d'anorthosite", "Anorthosite Bricks", hard=1.8, texture="st_anorthosite_bricks")
    block("mare_basalt", "Basalte des mers", "Mare Basalt", hard=2.4, texture="st_mare_basalt")
    block("polished_mare_basalt", "Basalte des mers poli", "Polished Mare Basalt", hard=2.4, texture="st_polished_mare_basalt")
    block("mare_basalt_bricks", "Briques de basalte des mers", "Mare Basalt Bricks", hard=2.4, texture="st_mare_basalt_bricks")
    block("tektite", "Tectite", "Tektite", hard=2.0, light=4, texture="st_tektite")
    block("lunar_dust", "Poussière lunaire", "Lunar Dust", tool="shovel", hard=0.4, need=None, sound="gravel", texture="st_lunar_dust")
    block("impact_glass", "Verre d'impact", "Impact Glass", hard=0.8, glass=True, sound="glass", need=None, texture="st_impact_glass")
    block("moon_lantern", "Lanterne lunaire", "Moon Lantern", hard=1.5, light=15, sound="glass", texture="st_lantern")
    block("cracked_lunar_rock", "Roche lunaire fissurée", "Cracked Lunar Rock", hard=1.8, texture="st_cracked")
    block("glowing_olivine_block", "Bloc d'olivine", "Olivine Block", hard=3.0, light=6, need="iron", texture="st_olivine_block")
    block("moonstone_block", "Bloc de pierre de lune", "Moonstone Block", hard=3.0, light=10, need="iron", texture="st_moonstone_block")
    shaped(I("polished_anorthosite"), ["RR", "RR"], {"R": I("anorthosite")}, 4)
    shaped(I("anorthosite_bricks"), ["RR", "RR"], {"R": I("polished_anorthosite")}, 4)
    shaped(I("polished_mare_basalt"), ["RR", "RR"], {"R": I("mare_basalt")}, 4)
    shaped(I("mare_basalt_bricks"), ["RR", "RR"], {"R": I("polished_mare_basalt")}, 4)
    shaped(I("impact_glass"), ["TT"], {"T": I("tektite")}, 2)
    shaped(I("lunar_dust"), ["RR", "RR"], {"R": I("iron_scrap")}, 1)
    shapeless(I("cracked_lunar_rock"), [I("lunar_rock"), I("iron_scrap")])
    shaped(I("moon_lantern"), [" P ", "GLG", " P "], {"P": I("steel_plate"), "G": I("regolith_glass"), "L": I("helium3_crystal")})
    shaped(I("glowing_olivine_block"), ["OOO", "OOO", "OOO"], {"O": I("olivine")})
    shaped(I("moonstone_block"), ["MMM", "MMM", "MMM"], {"M": I("moonstone")})
    shapeless(I("olivine"), [I("glowing_olivine_block")], 9)
    shapeless(I("moonstone"), [I("moonstone_block")], 9)

    # --- objets utiles (clic droit)
    item("oxygen_pill", "Pilule d'oxygène", "Oxygen Pill", pill=(120, 220, 255), stack=16,
         use=dict(o2=400, msg="Une bouffée d'air ! +O₂"))
    item("adrenaline_shot", "Seringue d'adrénaline", "Adrenaline Shot", vial=(230, 70, 70), stack=8,
         use=dict(cmds=["effect give %p minecraft:speed 40 2 true", "effect give %p minecraft:strength 40 1 true"],
                  msg="Adrénaline !"))
    item("night_vision_pill", "Pilule de vision nocturne", "Night Vision Pill", pill=(160, 255, 130), stack=16,
         use=dict(cmds=["effect give %p minecraft:night_vision 300 0 true"], msg="Vous voyez dans le noir."))
    item("spring_serum", "Sérum à ressort", "Spring Serum", vial=(120, 255, 180), stack=8,
         use=dict(cmds=["effect give %p minecraft:jump_boost 120 2 true"], msg="Vos jambes sont des ressorts."))
    item("stasis_capsule", "Capsule de stase", "Stasis Capsule", pill=(190, 160, 255), stack=4,
         use=dict(cmds=["effect give %p minecraft:resistance 20 4 true", "effect give %p minecraft:slowness 20 3 true"],
                  msg="Stase activée pendant 20 s."))
    item("signal_flare", "Fusée éclairante", "Signal Flare", flare=True, stack=8,
         use=dict(cmds=["execute as %p at @s run effect give @e[distance=..48] minecraft:glowing 20 0 true"],
                  msg="Tout ce qui vit autour de vous brille."))
    item("radar_pulse", "Impulsion radar", "Radar Pulse", radar=True, stack=8,
         use=dict(cmds=["execute as %p at @s run effect give @e[type=lunaire:selenite,distance=..64] minecraft:glowing 15 0 true",
                        "execute as %p at @s run effect give @e[type=lunaire:dust_golem,distance=..64] minecraft:glowing 15 0 true"],
                  msg="Impulsion envoyée : les créatures lunaires sont révélées."))
    item("moon_compass", "Boussole lunaire", "Moon Compass", compass=True, stack=1, use=dict(pos=True, keep=True))
    item("moon_cheese", "Fromage lunaire", "Moon Cheese", food=(235, 215, 120), stack=16,
         use=dict(cmds=["effect give %p minecraft:saturation 1 5 true"], msg="Étonnamment bon."))
    item("emergency_ration", "Ration d'urgence", "Emergency Ration", food=(120, 160, 90), stack=16,
         use=dict(cmds=["effect give %p minecraft:saturation 1 8 true", "effect give %p minecraft:regeneration 8 1 true"],
                  msg="Ration avalée."))
    item("shock_absorber", "Amortisseur", "Shock Absorber", pill=(255, 200, 80), stack=8,
         use=dict(cmds=["effect give %p minecraft:slow_falling 60 0 true", "effect give %p minecraft:resistance 60 1 true"],
                  msg="Protégé pendant 60 s."))
    item("oxygen_candle", "Bougie à oxygène", "Oxygen Candle", flare=True, stack=8, color=(120, 200, 255),
         use=dict(o2=1500, msg="La bougie dégage de l'oxygène : +O₂"))
    shapeless(I("oxygen_pill"), [I("olivine"), I("algae_culture"), I("silicon")], 4)
    shapeless(I("adrenaline_shot"), [I("oxygen_bottle"), I("moonstone"), I("nutrient_paste")])
    shapeless(I("night_vision_pill"), [I("olivine"), I("silver_ingot")], 3)
    shapeless(I("spring_serum"), [I("olivine"), I("moonstone"), I("oxygen_bottle")])
    shapeless(I("stasis_capsule"), [I("titanium_plate"), I("insulation"), I("moonstone")])
    shapeless(I("signal_flare"), [I("helium3_crystal"), I("copper_wire"), I("iron_scrap")], 2)
    shapeless(I("radar_pulse"), [I("processor"), I("copper_wire"), I("silver_wire")])
    shaped(I("moon_compass"), [" S ", "SMS", " S "], {"S": I("steel_plate"), "M": I("moonstone")})
    shapeless(I("moon_cheese"), [I("algae_culture"), I("nutrient_paste"), I("lunar_ice")])
    shapeless(I("emergency_ration"), [I("protein_ration"), I("energy_gel")])
    shapeless(I("shock_absorber"), [I("aluminum_plate"), I("insulation"), I("olivine")])
    shapeless(I("oxygen_candle"), [I("oxygen_bottle_full"), I("olivine"), I("iron_scrap")])


build_extra()

KNOWN_VANILLA = {"minecraft:iron_ingot"}


def validate():
    names = {i["name"] for i in ITEMS} | {b["name"] for b in BLOCKS}
    bad = []

    def chk(x):
        if x.startswith(M):
            if x[len(M):] not in names:
                bad.append(x)
        elif x not in KNOWN_VANILLA:
            bad.append(x)

    for r in RECIPES:
        chk(r["result"])
        for v in (r.get("key") or {}).values():
            chk(v)
        for v in r.get("ingredients", []):
            chk(v)
    for b in BLOCKS:
        if b["drop"]:
            chk(b["drop"])
    return sorted(set(bad))
