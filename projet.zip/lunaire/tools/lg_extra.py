"""Succès, soleil, musique de la Lune."""
import math
import random
import struct
import subprocess
import wave
from lg_core import ASSETS, DATA, RES, Img, write_json

M = "lunaire:"

# id, parent, icône, type, argument, titre FR, description FR, titre EN, description EN, cadre, xp
ADV = [
    ("the_start", None, "regolith", "grant", None, "The Start", "Vous êtes sur la Lune. Pas d'air, peu de gravité, beaucoup de travail.",
     "The Start", "You are on the Moon. No air, low gravity, lots of work.", "task", 0),
    ("first_breath", "the_start", "oxygen_bottle", "item", ["oxygen_bottle", "oxygen_tank"], "Premier souffle", "Fabriquez une bouteille d'oxygène.",
     "First Breath", "Craft an oxygen bottle.", "task", 5),
    ("stone_age", "the_start", "lunar_rock_pickaxe", "item", ["lunar_rock_pickaxe"], "Âge de la roche lunaire", "Fabriquez une pioche en roche lunaire.",
     "Lunar Stone Age", "Craft a lunar rock pickaxe.", "task", 5),
    ("ice_ice", "the_start", "lunar_ice", "item", ["lunar_ice"], "Glace, glace, bébé", "Trouvez de la glace lunaire.",
     "Ice Ice Baby", "Find lunar ice.", "task", 5),
    ("fixed_purifier", "first_breath", "air_purifier", "item", ["air_purifier"], "Respirer mieux", "Réparez l'épurateur d'air.",
     "Breathe Easier", "Repair the air purifier.", "task", 10),
    ("first_metal", "stone_age", "copper_ingot", "item", ["copper_ingot", "tin_ingot", "lunar_iron_ore"], "Premier métal", "Obtenez du cuivre, de l'étain ou du fer lunaire.",
     "First Metal", "Obtain copper, tin or lunar iron.", "task", 5),
    ("light_metal", "first_metal", "aluminum_ingot", "item", ["aluminum_ingot"], "Métal léger", "Obtenez de l'aluminium.",
     "Light Metal", "Obtain aluminum.", "task", 10),
    ("titanium_age", "light_metal", "titanium_ingot", "item", ["titanium_ingot"], "Le Titane", "Obtenez du titane.",
     "Titanium", "Obtain titanium.", "goal", 20),
    ("bronze_age", "first_metal", "bronze_ingot", "item", ["bronze_ingot"], "Âge du bronze", "Fabriquez du bronze.",
     "Bronze Age", "Make bronze.", "task", 10),
    ("steel_age", "first_metal", "steel_ingot", "item", ["steel_ingot"], "Âge de l'acier", "Fabriquez de l'acier.",
     "Steel Age", "Make steel.", "task", 15),
    ("lunar_alloy", "titanium_age", "lunar_alloy_ingot", "item", ["lunar_alloy_ingot"], "Alliage lunaire", "Forgez de l'alliage lunaire.",
     "Lunar Alloy", "Forge lunar alloy.", "goal", 30),
    ("precious", "first_metal", "silver_ingot", "item", ["silver_ingot", "nickel_ingot", "lithium_ingot"], "Métaux rares", "Obtenez de l'argent, du nickel ou du lithium.",
     "Rare Metals", "Obtain silver, nickel or lithium.", "task", 10),
    ("fuel_of_future", "precious", "helium3_crystal", "item", ["helium3_crystal"], "Carburant du futur", "Minez de l'hélium-3.",
     "Fuel of the Future", "Mine helium-3.", "goal", 20),
    ("moonstone", "precious", "moonstone", "item", ["moonstone"], "Pierre de lune", "Trouvez une pierre de lune.",
     "Moonstone", "Find a moonstone.", "task", 10),
    ("olivine", "precious", "olivine", "item", ["olivine"], "Vert espoir", "Trouvez de l'olivine.",
     "Green Hope", "Find olivine.", "task", 10),
    ("from_the_sky", "precious", "meteorite_shard", "item", ["meteorite_shard"], "Venue du ciel", "Ramassez un éclat de météorite.",
     "From the Sky", "Pick up a meteorite shard.", "goal", 20),
    ("circuits", "steel_age", "circuit_board", "item", ["circuit_board"], "Électronique", "Fabriquez une carte électronique.",
     "Electronics", "Craft a circuit board.", "task", 10),
    ("processor", "circuits", "processor", "item", ["processor"], "Cerveau de bord", "Fabriquez un processeur.",
     "Onboard Brain", "Craft a processor.", "goal", 20),
    ("battery", "circuits", "lithium_battery", "item", ["lithium_battery"], "Plein d'énergie", "Fabriquez une batterie au lithium.",
     "Fully Charged", "Craft a lithium battery.", "task", 10),
    ("solar", "battery", "solar_panel", "item", ["solar_panel"], "Énergie solaire", "Posez de quoi capter le Soleil : fabriquez un panneau solaire.",
     "Solar Power", "Craft a solar panel.", "task", 15),
    ("electrolysis", "solar", "electrolyzer", "item", ["electrolyzer"], "De l'eau à l'air", "Fabriquez un électrolyseur.",
     "Water to Air", "Craft an electrolyzer.", "task", 15),
    ("compressor", "electrolysis", "oxygen_compressor", "item", ["oxygen_compressor"], "Sous pression", "Fabriquez un compresseur d'O₂.",
     "Under Pressure", "Craft an oxygen compressor.", "task", 15),
    ("home_sweet_home", "electrolysis", "atmosphere_sealer", "item", ["atmosphere_sealer"], "Chez soi", "Fabriquez un scelleur d'atmosphère.",
     "Home Sweet Home", "Craft an atmosphere sealer.", "goal", 25),
    ("warm", "solar", "radiator", "item", ["radiator", "hydrogen_generator"], "Au chaud", "Fabriquez un radiateur ou un générateur à hydrogène.",
     "Stay Warm", "Craft a radiator or hydrogen generator.", "task", 15),
    ("first_suit", "steel_age", "survival_suit_chestplate", "item", ["survival_suit_chestplate", "survival_suit_helmet"], "Premier scaphandre", "Fabriquez une pièce de combinaison de survie.",
     "First Suit", "Craft a survival suit piece.", "task", 15),
    ("spacesuit", "first_suit", "spacesuit_helmet", "item", ["spacesuit_helmet", "spacesuit_chestplate"], "Astronaute", "Fabriquez une pièce de combinaison spatiale.",
     "Astronaut", "Craft a spacesuit piece.", "goal", 25),
    ("orbital_suit", "spacesuit", "orbital_suit_helmet", "item", ["orbital_suit_chestplate"], "Respirer à l'infini", "Fabriquez le plastron orbital.",
     "Infinite Breath", "Craft the orbital chestplate.", "challenge", 60),
    ("steel_tools", "steel_age", "steel_pickaxe", "item", ["steel_pickaxe"], "Outils d'acier", "Fabriquez une pioche en acier.",
     "Steel Tools", "Craft a steel pickaxe.", "task", 15),
    ("titanium_tools", "titanium_age", "titanium_pickaxe", "item", ["titanium_pickaxe"], "Outils de titane", "Fabriquez une pioche en titane.",
     "Titanium Tools", "Craft a titanium pickaxe.", "goal", 25),
    ("alloy_tools", "lunar_alloy", "lunar_alloy_pickaxe", "item", ["lunar_alloy_pickaxe"], "Outils de légende", "Fabriquez une pioche en alliage lunaire.",
     "Legendary Tools", "Craft a lunar alloy pickaxe.", "challenge", 40),
    ("blueprint1", "the_start", "blueprint_tier1", "item", ["blueprint_tier1"], "Premier plan", "Trouvez un schéma de fusée Tier 1.",
     "First Plan", "Find a Tier 1 rocket blueprint.", "task", 10),
    ("blueprint2", "blueprint1", "blueprint_tier2", "item", ["blueprint_tier2"], "Plans avancés", "Trouvez un schéma de fusée Tier 2.",
     "Advanced Plans", "Find a Tier 2 rocket blueprint.", "task", 20),
    ("blueprint3", "blueprint2", "rocket_blueprint", "item", ["rocket_blueprint"], "Plan de génie", "Trouvez le schéma de fusée Tier 3 dans un temple.",
     "Master Plan", "Find the Tier 3 rocket blueprint in a temple.", "goal", 40),
    ("thruster", "processor", "thruster", "item", ["thruster"], "Poussée", "Fabriquez un propulseur.",
     "Thrust", "Craft a thruster.", "task", 15),
    ("engine", "thruster", "rocket_engine", "item", ["rocket_engine"], "Moteur de fusée", "Fabriquez un moteur de fusée.",
     "Rocket Engine", "Craft a rocket engine.", "goal", 30),
    ("fuel", "engine", "rocket_fuel", "item", ["rocket_fuel"], "Plein de carburant", "Fabriquez du carburant de fusée.",
     "Fuel Up", "Make rocket fuel.", "task", 20),
    ("reentry", "engine", "reentry_module", "item", ["reentry_module"], "Module de rentrée", "Fabriquez un module de rentrée atmosphérique.",
     "Reentry Module", "Craft a reentry module.", "goal", 30),
    ("platform", "reentry", "launch_platform", "item", ["launch_platform"], "Pas de tir", "Fabriquez une plateforme de lancement.",
     "Launch Pad", "Craft a launch platform.", "goal", 30),
    ("back_to_home", "platform", "parachute", "grant", None, "Back to Home", "Décollez de la Lune et rentrez sur Terre.",
     "Back to Home", "Lift off from the Moon and return to Earth.", "challenge", 200),
    ("jetpack", "engine", "jet_booster", "item", ["jet_booster"], "Propulsé", "Fabriquez un propulseur dorsal.",
     "Boosted", "Craft a jet booster.", "task", 15),
    ("medic", "the_start", "medkit", "item", ["medkit"], "Docteur Lune", "Fabriquez une trousse de soins.",
     "Doctor Moon", "Craft a medkit.", "task", 10),
    ("gourmet", "the_start", "space_stew", "item", ["space_stew", "hydroponic_salad", "moon_cheese"], "Gastronomie spatiale", "Préparez un vrai repas lunaire.",
     "Space Cuisine", "Cook a proper lunar meal.", "task", 15),
    ("lantern", "stone_age", "moon_lantern", "item", ["moon_lantern"], "Que la lumière soit", "Fabriquez une lanterne lunaire.",
     "Let There Be Light", "Craft a moon lantern.", "task", 10),
    ("radar", "processor", "radar_pulse", "item", ["radar_pulse"], "Ping !", "Fabriquez une impulsion radar.",
     "Ping!", "Craft a radar pulse.", "task", 15),
    ("hunter", "the_start", "lunar_rock_sword", "kill", "lunaire:selenite", "Chasseur d'ombres", "Éliminez un Sélénite de l'Ombre.",
     "Shadow Hunter", "Slay a Shadow Selenite.", "task", 20),
    ("golem_breaker", "hunter", "meteorite_block", "kill", "lunaire:dust_golem", "Casseur de golems", "Détruisez un Golem de poussière.",
     "Golem Breaker", "Destroy a Dust Golem.", "goal", 25),
    ("lab_found", "the_start", "lab_plating", "struct", "lunaire:lab", "Laboratoire abandonné", "Découvrez un laboratoire.",
     "Abandoned Lab", "Discover a laboratory.", "task", 20),
    ("temple_found", "lab_found", "ancient_glyph", "struct", "lunaire:temple", "Les anciens", "Trouvez un temple enterré.",
     "The Ancients", "Find a buried temple.", "goal", 40),
    ("outpost_found", "the_start", "solar_panel", "struct", "lunaire:outpost", "Dernier signal", "Découvrez un avant-poste.",
     "Last Signal", "Discover an outpost.", "task", 15),
    ("crater_found", "the_start", "meteorite_ore", "struct", "lunaire:crater", "Point d'impact", "Atteignez un cratère de météorite.",
     "Point of Impact", "Reach a meteorite crater.", "task", 15),
]


def lang():
    fr, en = {}, {}
    for a in ADV:
        fr[f"advancements.lunaire.{a[0]}.title"] = a[5]
        fr[f"advancements.lunaire.{a[0]}.description"] = a[6]
        en[f"advancements.lunaire.{a[0]}.title"] = a[7]
        en[f"advancements.lunaire.{a[0]}.description"] = a[8]
    return fr, en


def gen_advancements(structures=True):
    for aid, parent, icon, kind, arg, *_rest in ADV:
        frame, xp = _rest[-2], _rest[-1]
        if kind == "struct" and not structures:
            continue
        if kind == "item":
            crit = {f"has_{i}": {"trigger": "minecraft:inventory_changed", "conditions": {"items": [{"items": M + i}]}} for i in arg}
        elif kind == "kill":
            crit = {"kill": {"trigger": "minecraft:player_killed_entity", "conditions": {"entity": {
                "type": "minecraft:entity_properties", "entity": "this", "predicate": {"minecraft:entity_type": arg}}}}}
        elif kind == "struct":
            crit = {"in_structure": {"trigger": "minecraft:location", "conditions": {"player": {
                "type": "minecraft:entity_properties", "entity": "this", "predicate": {"minecraft:location": {"structures": arg}}}}}}
        else:
            crit = {"granted": {"trigger": "minecraft:impossible"}}
        adv = {
            "criteria": crit,
            "display": {"icon": {"id": M + icon}, "title": {"translate": f"advancements.lunaire.{aid}.title"},
                        "description": {"translate": f"advancements.lunaire.{aid}.description"}, "frame": frame},
            "requirements": [list(crit.keys())],
        }
        if frame == "task":
            adv["display"].pop("frame")
        if parent:
            adv["parent"] = M + parent
        else:
            adv["display"]["background"] = "minecraft:gui/advancements/backgrounds/stone"
            adv["display"]["show_toast"] = True
            adv["display"]["announce_to_chat"] = False
        if xp:
            adv["rewards"] = {"experience": xp}
        write_json(DATA / "advancement" / f"{aid}.json", adv)


# ------------------------------------------------------------------ soleil
def gen_sun():
    size = 32
    img = Img(size, size)
    c = (size - 1) / 2
    for y in range(size):
        for x in range(size):
            d = math.hypot(x - c, y - c) / c
            if d <= 0.62:
                t = d / 0.62
                col = (255, 255 - 40 * t ** 2, 220 - 130 * t ** 3, 255)
            else:
                a = max(0.0, 1 - (d - 0.62) / 0.38)
                ang = math.atan2(y - c, x - c)
                ray = 0.65 + 0.35 * abs(math.cos(ang * 6))
                a = a * a * ray
                col = (255, 210, 120, int(230 * a))
            if col[3] > 0:
                img.set(x, y, col)
    img.save(ASSETS.parent / "minecraft" / "textures" / "environment" / "celestial" / "sun.png")


# ------------------------------------------------------------------ musique (synthétisée, aucun fichier externe)
def gen_music(out_ogg, tmp_wav):
    sr, dur = 32000, 96
    n = sr * dur
    rng = random.Random(7)
    buf = [0.0] * n
    # progression lente : Am9 – Fmaj7 – Cmaj7 – Em7 (notes en Hz)
    chords = [(110.0, 164.8, 220.0, 261.6, 329.6), (87.3, 130.8, 220.0, 261.6, 329.6),
              (130.8, 196.0, 261.6, 329.6, 392.0), (82.4, 164.8, 246.9, 293.7, 392.0)]
    seg = dur / len(chords) / 2
    for ci in range(8):
        ch = chords[ci % 4]
        t0 = int(ci * seg * sr)
        length = int(seg * 1.5 * sr)
        for f in ch:
            ph = rng.random() * 6.28
            for det in (-0.4, 0.0, 0.5):
                w = 2 * math.pi * (f + det) / sr
                for k in range(0, length, 1):
                    i = t0 + k
                    if i >= n:
                        break
                    env = min(1.0, k / (sr * 2.5)) * min(1.0, (length - k) / (sr * 3.0))
                    buf[i] += 0.035 * env * math.sin(w * k + ph)
    # cloches éparses (sons de verre) avec écho
    scale = [523.3, 587.3, 659.3, 784.0, 880.0, 1046.5]
    t = 4.0
    while t < dur - 6:
        f = rng.choice(scale)
        start = int(t * sr)
        for k in range(int(3.5 * sr)):
            i = start + k
            if i >= n:
                break
            env = math.exp(-k / (sr * 0.9))
            v = 0.05 * env * (math.sin(2 * math.pi * f * k / sr) + 0.3 * math.sin(2 * math.pi * f * 2.76 * k / sr))
            buf[i] += v
            j = i + int(0.45 * sr)
            if j < n:
                buf[j] += v * 0.45
        t += rng.choice((4.5, 6.0, 7.5, 9.0))
    peak = max(abs(v) for v in buf) or 1.0
    with wave.open(str(tmp_wav), "wb") as w:
        w.setnchannels(1), w.setsampwidth(2), w.setframerate(sr)
        fade = sr * 2
        frames = bytearray()
        for i, v in enumerate(buf):
            g = min(1.0, i / fade, (n - i) / fade)
            frames += struct.pack("<h", int(max(-1, min(1, v / peak * 0.8 * g)) * 32767))
        w.writeframes(bytes(frames))
    out_ogg.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(tmp_wav), "-c:a", "libvorbis", "-q:a", "3", str(out_ogg)], check=True)
    write_json(ASSETS / "sounds.json", {"music.moon": {"sounds": [{"name": "lunaire:music/moon_drift", "stream": True}]}})
