"""Textures « Java ».

Au lieu de redessiner, Lunaire RÉFÉRENCE directement les textures du jeu de base (minecraft:item/…,
minecraft:block/…, équipements). Elles sont lues dans le jeu du joueur : rien n'est copié dans le mod.
Les couleurs propres à Lunaire passent par une teinte (comme le cuir teint du jeu).
"""

COLOR_NAMES = ["white", "orange", "magenta", "light_blue", "yellow", "lime", "pink", "gray", "light_gray", "cyan",
               "purple", "blue", "brown", "green", "red", "black"]

# couleur moyenne approximative des textures du jeu (sert à calculer la teinte)
BASE_MID = {"iron": (190, 190, 190), "golden": (240, 200, 55), "diamond": (70, 205, 190),
            "netherite": (85, 75, 88), "copper": (200, 110, 80), "stone": (128, 128, 128)}


def _tint(t):
    """Couleur ARGB opaque, en entier signé 32 bits : exactement le format des JSON du jeu (ex. -6265536)."""
    t = [max(0.0, min(1.0, x)) for x in t]
    v = 0xFF000000 | (round(t[0] * 255) << 16) | (round(t[1] * 255) << 8) | round(t[2] * 255)
    return v - (1 << 32) if v >= (1 << 31) else v


def pick(target, allowed=("iron", "golden", "diamond", "netherite")):
    """Choisit la texture de base et la teinte pour approcher `target` (r,g,b)."""
    best = None
    for name in allowed:
        b = BASE_MID[name]
        t = tuple(min(1.0, target[i] / b[i]) for i in range(3))
        err = sum((b[i] * t[i] - target[i]) ** 2 for i in range(3))
        pen = 400 * sum((1 - x) ** 2 for x in t)
        s = err + pen
        if best is None or s < best[0]:
            best = (s, name, t)
    _, name, t = best
    t = tuple(max(0.28, x) for x in t)
    return name, (None if min(t) > 0.97 else _tint(t))


# ------------------------------------------------------------------ objets

def item_ref(it, suits=None):
    """Retourne {"parent", "textures", "tints"} si l'objet reprend une texture du jeu, sinon None."""
    n = it["name"]
    if "tool" in it:
        from lg_bulk import TOOL_MATS
        col = TOOL_MATS[it["mat"]][6]
        kind = it["tool"]
        if it["mat"] == "lunar_rock":
            return dict(parent="minecraft:item/handheld", textures={"layer0": f"minecraft:item/stone_{kind}"}, tints=[])
        base, tint = pick(col)
        return dict(parent="minecraft:item/handheld", textures={"layer0": f"minecraft:item/{base}_{kind}"},
                    tints=[tint] if tint is not None else [])
    if "armor" in it:
        suit, piece = it["suit"], it["armor"]
        main = suits[suit][0]
        if suit in CLOTH:
            return dict(parent="minecraft:item/generated",
                        textures={"layer0": f"minecraft:item/leather_{piece}",
                                  "layer1": f"minecraft:item/leather_{piece}_overlay"},
                        tints=[_tint([c / 255 for c in main])])
        base, tint = pick(main)
        return dict(parent="minecraft:item/generated", textures={"layer0": f"minecraft:item/{base}_{piece}"},
                    tints=[tint] if tint is not None else [])
    if it.get("form") == "ingot":
        from lg_content import MAT
        col = MAT[it["mat"]]
        base, tint = pick(col, ("iron", "golden", "copper", "netherite"))
        tex = {"iron": "iron_ingot", "golden": "gold_ingot", "copper": "copper_ingot", "netherite": "netherite_ingot"}[base]
        return dict(parent="minecraft:item/generated", textures={"layer0": f"minecraft:item/{tex}"},
                    tints=[tint] if tint is not None else [])
    if it.get("shape") == "nugget":
        col = it["color"]
        base, tint = pick(col, ("iron", "golden"))
        tex = {"iron": "iron_nugget", "golden": "gold_nugget"}[base]
        return dict(parent="minecraft:item/generated", textures={"layer0": f"minecraft:item/{tex}"},
                    tints=[tint] if tint is not None else [])
    if n in GEMS:
        tex, mid = GEMS[n]
        from lg_content import MAT
        col = it.get("color") or GEM_COLOR[n]
        t = tuple(min(1.0, col[i] / mid[i]) for i in range(3))
        t = tuple(max(0.28, x) for x in t)
        return dict(parent="minecraft:item/generated", textures={"layer0": f"minecraft:item/{tex}"},
                    tints=[_tint(t)])
    if n in DIRECT:
        tex, tint = DIRECT[n]
        return dict(parent="minecraft:item/generated", textures={"layer0": f"minecraft:item/{tex}"},
                    tints=[tint] if tint is not None else [])
    return None


# objets qui ont un équivalent exact dans le jeu de base
DIRECT = {
    "guide_book": ("knowledge_book", None),
    "moon_meat": ("mutton", None), "cooked_moon_meat": ("cooked_mutton", None),
    "moon_fish": ("cod", _tint([0.62, 0.78, 1.0])), "cooked_moon_fish": ("cooked_cod", None),
    "algae_bar": ("dried_kelp", None), "algae_soup": ("beetroot_soup", None), "moon_stew": ("rabbit_stew", None),
    "space_stew": ("mushroom_stew", None), "lunar_pie": ("pumpkin_pie", None), "regolith_cookie": ("cookie", None),
    "emergency_ration": ("bread", None), "protein_ration": ("cooked_beef", None),
    "glow_dust": ("glowstone_dust", None), "tortoise_shell": ("turtle_scute", None),
    "selenite_shard": ("amethyst_shard", None), "crystal_honey": ("honey_bottle", None),
    "signal_flare": ("firework_rocket", None), "beacon_flare": ("firework_rocket", None),
    "moon_compass": ("compass_16", None), "helium3_crystal": ("prismarine_crystals", None),
    "meteorite_shard": ("netherite_scrap", None), "iron_scrap": ("iron_nugget", None),
    "void_essence": ("ender_pearl", None), "oxygen_bottle": ("glass_bottle", None),
}


CLOTH = ("survival_suit", "spacesuit", "orbital_suit")
GEMS = {"moonstone": ("quartz", (235, 230, 225)), "olivine": ("emerald", (60, 200, 100))}
GEM_COLOR = {"moonstone": (150, 190, 245), "olivine": (110, 190, 80)}


def equipment(suit, main):
    """Contenu de assets/lunaire/equipment/<suit>.json (armure portée = textures du jeu, teintées)."""
    if suit in CLOTH:
        layer = [{"texture": "minecraft:leather", "dyeable": {"color_when_undyed": _tint([c / 255 for c in main])}},
                 {"texture": "minecraft:leather_overlay"}]
        return {"layers": {"humanoid": layer, "humanoid_leggings": layer}}
    base, tint = pick(main)
    tex = {"iron": "iron", "golden": "gold", "diamond": "diamond", "netherite": "netherite"}[base]
    lay = {"texture": f"minecraft:{tex}"}
    if tint is not None:
        lay["dyeable"] = {"color_when_undyed": tint}
    return {"layers": {"humanoid": [dict(lay)], "humanoid_leggings": [dict(lay)]}}


# ------------------------------------------------------------------ blocs

ORE_VANILLA = {"lunar_iron_ore": "iron", "lunar_copper_ore": "copper", "tin_ore": "gold", "aluminum_ore": "iron",
               "titanium_ore": "lapis", "nickel_ore": "coal", "silver_ore": "gold", "lithium_ore": "redstone",
               "helium3_ore": "lapis", "moonstone_ore": "diamond", "olivine_ore": "emerald", "meteorite_ore": "coal"}

_B = {
    # sol et roches
    "regolith": "light_gray_concrete_powder", "hydrated_regolith": "clay", "lunar_rock": "stone",
    "cracked_lunar_rock": "cracked_stone_bricks", "polished_lunar_rock": "smooth_stone",
    "lunar_rock_bricks": "stone_bricks", "lunar_rock_tiles": "polished_andesite",
    "chiseled_lunar_rock": "chiseled_stone_bricks", "regolith_bricks": "andesite",
    "lunar_ice": "packed_ice", "frozen_regolith": "snow",
    "anorthosite": "diorite", "polished_anorthosite": "polished_diorite", "anorthosite_bricks": "polished_diorite",
    "anorthosite_tiles": "polished_diorite", "chiseled_anorthosite": "chiseled_quartz_block",
    "mare_basalt": "smooth_basalt", "polished_mare_basalt": "polished_blackstone",
    "mare_basalt_bricks": "polished_blackstone_bricks", "mare_basalt_tiles": "polished_blackstone",
    "chiseled_mare_basalt": "chiseled_polished_blackstone",
    "tektite": "obsidian", "tektite_bricks": "polished_blackstone_bricks",
    "lunar_dust": "gray_concrete_powder", "highland_dust": "white_concrete_powder",
    "compressed_dust": "light_gray_concrete", "volcanic_ash": "black_concrete_powder",
    "lunar_gravel": "gravel", "olivine_gravel": "gravel", "crystal_sand": "sand",
    "glowing_sand": "glowstone",
    # verre
    "regolith_glass": "glass", "reinforced_glass": "tinted_glass", "impact_glass": "tinted_glass",
    # métaux et gemmes
    "meteorite_block": "netherite_block", "meteorite_bricks": "polished_blackstone_bricks",
    "copper_block": "copper_block", "tin_block": "iron_block", "aluminum_block": "iron_block",
    "titanium_block": "diamond_block", "steel_block": "iron_block", "bronze_block": "raw_copper_block",
    "lunar_alloy_block": "netherite_block", "nickel_block": "iron_block", "silver_block": "iron_block",
    "moonstone_block": "diamond_block", "glowing_olivine_block": "emerald_block",
    "olivine_bricks": "prismarine_bricks", "moonstone_bricks": "quartz_bricks",
    # base scientifique et ruines
    "lab_plating": "iron_block", "lab_floor": "smooth_stone", "lab_light": "sea_lantern",
    "lab_vent": "iron_trapdoor", "moon_lantern": "sea_lantern",
    "ancient_stone": "deepslate_tiles", "ancient_bricks": "deepslate_bricks", "ancient_glyph": "chiseled_deepslate",
    "white_tile": "white_concrete", "black_tile": "black_concrete", "heavy_plating": "iron_block",
    "solar_tile": "blue_concrete",
}
for _o, _v in ORE_VANILLA.items():
    _B[_o] = f"{_v}_ore"
    _B["anorthosite_" + _o] = f"{_v}_ore"
    _B["mare_basalt_" + _o] = f"deepslate_{_v}_ore"
for _c in COLOR_NAMES:
    _B[f"lunar_concrete_{_c}"] = f"{_c}_concrete"
    _B[f"stained_glass_{_c}"] = f"{_c}_stained_glass"
    _B[f"neon_lamp_{_c}"] = f"{_c}_glazed_terracotta"
    _B[f"lab_panel_{_c}"] = f"{_c}_terracotta"
    _B[f"moon_bricks_{_c}"] = f"{_c}_concrete_powder"


def block_tex(name, default=None):
    """Texture du jeu de base pour ce bloc (ex. « minecraft:block/stone »), ou `default`."""
    v = _B.get(name)
    return f"minecraft:block/{v}" if v else default


def has_block(name):
    return name in _B
