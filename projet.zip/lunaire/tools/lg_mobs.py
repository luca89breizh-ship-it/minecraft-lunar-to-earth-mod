"""Créatures de Lunaire : formes (modèles), table des mobs, textures peintes."""
import random
from lg_core import Img, shade

# --------------------------------------------------------------------------- formes (px) : tête, corps, bras, jambe (w, h, d)
SHAPE_DEF = {
    "humanoid": dict(head=(8, 8, 8), body=(8, 12, 4), arm=(4, 12, 4), leg=(4, 12, 4)),
    "slender": dict(head=(6, 8, 6), body=(6, 13, 4), arm=(2, 14, 2), leg=(2, 13, 2)),
    "brute": dict(head=(6, 6, 6), body=(12, 12, 6), arm=(5, 14, 5), leg=(5, 10, 5)),
    "imp": dict(head=(10, 10, 10), body=(6, 6, 4), arm=(3, 7, 3), leg=(3, 6, 3)),
    "crawler": dict(head=(8, 6, 8), body=(12, 6, 10), arm=(2, 8, 2), leg=(2, 6, 2)),
    "golem": dict(head=(8, 8, 8), body=(12, 14, 8), arm=(5, 16, 5), leg=(6, 10, 6)),
    "round": dict(head=(8, 8, 8), body=(14, 10, 12), arm=(3, 4, 3), leg=(3, 5, 3)),
    "tall": dict(head=(7, 7, 7), body=(7, 16, 3), arm=(3, 18, 3), leg=(3, 16, 3)),
    "skeleton": dict(head=(8, 8, 8), body=(8, 12, 4), arm=(2, 12, 2), leg=(2, 12, 2)),
    "enderman": dict(head=(8, 8, 8), body=(8, 12, 4), arm=(2, 30, 2), leg=(2, 30, 2)),
    "creeper": dict(head=(8, 8, 8), body=(8, 12, 4), arm=(4, 6, 4), leg=(4, 6, 4), quad=True),
    "penguin": dict(head=(6, 6, 6), body=(6, 9, 4), arm=(2, 8, 3), leg=(3, 3, 3)),
    "titan": dict(head=(12, 12, 12), body=(18, 20, 10), arm=(8, 22, 8), leg=(9, 14, 9)),
}


def _rect(w, h, d):
    return (2 * d + 2 * w, d + h)


def build_shapes():
    """Calcule positions et décalages de texture (emballage automatique) pour chaque forme."""
    out = {}
    for name, s in SHAPE_DEF.items():
        hw, hh, hd = s["head"]
        bw, bh, bd = s["body"]
        aw, ah, ad = s["arm"]
        lw, lh, ld = s["leg"]
        ly = 24 - lh
        by = ly - bh
        parts = {
            "head": dict(box=[-hw / 2, -hh, -hd / 2, hw, hh, hd], pos=[0, by, 0], dims=(hw, hh, hd)),
            "body": dict(box=[-bw / 2, 0, -bd / 2, bw, bh, bd], pos=[0, by, 0], dims=(bw, bh, bd)),
            "right_arm": dict(box=[-aw + 1, -2, -ad / 2, aw, ah, ad], pos=[-(bw / 2 + 1), by + 2, 0], dims=(aw, ah, ad)),
            "left_arm": dict(box=[-1, -2, -ad / 2, aw, ah, ad], pos=[bw / 2 + 1, by + 2, 0], dims=(aw, ah, ad)),
            "right_leg": dict(box=[-lw / 2, 0, -ld / 2, lw, lh, ld], pos=[-(lw / 2 - 0.1), ly, 0], dims=(lw, lh, ld)),
            "left_leg": dict(box=[-lw / 2, 0, -ld / 2, lw, lh, ld], pos=[lw / 2 - 0.1, ly, 0], dims=(lw, lh, ld)),
        }
        if s.get("quad"):
            parts["right_arm"] = dict(box=[-2, 0, -2, aw, ah, ad], pos=[-2, ly, 4], dims=(aw, ah, ad))
            parts["left_arm"] = dict(box=[-2, 0, -2, aw, ah, ad], pos=[2, ly, 4], dims=(aw, ah, ad))
            parts["right_leg"] = dict(box=[-2, 0, -2, lw, lh, ld], pos=[-2, ly, -4], dims=(lw, lh, ld))
            parts["left_leg"] = dict(box=[-2, 0, -2, lw, lh, ld], pos=[2, ly, -4], dims=(lw, lh, ld))
        # emballage : head, hat, body, arm, leg
        items = [("head", parts["head"]["dims"]), ("hat", parts["head"]["dims"]), ("body", parts["body"]["dims"]),
                 ("right_arm", parts["right_arm"]["dims"]), ("right_leg", parts["right_leg"]["dims"])]
        for size in (64, 128):
            x = y = row = 0
            tex = {}
            ok = True
            for key, dims in sorted(items, key=lambda it: -_rect(*it[1])[1]):
                rw, rh = _rect(*dims)
                if x + rw > size:
                    x, y = 0, y + row
                    row = 0
                if y + rh > size or rw > size:
                    ok = False
                    break
                tex[key] = (x, y)
                x += rw
                row = max(row, rh)
            if ok:
                break
        parts["head"]["tex"] = tex["head"]
        parts["hat"] = dict(tex=tex["hat"], dims=parts["head"]["dims"])
        parts["body"]["tex"] = tex["body"]
        parts["right_arm"]["tex"] = parts["left_arm"]["tex"] = tex["right_arm"]
        parts["right_leg"]["tex"] = parts["left_leg"]["tex"] = tex["right_leg"]
        height = (hh + bh + lh) / 16.0
        if name == "enderman":
            height = 2.8
        width = max(bw, bd) / 16.0 + 0.1
        out[name] = dict(parts={k: {kk: vv for kk, vv in v.items() if kk != "dims"} for k, v in parts.items() if k != "hat"},
                         hat_tex=list(tex["hat"]), tex_size=size, height=round(height + 0.1, 2), width=round(min(width, 1.6), 2),
                         _dims={k: v["dims"] for k, v in parts.items()})
    return out


SHAPES = build_shapes()
from lg_mobs_quad import SPECIAL as _SPECIAL
SHAPES.update(_SPECIAL)

# --------------------------------------------------------------------------- table des mobs
# name, fr, en, shape, style, behavior, hp, dmg, speed, (main, dark, accent), drops, extra
H, N, P, B = "hostile", "neutral", "passive", "boss"
MOBS = [
    # ---- hostiles
    ("selenite_scout", "Éclaireur sélénite", "Selenite Scout", "slender", "organic", H, 14, 3, 0.34, ((120, 190, 215), (70, 120, 150), (255, 255, 140)), [("selenite_shard", 0, 2)], dict(sun=True)),
    ("selenite_brute", "Brute sélénite", "Selenite Brute", "brute", "organic", H, 34, 6, 0.26, ((90, 150, 185), (50, 95, 125), (255, 200, 80)), [("selenite_shard", 1, 3)], dict(sun=True)),
    ("selenite_shaman", "Chaman sélénite", "Selenite Shaman", "slender", "glow", H, 20, 4, 0.30, ((160, 130, 220), (90, 70, 150), (255, 140, 255)), [("selenite_shard", 1, 2), ("moonstone", 0, 1)], dict(effect="minecraft:slowness 4 1", sun=True)),
    ("shadow_stalker", "Rôdeur de l'ombre", "Shadow Stalker", "tall", "ghost", H, 24, 5, 0.36, ((34, 32, 50), (15, 14, 24), (190, 70, 255)), [("void_essence", 0, 1)], dict(effect="minecraft:blindness 4 0", sun=True)),
    ("crater_crawler", "Rampant des cratères", "Crater Crawler", "crawler", "insect", H, 16, 3, 0.38, ((115, 104, 98), (70, 62, 58), (255, 120, 40)), [("chitin_plate", 0, 2)], {}),
    ("regolith_husk", "Carcasse de régolithe", "Regolith Husk", "humanoid", "undead", H, 22, 4, 0.24, ((152, 146, 136), (96, 90, 84), (255, 90, 60)), [("dust_core", 0, 1), ("iron_scrap", 0, 2)], {}),
    ("dust_wraith", "Spectre de poussière", "Dust Wraith", "slender", "ghost", H, 14, 3, 0.32, ((205, 200, 190), (150, 146, 138), (255, 255, 255)), [("dust_core", 0, 2)], dict(effect="minecraft:weakness 5 0")),
    ("iron_sentinel", "Sentinelle de fer", "Iron Sentinel", "golem", "robot", H, 40, 7, 0.22, ((122, 128, 138), (70, 74, 84), (255, 60, 60)), [("bot_scrap", 1, 3), ("steel_ingot", 0, 1)], {}),
    ("rogue_miner_bot", "Robot mineur fou", "Rogue Miner Bot", "imp", "robot", H, 18, 3, 0.30, ((205, 172, 64), (120, 100, 40), (60, 255, 120)), [("bot_scrap", 1, 2), ("copper_wire", 0, 2)], {}),
    ("cryo_horror", "Horreur cryogénique", "Cryo Horror", "brute", "ice", H, 38, 6, 0.25, ((172, 222, 246), (110, 160, 200), (255, 255, 255)), [("cryo_gel", 1, 3)], dict(effect="minecraft:slowness 6 2")),
    ("solar_scorcher", "Brûleur solaire", "Solar Scorcher", "brute", "fire", H, 32, 6, 0.27, ((232, 122, 52), (160, 70, 30), (255, 232, 92)), [("sun_ember", 1, 2)], dict(ignite=6)),
    ("tektite_golem", "Golem de tectite", "Tektite Golem", "golem", "crystal", H, 42, 7, 0.22, ((42, 72, 56), (22, 40, 30), (120, 255, 170)), [("tektite", 1, 2)], {}),
    ("olivine_guardian", "Gardien d'olivine", "Olivine Guardian", "golem", "crystal", H, 46, 8, 0.22, ((92, 162, 72), (50, 100, 40), (200, 255, 120)), [("olivine", 1, 3)], {}),
    ("void_walker", "Marcheur du vide", "Void Walker", "tall", "ghost", H, 30, 6, 0.34, ((18, 12, 32), (8, 4, 16), (130, 50, 210)), [("void_essence", 1, 2)], dict(effect="minecraft:darkness 6 0", sun=True)),
    ("lab_experiment", "Expérience de laboratoire", "Lab Experiment", "humanoid", "organic", H, 26, 5, 0.28, ((112, 202, 112), (60, 130, 60), (255, 60, 60)), [("bio_sample", 1, 2)], dict(effect="minecraft:poison 4 0")),
    ("meteor_imp", "Diablotin météorique", "Meteor Imp", "imp", "fire", H, 12, 3, 0.40, ((92, 62, 112), (50, 30, 70), (255, 110, 200)), [("meteorite_shard", 0, 1)], dict(ignite=4)),
    ("gravity_ghoul", "Goule de gravité", "Gravity Ghoul", "round", "organic", H, 28, 5, 0.24, ((122, 92, 152), (70, 50, 100), (160, 255, 255)), [("dust_core", 1, 2)], dict(effect="minecraft:levitation 3 0")),
    ("crystal_mimic", "Mimique de cristal", "Crystal Mimic", "crawler", "crystal", H, 20, 5, 0.33, ((62, 102, 182), (30, 60, 120), (200, 230, 255)), [("crystal_shell", 1, 2)], {}),
    ("void_spider", "Araignée du vide", "Void Spider", "crawler", "ghost", H, 18, 4, 0.40, ((28, 22, 44), (12, 8, 22), (255, 60, 200)), [("void_essence", 0, 1)], dict(effect="minecraft:slowness 3 1")),
    ("radiation_slime", "Gelée radioactive", "Radiation Slime", "round", "organic", H, 24, 4, 0.22, ((130, 230, 60), (70, 150, 30), (240, 255, 100)), [("geode_slime", 1, 3)], dict(effect="minecraft:poison 5 0")),
    ("iron_hound", "Chien de fer", "Iron Hound", "crawler", "robot", H, 22, 5, 0.42, ((150, 155, 165), (90, 94, 104), (255, 140, 40)), [("bot_scrap", 1, 2)], {}),
    ("frost_reaver", "Pillard de givre", "Frost Reaver", "slender", "ice", H, 22, 5, 0.35, ((190, 232, 252), (120, 170, 210), (110, 200, 255)), [("cryo_gel", 1, 2)], dict(effect="minecraft:slowness 4 0")),
    ("lunar_lurker", "Rôdeur lunaire", "Lunar Lurker", "humanoid", "undead", H, 26, 5, 0.30, ((86, 90, 108), (46, 48, 62), (255, 255, 120)), [("dust_core", 0, 1), ("selenite_shard", 0, 1)], {}),
    ("star_reaver", "Moissonneur d'étoiles", "Star Reaver", "tall", "glow", H, 34, 7, 0.34, ((60, 50, 120), (30, 24, 70), (255, 240, 120)), [("void_essence", 1, 2), ("meteorite_shard", 0, 1)], dict(effect="minecraft:weakness 5 1")),
    # ---- boss
    ("ancient_warden", "Gardien des anciens", "Ancient Warden", "titan", "runic", B, 160, 14, 0.24, ((74, 74, 90), (40, 40, 52), (255, 200, 60)), [("ancient_core", 1, 1), ("titanium_ingot", 2, 5), ("meteorite_shard", 2, 4)], dict(boss=True)),
    ("lab_overseer", "Superviseur du laboratoire", "Lab Overseer", "titan", "robot", B, 110, 10, 0.26, ((62, 72, 94), (30, 36, 52), (255, 60, 60)), [("overseer_chip", 1, 1), ("advanced_circuit", 2, 4), ("processor", 0, 1)], dict(boss=True)),
    # ---- neutres et passifs
    ("space_goat", "Chèvre spatiale", "Space Goat", "round", "organic", N, 14, 3, 0.26, ((214, 208, 192), (150, 144, 130), (255, 220, 120)), [("moon_fluff", 0, 2), ("moon_meat", 1, 2)], {}),
    ("crystal_crab", "Crabe de cristal", "Crystal Crab", "crawler", "crystal", N, 12, 2, 0.28, ((132, 182, 232), (80, 120, 180), (255, 255, 255)), [("crystal_shell", 1, 2)], {}),
    ("regolith_mole", "Taupe de régolithe", "Regolith Mole", "crawler", "organic", N, 10, 2, 0.26, ((102, 92, 86), (60, 54, 50), (255, 180, 160)), [("moon_meat", 1, 1)], {}),
    ("moon_rabbit", "Lapin lunaire", "Moon Rabbit", "imp", "organic", P, 4, 0, 0.30, ((204, 204, 210), (150, 150, 160), (255, 140, 160)), [("moon_meat", 0, 1)], {}),
    ("dust_bunny", "Lapin de poussière", "Dust Bunny", "round", "organic", P, 4, 0, 0.30, ((172, 162, 152), (120, 112, 104), (255, 255, 255)), [("moon_fluff", 0, 2)], {}),
    ("glow_beetle", "Scarabée lumineux", "Glow Beetle", "crawler", "insect", P, 6, 0, 0.24, ((40, 62, 52), (22, 34, 28), (120, 255, 150)), [("glow_dust", 1, 2)], {}),
    ("lunar_tortoise", "Tortue lunaire", "Lunar Tortoise", "round", "organic", P, 20, 0, 0.14, ((112, 132, 102), (70, 90, 62), (230, 210, 140)), [("tortoise_shell", 0, 1)], {}),
    ("moon_sheep", "Mouton lunaire", "Moon Sheep", "round", "organic", P, 10, 0, 0.24, ((236, 236, 246), (180, 180, 200), (255, 190, 210)), [("moon_fluff", 1, 3), ("moon_meat", 0, 1)], {}),
    ("helper_bot", "Robot assistant", "Helper Bot", "imp", "robot", P, 15, 0, 0.26, ((212, 218, 228), (130, 136, 150), (80, 200, 255)), [("bot_scrap", 0, 2)], {}),
    ("moon_cat", "Chat lunaire", "Moon Cat", "imp", "organic", P, 8, 0, 0.32, ((82, 82, 98), (46, 46, 58), (255, 232, 84)), [], {}),
    ("geode_slug", "Limace géode", "Geode Slug", "crawler", "organic", P, 8, 0, 0.18, ((152, 102, 172), (100, 60, 120), (255, 200, 255)), [("geode_slime", 1, 2)], {}),
    ("ice_penguin", "Manchot des glaces", "Ice Penguin", "imp", "organic", P, 8, 0, 0.22, ((52, 62, 82), (30, 36, 52), (255, 255, 255)), [("cryo_gel", 0, 1)], {}),
    ("star_moth", "Phalène stellaire", "Star Moth", "tall", "ghost", P, 6, 0, 0.26, ((232, 232, 255), (170, 170, 220), (255, 240, 180)), [("glow_dust", 1, 2)], {}),
    ("lunar_hare", "Lièvre lunaire", "Lunar Hare", "slender", "organic", P, 6, 0, 0.36, ((192, 186, 180), (130, 124, 118), (255, 150, 150)), [("moon_meat", 1, 1)], {}),
    ("pebble_pup", "Chiot de caillou", "Pebble Pup", "imp", "crystal", P, 12, 0, 0.28, ((132, 132, 152), (80, 80, 100), (255, 255, 160)), [("olivine", 0, 1)], {}),
    ("astro_pup", "Chiot astronaute", "Astro Pup", "imp", "organic", P, 10, 0, 0.30, ((202, 162, 112), (140, 100, 62), (255, 255, 255)), [], {}),
    ("solar_firefly", "Luciole solaire", "Solar Firefly", "tall", "glow", P, 4, 0, 0.28, ((255, 232, 122), (210, 170, 60), (255, 255, 220)), [("glow_dust", 1, 3)], {}),
    ("moon_jelly", "Méduse lunaire", "Moon Jelly", "round", "ghost", P, 8, 0, 0.12, ((150, 200, 255), (90, 140, 220), (255, 255, 255)), [("cryo_gel", 0, 1)], {}),
]


_KEEP = {"helper_bot", "ancient_warden", "lab_overseer", "moon_rabbit", "moon_sheep", "moon_cat", "astro_pup", "lunar_tortoise", "ice_penguin", "space_goat"}
_NEW = [
    ("space_zombie", "Zombie de l'espace", "Space Zombie", "humanoid", "zombie", H, 20, 3, 0.23, ((84, 140, 90), (50, 90, 58), (20, 20, 30)),
     [("bio_sample", 0, 2), ("iron_scrap", 0, 1), ("minecraft:rotten_flesh", 0, 2)], dict(helmet=True, outfit=((52, 78, 128), (44, 46, 104)), sun=False)),
    ("dust_husk", "Carcasse de poussière", "Dust Husk", "humanoid", "zombie", H, 22, 3, 0.23, ((178, 162, 122), (130, 116, 84), (30, 26, 20)),
     [("dust_core", 0, 1), ("minecraft:rotten_flesh", 0, 1)], dict(outfit=((152, 136, 102), (122, 108, 80)), effect="minecraft:weakness 5 0")),
    ("space_skeleton", "Squelette de l'espace", "Space Skeleton", "skeleton", "bone", H, 20, 2, 0.25, ((208, 208, 200), (150, 150, 142), (20, 20, 20)),
     [("minecraft:bone", 0, 2), ("minecraft:arrow", 0, 2)], dict(helmet=True, ranged=True)),
    ("frost_skeleton", "Squelette givré", "Frost Skeleton", "skeleton", "bone", H, 20, 2, 0.25, ((176, 200, 214), (120, 150, 170), (20, 30, 40)),
     [("minecraft:bone", 0, 2), ("cryo_gel", 0, 1)], dict(ranged=True)),
    ("space_creeper", "Creeper de l'espace", "Space Creeper", "creeper", "creeper", H, 20, 0, 0.25, ((96, 150, 96), (60, 100, 66), (16, 20, 16)),
     [("minecraft:gunpowder", 0, 2)], dict(explode=True)),
    ("lunar_enderman", "Enderman lunaire", "Lunar Enderman", "enderman", "ender", H, 40, 7, 0.30, ((20, 18, 26), (10, 8, 14), (220, 130, 255)),
     [("void_essence", 0, 1)], dict(teleport=True)),
    ("moon_spider", "Araignée lunaire", "Moon Spider", "spider", "spider", H, 16, 2, 0.32, ((46, 38, 38), (26, 20, 20), (230, 30, 30)),
     [("minecraft:string", 0, 2), ("minecraft:spider_eye", 0, 1)], {}),
    ("space_pillager", "Pillard de l'espace", "Space Pillager", "humanoid", "zombie", H, 24, 4, 0.25, ((140, 134, 126), (96, 90, 84), (30, 30, 30)),
     [("bot_scrap", 0, 2), ("copper_wire", 0, 2)], dict(helmet=True, ranged=True, outfit=((84, 88, 96), (60, 62, 70)))),
]
_PATCH = {
    "moon_rabbit": ("rabbit", dict(limb=(176, 176, 184))),
    "moon_sheep": ("sheep", dict(head=(72, 66, 66), limb=(72, 66, 66), wool=True)),
    "moon_cat": ("cat", {}),
    "astro_pup": ("dog", dict(limb=(176, 136, 90))),
    "lunar_tortoise": ("tortoise", dict(head=(150, 150, 110))),
    "ice_penguin": ("penguin", dict(belly=(238, 238, 244))),
    "space_goat": ("goat", dict(limb=(190, 184, 170))),
}
_old = [m for m in MOBS if m[0] in _KEEP]
MOBS = _NEW[:]
for _m in _old:
    if _m[0] in _PATCH:
        _sh, _ex = _PATCH[_m[0]]
        _m = _m[:3] + (_sh,) + _m[4:11] + (dict(_m[11], **_ex),)
    MOBS.append(_m)


# --------------------------------------------------------------------------- textures
def _region_fill(img, x, y, w, h, base, rng, var=10):
    for yy in range(y, y + h):
        for xx in range(x, x + w):
            v = rng.randint(-var, var)
            img.set(xx, yy, shade(base, v))


def _faces(u, v, w, h, d):
    """Rectangles des 6 faces d'un cube de texture Minecraft."""
    return {"top": (u + d, v, w, d), "bottom": (u + d + w, v, w, d), "right": (u, v + d, d, h),
            "front": (u + d, v + d, w, h), "left": (u + d + w, v + d, d, h), "back": (u + 2 * d + w, v + d, w, h)}


def paint(mob, shape_name):
    name, fr, en, sh, style, beh, hp, dmg, spd, (main, dark, acc), drops, extra = mob
    shp = SHAPES[shape_name]
    size = shp["tex_size"]
    img = Img(size, size)
    rng = random.Random(sum(map(ord, name)))
    dims = shp["_dims"]

    def paint_part(key, tex, d, base, is_head=False, is_body=False, is_hat=False):
        w, h, dd = d
        for face, (x, y, fw, fh) in _faces(tex[0], tex[1], w, h, dd).items():
            if is_hat:
                continue
            _region_fill(img, x, y, fw, fh, base, rng, 8 if style != "ghost" else 5)
            if face in ("right", "left", "back"):
                for xx in range(x, x + fw):
                    for yy in range(y, y + fh):
                        img.set(xx, yy, shade(img.get(xx, yy), -12))
            if face in ("bottom",):
                for xx in range(x, x + fw):
                    for yy in range(y, y + fh):
                        img.set(xx, yy, shade(img.get(xx, yy), -28))
            # style
            if style == "robot":
                for xx in range(x, x + fw):
                    img.set(xx, y, shade(dark, 10))
                for yy in range(y, y + fh, max(3, fh // 3)):
                    for xx in range(x, x + fw):
                        img.set(xx, yy, shade(dark, 5))
                if fw >= 3 and fh >= 3:
                    img.set(x + 1, y + 1, shade(acc, -40))
            elif style == "organic":
                for _ in range(max(1, fw * fh // 14)):
                    img.set(x + rng.randrange(fw), y + rng.randrange(fh), shade(dark, rng.randint(-5, 15)))
            elif style == "insect":
                for yy in range(y + 1, y + fh, 2):
                    for xx in range(x, x + fw):
                        img.set(xx, yy, shade(dark, 8))
            elif style == "ice":
                for k in range(0, fw + fh, 5):
                    xx, yy = x + k % fw, y + (k * 3) % fh
                    img.set(xx, yy, (245, 252, 255, 255))
            elif style == "crystal":
                for k in range(min(fw, fh)):
                    img.set(x + k, y + k, shade(acc, -30)), img.set(x + fw - 1 - k, y + k, shade(base, 40))
            elif style == "fire":
                for xx in range(x, x + fw):
                    for yy in range(y + fh // 2, y + fh):
                        if rng.random() < 0.35:
                            img.set(xx, yy, shade(acc, -rng.randint(0, 50)))
            elif style == "undead":
                for _ in range(max(1, fw * fh // 10)):
                    img.set(x + rng.randrange(fw), y + rng.randrange(fh), shade(dark, -10))
            elif style == "runic":
                for yy in range(y + 2, y + fh - 1, 4):
                    for xx in range(x + 1, x + fw - 1, 3):
                        img.set(xx, yy, acc), img.set(xx + 1, yy, shade(acc, -60))
            elif style == "glow":
                for _ in range(max(1, fw * fh // 9)):
                    img.set(x + rng.randrange(fw), y + rng.randrange(fh), shade(acc, -rng.randint(0, 40)))
            elif style == "ghost":
                for yy in range(y, y + fh):
                    if yy % 4 == 0:
                        for xx in range(x, x + fw):
                            img.set(xx, yy, shade(img.get(xx, yy), 14))
        # visage et détails
        if is_head:
            x, y, fw, fh = _faces(tex[0], tex[1], w, h, dd)["front"]
            ey = y + max(1, fh * 3 // 8)
            ew = max(1, fw // 5)
            ex1 = x + max(1, fw // 5)
            ex2 = x + fw - max(1, fw // 5) - ew
            img.rect(ex1, ey, ew, max(1, ew), acc), img.rect(ex2, ey, ew, max(1, ew), acc)
            if fw >= 6 and style != "ghost":
                img.rect(x + fw // 4, y + fh - max(2, fh // 4), fw // 2, 1, dark)
            if style in ("robot", "insect"):
                img.set(ex1 + ew // 2, ey - 1, shade(acc, 60)), img.set(ex2 + ew // 2, ey - 1, shade(acc, 60))
        if is_body and style in ("robot", "glow", "runic", "crystal"):
            x, y, fw, fh = _faces(tex[0], tex[1], w, h, dd)["front"]
            cx, cy = x + fw // 2, y + fh // 3
            img.rect(cx - 1, cy - 1, 2, 2, acc)
            img.set(cx - 1, cy - 1, shade(acc, 70))

    P = shp["parts"]
    paint_part("head", P["head"]["tex"], dims["head"], main, is_head=True)
    paint_part("body", P["body"]["tex"], dims["body"], shade(main, -10), is_body=True)
    paint_part("arm", P["right_arm"]["tex"], dims["right_arm"], shade(main, -5))
    paint_part("leg", P["right_leg"]["tex"], dims["right_leg"], shade(dark, 12))
    # chapeau : petites cornes / antennes selon le style (région du chapeau)
    hx, hy = shp["hat_tex"]
    w, h, dd = dims["head"]
    if style in ("insect", "robot", "crystal", "fire", "ghost", "glow"):
        tx, ty, tw, th = _faces(hx, hy, w, h, dd)["front"]
        topx, topy, topw, toph = _faces(hx, hy, w, h, dd)["top"]
        for xx in (tx + 1, tx + tw - 2):
            img.set(xx, ty, acc), img.set(xx, ty + 1, shade(acc, -30))
    if style == "ghost":  # translucide
        img.px = [(r, g, b, (a * 200) // 255 if a else 0) for (r, g, b, a) in img.px]
    return img


def java_config():
    out = {}
    for m in MOBS:
        name, fr, en, sh, style, beh, hp, dmg, spd, cols, drops, extra = m
        out[name] = dict(shape=sh, beh=beh, hp=hp, dmg=dmg, speed=spd, effect=extra.get("effect", ""),
                         ignite=bool(extra.get("ignite")), ranged=bool(extra.get("ranged")), explode=bool(extra.get("explode")),
                         teleport=bool(extra.get("teleport")), sun=bool(extra.get("sun")), boss=bool(extra.get("boss")),
                         width=SHAPES[sh]["width"], height=SHAPES[sh]["height"])
    return out


def java_shapes():
    return {k: dict(parts=v["parts"], hat_tex=v["hat_tex"], tex_size=v["tex_size"],
                    extras=[{kk: vv for kk, vv in e.items() if kk != "dims"} for e in v.get("extras", [])])
            for k, v in SHAPES.items()}
