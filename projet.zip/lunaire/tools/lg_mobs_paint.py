"""Peinture détaillée des créatures : ombrage par face, dégradés, détails par style, visages expressifs."""
import random
from lg_core import Img, shade
from lg_mobs import SHAPES, _faces

FACE_LIGHT = {"top": 16, "front": 0, "right": -10, "left": -10, "back": -16, "bottom": -34}


def _mix(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def paint(mob, shape_name):
    name, fr, en, sh, style, beh, hp, dmg, spd, (main, dark, acc), drops, extra = mob
    shp = SHAPES[shape_name]
    size = shp["tex_size"]
    img = Img(size, size)
    rng = random.Random(sum(map(ord, name)) * 17)
    dims, P = shp["_dims"], shp["parts"]
    hostile = beh in ("hostile", "boss", "neutral")
    alpha = 205 if style == "ghost" else 255

    def px(x, y, c):
        img.set(x, y, tuple(c[:3]) + (alpha,))

    def face_fill(x, y, w, h, base, face, part):
        for yy in range(h):
            g = 10 - 20 * yy / max(1, h - 1)
            for xx in range(w):
                n = rng.choice((-4, -2, 0, 0, 2, 4))
                c = shade(base, FACE_LIGHT[face] + g + n)
                if xx == 0 or xx == w - 1:
                    c = shade(c, -7)
                px(x + xx, y + yy, c)
        if style == "robot":
            for yy in range(2, h, 4):
                for xx in range(w):
                    px(x + xx, y + yy, shade(dark, -6))
            if w >= 6 and h >= 6 and face in ("front", "back"):
                for cx, cy in ((x + 1, y + 1), (x + w - 2, y + 1), (x + 1, y + h - 2), (x + w - 2, y + h - 2)):
                    px(cx, cy, shade(base, 45))
        elif style == "organic":
            for _ in range(max(2, w * h // 6)):
                xx, yy = x + rng.randrange(w), y + rng.randrange(max(1, h - 1))
                c = shade(base, rng.choice((-22, -14, 14, 22)))
                px(xx, yy, c)
                if rng.random() < 0.6:
                    px(xx, yy + 1, shade(c, -6))
        elif style == "insect":
            for yy in range(0, h, 3):
                for xx in range(w):
                    px(x + xx, y + yy, shade(dark, -8))
                    if yy + 1 < h:
                        px(x + xx, y + yy + 1, shade(base, 26))
        elif style == "ice":
            for k in range(rng.randint(2, 4)):
                xx, yy = x + rng.randrange(w), y + rng.randrange(h)
                for d in range(rng.randint(2, 4)):
                    px(xx + d, yy + d, (236, 248, 255))
            for _ in range(w * h // 9):
                px(x + rng.randrange(w), y + rng.randrange(h), shade(base, 38))
        elif style == "crystal":
            for k in range(0, w + h, 4):
                for d in range(max(w, h)):
                    xx, yy = x + k - d, y + d
                    if x <= xx < x + w and y <= yy < y + h:
                        px(xx, yy, shade(acc, -35 if d % 2 else 20))
        elif style == "fire":
            for yy in range(h):
                t = yy / max(1, h - 1)
                for xx in range(w):
                    if rng.random() < t * 0.9:
                        px(x + xx, y + yy, _mix(main, acc, min(1.0, t * 1.2 + rng.random() * 0.2)))
        elif style == "undead":
            for _ in range(max(2, w * h // 7)):
                xx, yy = x + rng.randrange(w), y + rng.randrange(h)
                px(xx, yy, rng.choice((shade(dark, -18), (214, 206, 188), shade(base, -30))))
        elif style == "runic":
            for yy in range(2, h - 1, 4):
                for xx in range(1, w - 2, 4):
                    for dx, dy in ((0, 0), (1, 0), (1, 1), (2, 1)):
                        px(x + xx + dx, y + yy + dy, acc)
        elif style == "glow":
            for _ in range(max(2, w * h // 7)):
                px(x + rng.randrange(w), y + rng.randrange(h), shade(acc, -rng.randint(0, 60)))
        elif style == "ghost":
            for yy in range(h):
                t = yy / max(1, h - 1)
                for xx in range(w):
                    c = img.get(x + xx, y + yy)
                    img.set(x + xx, y + yy, (c[0], c[1], c[2], int(alpha * (1 - 0.45 * t))))

    def part_paint(key, tex, d, base, kind):
        w, h, dd = d
        faces = _faces(tex[0], tex[1], w, h, dd)
        for face, (x, y, fw, fh) in faces.items():
            face_fill(x, y, fw, fh, base, face, key)
        if kind in ("arm", "leg"):  # mains / pieds plus sombres
            band = max(2, h // 5)
            for face in ("front", "back", "left", "right"):
                x, y, fw, fh = faces[face]
                for yy in range(fh - band, fh):
                    for xx in range(fw):
                        px(x + xx, y + yy, shade(img.get(x + xx, y + yy), -26 if kind == "leg" else -14))
                for xx in range(fw):
                    px(x + xx, y + fh - band, shade(dark, -18))
        if kind == "body":
            x, y, fw, fh = faces["front"]
            if style in ("organic", "undead", "ice") and fw >= 5:
                bw = fw - 4
                for yy in range(2, fh - 1):
                    for xx in range(2, 2 + bw):
                        c = img.get(x + xx, y + yy)
                        px(x + xx, y + yy, shade(c, 18))
            if style in ("robot", "glow", "runic", "crystal", "fire") and fw >= 4 and fh >= 5:
                cx, cy = x + fw // 2 - 1, y + fh // 3
                img.rect(cx - 1, cy - 1, 4, 4, tuple(shade(dark, -25)[:3]) + (alpha,))
                img.rect(cx, cy, 2, 2, tuple(acc[:3]) + (alpha,))
                px(cx, cy, shade(acc, 70))
            if style == "robot":
                for xx in range(fw):
                    px(x + xx, y + fh - 3, shade(dark, -30))

    part_paint("body", P["body"]["tex"], dims["body"], shade(main, -8), "body")
    part_paint("arm", P["right_arm"]["tex"], dims["right_arm"], shade(main, -4), "arm")
    part_paint("leg", P["right_leg"]["tex"], dims["right_leg"], shade(dark, 14), "leg")
    part_paint("head", P["head"]["tex"], dims["head"], main, "head")

    # ---- visage
    hx, hy = P["head"]["tex"]
    w, h, dd = dims["head"]
    x, y, fw, fh = _faces(hx, hy, w, h, dd)["front"]
    ey = y + max(1, int(fh * 0.38))
    ew = 2 if fw >= 7 else 1
    gap = max(1, (fw - 2 * ew) // 3)
    ex1 = x + gap
    ex2 = x + fw - gap - ew
    brow = shade(dark, -35)
    if style == "robot":
        for xx in range(x + 1, x + fw - 1):
            px(xx, ey, shade(acc, -10))
            px(xx, ey - 1, shade(dark, -40))
            px(xx, ey + 1, shade(dark, -40))
        px(x + fw // 2, ey, (255, 255, 255))
    elif style in ("ghost", "glow", "fire", "runic"):
        for ex in (ex1, ex2):
            img.rect(ex, ey, ew, max(1, ew // 1), tuple(acc[:3]) + (255,))
            px(ex, ey, (255, 255, 255))
            for dx in range(-1, ew + 1):
                if img.get(ex + dx, ey + 1)[3] and dx in (-1, ew):
                    px(ex + dx, ey, shade(acc, -90))
    elif style == "undead":
        for ex in (ex1, ex2):
            img.rect(ex, ey, ew, ew, (24, 18, 18, 255))
            px(ex + ew - 1, ey + ew - 1, acc)
    else:
        for ex in (ex1, ex2):
            img.rect(ex, ey, ew, ew, (240, 240, 236, 255))
            px(ex + (ew - 1 if ex == ex1 else 0), ey + ew - 1, (20, 16, 20))
            if ew > 1:
                px(ex + (ew - 1 if ex == ex1 else 0), ey, acc)
        if hostile:
            for ex in (ex1, ex2):
                for dx in range(ew):
                    px(ex + dx, ey - 1, brow)
    if fw >= 6 and fh >= 6:
        my = y + fh - max(2, fh // 4)
        if hostile and style not in ("robot", "ghost"):
            for xx in range(x + fw // 4, x + fw - fw // 4):
                px(xx, my, (26, 20, 22))
                if (xx - x) % 2 == 0:
                    px(xx, my - 1, (232, 228, 214))
        elif not hostile:
            px(x + fw // 2 - 1, my, shade(dark, -40))
            px(x + fw // 2, my, shade(dark, -40))
            px(x + fw // 2 - 1, my - 1, (238, 160, 160))
    if not hostile:  # nez
        px(x + fw // 2 - 1, ey + 2, shade(dark, -50))
        px(x + fw // 2, ey + 2, shade(dark, -50))

    # ---- chapeau (couche externe) : cornes, antennes ou crête
    hx2, hy2 = shp["hat_tex"]
    hf = _faces(hx2, hy2, w, h, dd)
    tx, ty, tw, th = hf["front"]
    ttx, tty, ttw, tth = hf["top"]
    if style in ("insect", "robot", "crystal", "fire", "ghost", "glow", "ice"):
        for xx in (tx + 1, tx + tw - 2):
            for k in range(2):
                px(xx, ty + k, shade(acc, -k * 40))
    if hostile and style in ("organic", "undead", "insect"):
        for xx in (tx, tx + tw - 1):
            for k in range(3):
                px(xx, ty + k, (222, 214, 196) if k == 0 else (178, 168, 150))
    return img
