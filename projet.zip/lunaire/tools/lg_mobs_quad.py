"""Formes non humanoïdes : quadrupèdes (lapin, mouton, chat, chien, chèvre, tortue) et araignée à 8 pattes.
Le corps est tourné de 90° ; les 'bras' sont les pattes avant, les 'jambes' les pattes arrière ; les extras sont statiques."""
import math

PI2 = math.pi / 2


def _rect(w, h, d):
    return (2 * d + 2 * w, d + h)


def _pack(items):
    for size in (64, 128):
        x = y = row = 0
        tex, ok = {}, True
        for key, dims in sorted(items, key=lambda it: -_rect(*it[1])[1]):
            rw, rh = _rect(*dims)
            if x + rw > size:
                x, y, row = 0, y + row, 0
            if y + rh > size or rw > size:
                ok = False
                break
            tex[key] = (x, y)
            x += rw
            row = max(row, rh)
        if ok:
            return tex, size
    raise ValueError("texture trop grande")


def _finish(name, parts, extras, extra_tex_def, width, height):
    """parts : head, body, right_arm, left_arm, right_leg, left_leg (box,pos,rot?,dims)."""
    items = [("head", parts["head"]["dims"]), ("hat", parts["head"]["dims"]), ("body", parts["body"]["dims"]),
             ("right_arm", parts["right_arm"]["dims"]), ("right_leg", parts["right_leg"]["dims"])]
    items += [(k, v["dims"]) for k, v in extra_tex_def.items()]
    tex, size = _pack(items)
    parts["head"]["tex"] = tex["head"]
    parts["body"]["tex"] = tex["body"]
    parts["right_arm"]["tex"] = parts["left_arm"]["tex"] = tex["right_arm"]
    parts["right_leg"]["tex"] = parts["left_leg"]["tex"] = tex["right_leg"]
    dims = {k: v["dims"] for k, v in parts.items()}
    dims["hat"] = parts["head"]["dims"]
    for e in extras:
        e["tex"] = list(tex[e["tex_key"]])
    extra_tex = {k: dict(tex=tex[k], dims=v["dims"], role=v["role"]) for k, v in extra_tex_def.items()}
    return dict(parts={k: {kk: vv for kk, vv in v.items() if kk != "dims"} for k, v in parts.items()},
                hat_tex=list(tex["hat"]), tex_size=size, height=height, width=width, _dims=dims,
                extras=extras, extra_tex=extra_tex)


def quad(name, head, body, leg, extras_def, width, height, head_dy=0.0):
    hw, hh, hd = head
    bw, bl, bt = body
    lw, lh, ld = leg
    ly = 24 - lh
    cy = ly - bt / 2.0
    parts = {
        "head": dict(box=[-hw / 2, -hh * 0.6, -hd, hw, hh, hd], pos=[0, cy - 0.5 + head_dy, -bl / 2 + hd * 0.3], dims=head),
        "body": dict(box=[-bw / 2, -bl / 2, -bt / 2, bw, bl, bt], pos=[0, cy, 0], rot=[PI2, 0, 0], dims=(bw, bl, bt)),
    }
    fx = bw / 2 - lw / 2
    fz = bl / 2 - ld / 2 - 0.5
    parts["right_arm"] = dict(box=[-lw / 2, 0, -ld / 2, lw, lh, ld], pos=[-fx, ly, -fz], dims=leg)
    parts["left_arm"] = dict(box=[-lw / 2, 0, -ld / 2, lw, lh, ld], pos=[fx, ly, -fz], dims=leg)
    parts["right_leg"] = dict(box=[-lw / 2, 0, -ld / 2, lw, lh, ld], pos=[-fx, ly, fz], dims=leg)
    parts["left_leg"] = dict(box=[-lw / 2, 0, -ld / 2, lw, lh, ld], pos=[fx, ly, fz], dims=leg)
    extras, extra_tex = [], {}
    for (key, parent, dims, box, pos, rot, role, texkey) in extras_def(cy, bl, ly):
        extra_tex.setdefault(texkey, dict(dims=dims, role=role))
        extras.append(dict(key=key, parent=parent, box=box, pos=pos, rot=rot, tex_key=texkey, dims=list(dims)))
    return _finish(name, parts, extras, extra_tex, width, height)


def _ear_pair(dims, box_r, box_l, pos_r, pos_l, rot_r=(0, 0, 0), rot_l=(0, 0, 0), role="main", key="ear"):
    return [("ear_r", "head", dims, box_r, pos_r, list(rot_r), role, key), ("ear_l", "head", dims, box_l, pos_l, list(rot_l), role, key)]


def rabbit():
    def ex(cy, bl, ly):
        e = _ear_pair((2, 6, 1), [-1, -6, -0.5, 2, 6, 1], [-1, -6, -0.5, 2, 6, 1], [-1.4, -3, -1.5], [1.4, -3, -1.5], (0, 0, -0.12), (0, 0, 0.12))
        e.append(("tail", "root", (3, 3, 2), [-1.5, -1.5, 0, 3, 3, 2], [0, cy - 1, bl / 2], [0, 0, 0], "light", "tail"))
        return e
    return quad("rabbit", (5, 5, 5), (6, 9, 5), (2, 4, 2), ex, 0.4, 0.5)


def sheep():
    def ex(cy, bl, ly):
        return _ear_pair((3, 2, 1), [-3, 0, -0.5, 3, 2, 1], [0, 0, -0.5, 3, 2, 1], [-3, -2.2, -1.5], [3, -2.2, -1.5], (0, 0, 0.4), (0, 0, -0.4), "dark")
    return quad("sheep", (6, 6, 6), (8, 12, 8), (3, 9, 3), ex, 0.9, 1.3, head_dy=-1.0)


def goat():
    def ex(cy, bl, ly):
        e = _ear_pair((3, 2, 1), [-3, 0, -0.5, 3, 2, 1], [0, 0, -0.5, 3, 2, 1], [-2.5, -2.2, -1.5], [2.5, -2.2, -1.5], (0, 0, 0.5), (0, 0, -0.5), "main", "gear")
        e += [("horn_r", "head", (1, 5, 1), [-0.5, -5, -0.5, 1, 5, 1], [-1.2, -3.4, -2], [-0.25, 0, -0.15], "light", "horn"),
              ("horn_l", "head", (1, 5, 1), [-0.5, -5, -0.5, 1, 5, 1], [1.2, -3.4, -2], [-0.25, 0, 0.15], "light", "horn"),
              ("tail", "root", (2, 3, 1), [-1, -1, 0, 2, 3, 1], [0, cy - 2, bl / 2], [0, 0, 0], "main", "tail")]
        return e
    return quad("goat", (5, 6, 6), (7, 11, 7), (3, 9, 3), ex, 0.9, 1.3, head_dy=-1.5)


def cat():
    def ex(cy, bl, ly):
        e = _ear_pair((2, 2, 1), [-1, -2, -0.5, 2, 2, 1], [-1, -2, -0.5, 2, 2, 1], [-1.6, -2.7, -1.5], [1.6, -2.7, -1.5])
        e.append(("tail", "root", (1, 8, 1), [-0.5, -8, -0.5, 1, 8, 1], [0, cy - 0.5, bl / 2], [-0.8, 0, 0], "dark", "tail"))
        return e
    return quad("cat", (5, 4, 5), (4, 10, 5), (2, 7, 2), ex, 0.5, 0.6)


def dog():
    def ex(cy, bl, ly):
        e = _ear_pair((2, 4, 1), [-1, 0, -0.5, 2, 4, 1], [-1, 0, -0.5, 2, 4, 1], [-3.2, -3.4, -1.5], [3.2, -3.4, -1.5], (0, 0, 0.25), (0, 0, -0.25), "dark")
        e.append(("snout", "head", (3, 2, 2), [-1.5, -0.5, -2, 3, 2, 2], [0, 0, -6], [0, 0, 0], "light", "snout"))
        e.append(("tail", "root", (2, 6, 2), [-1, -6, -1, 2, 6, 2], [0, cy - 1, bl / 2], [-1.0, 0, 0], "main", "tail"))
        return e
    return quad("dog", (6, 6, 6), (6, 11, 6), (3, 8, 3), ex, 0.6, 0.85)


def tortoise():
    def ex(cy, bl, ly):
        return [("shell", "root", (12, 3, 14), [-6, -1.5, -7, 12, 3, 14], [0, cy - 2.5, 0], [0, 0, 0], "dark", "shell")]
    return quad("tortoise", (4, 3, 4), (10, 12, 4), (3, 3, 3), ex, 1.0, 0.5)


def spider():
    parts = {
        "head": dict(box=[-3, -3, -6, 6, 6, 6], pos=[0, 15, -3], dims=(6, 6, 6)),
        "body": dict(box=[-3, -3, -3, 6, 6, 6], pos=[0, 15, 0], dims=(6, 6, 6)),
        "right_arm": dict(box=[-0.5, 0, -0.5, 1, 1, 1], pos=[0, 15, 0], dims=(1, 1, 1)),
        "left_arm": dict(box=[-0.5, 0, -0.5, 1, 1, 1], pos=[0, 15, 0], dims=(1, 1, 1)),
        "right_leg": dict(box=[-0.5, 0, -0.5, 1, 1, 1], pos=[0, 15, 0], dims=(1, 1, 1)),
        "left_leg": dict(box=[-0.5, 0, -0.5, 1, 1, 1], pos=[0, 15, 0], dims=(1, 1, 1)),
    }
    extras, extra_tex = [], {}
    extra_tex["abdomen"] = dict(dims=(10, 8, 12), role="main")
    extra_tex["spleg"] = dict(dims=(16, 2, 2), role="dark")
    extras.append(dict(key="abdomen", parent="root", box=[-5, -4, 0, 10, 8, 12], pos=[0, 15, 3], rot=[0, 0, 0], tex_key="abdomen", dims=[10, 8, 12]))
    zs = [-2.5, -0.8, 0.8, 2.5]
    yr = [-0.7, -0.35, 0.35, 0.7]
    for i in range(4):
        extras.append(dict(key=f"leg_r{i}", parent="root", box=[-15, -1, -1, 16, 2, 2], pos=[-3, 15, zs[i]], rot=[0, yr[i], -0.6],
                           tex_key="spleg", dims=[16, 2, 2]))
        extras.append(dict(key=f"leg_l{i}", parent="root", box=[-1, -1, -1, 16, 2, 2], pos=[3, 15, zs[i]], rot=[0, -yr[i], 0.6],
                           tex_key="spleg", dims=[16, 2, 2]))
    return _finish("spider", parts, extras, extra_tex, 1.4, 0.9)


SPECIAL = {"rabbit": rabbit(), "sheep": sheep(), "goat": goat(), "cat": cat(), "dog": dog(), "tortoise": tortoise(), "spider": spider()}
