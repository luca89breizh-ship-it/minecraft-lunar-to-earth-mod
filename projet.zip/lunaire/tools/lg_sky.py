"""Sprites des astres du ciel lunaire : Terre (continents), Jupiter, Saturne, Mars, Vénus, Mercure, Neptune."""
import math
import random
from lg_core import Img, RES

OUT = RES / "lunaire_sky"

# ------------------------------------------------------------------ bruit
def vnoise(seed, cell):
    rng = random.Random(seed)
    g = [[rng.random() for _ in range(64)] for _ in range(64)]

    def f(x, y):
        gx, gy = x / cell, y / cell
        x0, y0 = int(math.floor(gx)) % 62, int(math.floor(gy)) % 62
        tx, ty = gx - math.floor(gx), gy - math.floor(gy)
        tx, ty = tx * tx * (3 - 2 * tx), ty * ty * (3 - 2 * ty)
        a = g[y0][x0] * (1 - tx) + g[y0][x0 + 1] * tx
        b = g[y0 + 1][x0] * (1 - tx) + g[y0 + 1][x0 + 1] * tx
        return a * (1 - ty) + b * ty
    return f


def fbm(seed, cell):
    n = [vnoise(seed + i, cell / (2 ** i)) for i in range(3)]
    return lambda x, y: 0.55 * n[0](x, y) + 0.3 * n[1](x, y) + 0.15 * n[2](x, y)


def mixc(a, b, t):
    t = max(0.0, min(1.0, t))
    return tuple(a[i] * (1 - t) + b[i] * t for i in range(3))


# ------------------------------------------------------------------ sphère
LIGHT = (-0.55, -0.5, 0.67)


def sphere(size, surface, tilt=0.0, atmosphere=None, night=0.1, w=None, h=None, ox=0, oy=0):
    """Rend une sphère éclairée. surface(lon, lat, x, y) -> (r, g, b)."""
    w = w or size
    h = h or size
    img = Img(w, h)
    r = size / 2 - 0.5
    cx, cy = (w - 1) / 2 + ox, (h - 1) / 2 + oy
    for py in range(h):
        for px in range(w):
            x, y = (px - cx) / r, (py - cy) / r
            d2 = x * x + y * y
            if d2 > 1.0:
                continue
            z = math.sqrt(1 - d2)
            # rotation d'inclinaison autour de l'axe de vue
            xr = x * math.cos(tilt) - y * math.sin(tilt)
            yr = x * math.sin(tilt) + y * math.cos(tilt)
            lat = math.degrees(math.asin(max(-1, min(1, -yr))))
            lon = math.degrees(math.atan2(xr, z))
            col = surface(lon, lat, px, py)
            lit = max(0.0, x * LIGHT[0] + y * LIGHT[1] + z * LIGHT[2])
            k = night + (1 - night) * min(1.0, lit * 1.15)
            col = tuple(c * k for c in col)
            if atmosphere:
                rim = max(0.0, (math.sqrt(d2) - 0.8) / 0.2)
                col = mixc(col, atmosphere, rim * 0.55 * (0.4 + 0.6 * min(1.0, lit + 0.3)))
            img.set(px, py, tuple(int(c) for c in col) + (255,))
    return img


# ------------------------------------------------------------------ Terre
def inside(poly, lon, lat):
    c = False
    n = len(poly)
    j = n - 1
    for i in range(n):
        xi, yi = poly[i]
        xj, yj = poly[j]
        if (yi > lat) != (yj > lat) and lon < (xj - xi) * (lat - yi) / (yj - yi + 1e-9) + xi:
            c = not c
        j = i
    return c


CONT = {
    "africa": [(-17, 21), (-16, 12), (-8, 4), (5, 5), (9, 4), (10, -2), (13, -12), (12, -18), (15, -27), (19, -34), (27, -33), (32, -28),
               (35, -20), (40, -12), (40, -3), (43, 2), (51, 11), (43, 12), (37, 22), (33, 31), (25, 32), (10, 37), (-6, 36), (-13, 28)],
    "eurasia": [(-9, 37), (-9, 43), (-2, 44), (-4, 48), (2, 51), (8, 54), (10, 58), (5, 62), (15, 69), (25, 71), (40, 68), (60, 70), (80, 73),
                (110, 77), (140, 72), (170, 70), (180, 66), (160, 60), (155, 50), (142, 46), (135, 35), (128, 35), (122, 40), (122, 30),
                (120, 22), (108, 20), (106, 10), (100, 13), (103, 1), (98, 8), (92, 22), (80, 15), (77, 8), (72, 20), (67, 25), (57, 25),
                (52, 30), (48, 30), (56, 26), (58, 22), (52, 16), (43, 13), (35, 28), (36, 36), (27, 37), (26, 41), (20, 40), (13, 45),
                (12, 38), (5, 43), (-1, 38)],
    "namerica": [(-168, 66), (-165, 60), (-150, 60), (-135, 55), (-125, 48), (-124, 40), (-117, 32), (-110, 23), (-105, 20), (-97, 16),
                 (-92, 15), (-86, 12), (-80, 8), (-78, 8), (-82, 14), (-87, 21), (-97, 26), (-97, 28), (-90, 29), (-82, 26), (-80, 25),
                 (-81, 31), (-76, 35), (-70, 41), (-66, 45), (-60, 47), (-55, 52), (-62, 58), (-78, 62), (-90, 69), (-110, 70),
                 (-130, 70), (-150, 71)],
    "greenland": [(-55, 60), (-45, 60), (-20, 70), (-20, 82), (-60, 82), (-70, 76)],
    "samerica": [(-78, 8), (-72, 12), (-62, 10), (-52, 5), (-50, 0), (-35, -6), (-39, -14), (-48, -26), (-58, -38), (-65, -42), (-68, -52),
                 (-72, -53), (-75, -45), (-72, -30), (-70, -18), (-76, -12), (-81, -5), (-80, 2)],
    "australia": [(114, -22), (122, -18), (130, -12), (137, -12), (142, -11), (146, -19), (153, -27), (150, -37), (141, -38), (135, -34),
                  (129, -32), (115, -34)],
    "uk": [(-6, 50), (1, 51), (-2, 56), (-5, 58), (-6, 54)],
    "japan": [(130, 31), (135, 34), (141, 38), (142, 43), (140, 36), (133, 33)],
    "indonesia": [(95, 5), (105, -6), (115, -8), (118, -2), (108, 1)],
    "madagascar": [(44, -25), (49, -15), (50, -13), (47, -24)],
}


def earth(size=48):
    cl = fbm(11, 9)
    sand = fbm(5, 6)

    def surf(lon, lat, px, py):
        land = None
        for k, poly in CONT.items():
            if inside(poly, lon, lat):
                land = k
                break
        if lat < -68:
            land = "antarctica"
        if land:
            n = sand(lon * 0.6 + 50, lat * 0.6 + 50)
            if land in ("greenland", "antarctica") or abs(lat) > 70:
                col = (240, 246, 250)
            elif 12 < lat < 32 and -16 < lon < 55 and land in ("africa", "eurasia"):
                col = mixc((205, 175, 105), (170, 140, 80), n)
            elif abs(lat) < 14 and land in ("africa", "samerica", "indonesia"):
                col = mixc((30, 110, 45), (22, 85, 40), n)
            elif land == "australia":
                col = mixc((190, 130, 80), (140, 110, 60), n)
            else:
                col = mixc((70, 140, 65), (110, 130, 70), n)
        else:
            d = 0.5 + 0.5 * math.sin(lat * 0.1)
            col = mixc((12, 40, 110), (28, 80, 160), d * 0.5 + 0.2)
        c = cl(px * 1.3, py * 1.3)
        if c > 0.55:
            col = mixc(col, (250, 250, 252), min(1.0, (c - 0.55) / 0.12) * 0.85)
        return col
    return sphere(size, surf, tilt=0.35, atmosphere=(120, 180, 255), night=0.08)


# ------------------------------------------------------------------ autres planètes
def jupiter(size=30):
    n = fbm(21, 6)
    bands = [(214, 192, 160), (175, 120, 80), (230, 215, 190), (160, 105, 75), (222, 200, 170), (185, 135, 95), (235, 222, 200), (170, 120, 85)]

    def surf(lon, lat, px, py):
        t = (lat + 90) / 180 * len(bands) + (n(px * 0.9, py * 2.2) - 0.5) * 1.6
        i = int(math.floor(t)) % len(bands)
        col = mixc(bands[i], bands[(i + 1) % len(bands)], t - math.floor(t))
        dx, dy = (lon - 20) / 22, (lat + 20) / 11
        if dx * dx + dy * dy < 1:
            col = mixc(col, (190, 75, 50), 0.85 * (1 - dx * dx - dy * dy) + 0.2)
        return col
    return sphere(size, surf, tilt=0.05, night=0.12)


def saturn(size=22, w=46, h=30):
    n = fbm(31, 8)
    bands = [(232, 210, 150), (214, 190, 130), (238, 222, 170), (205, 180, 125)]
    img = Img(w, h)
    cx, cy = (w - 1) / 2, (h - 1) / 2
    tilt = -0.32
    ring = [(0, 0, 0)] * 0

    def ring_px(px, py):
        x, y = px - cx, py - cy
        xr = x * math.cos(tilt) - y * math.sin(tilt)
        yr = x * math.sin(tilt) + y * math.cos(tilt)
        yr *= 3.2
        d = math.hypot(xr, yr) / (w / 2 - 1)
        return d, yr

    # anneau arrière, planète, anneau avant
    def draw_ring(front):
        for py in range(h):
            for px in range(w):
                d, yr = ring_px(px, py)
                if 0.58 < d < 0.98 and ((yr > 0) == front):
                    if 0.80 < d < 0.84:
                        continue
                    shade = 0.75 + 0.25 * math.sin(d * 40)
                    col = mixc((150, 130, 95), (235, 215, 165), shade)
                    img.set(px, py, tuple(int(c) for c in col) + (255,))

    draw_ring(False)

    def surf(lon, lat, px, py):
        t = (lat + 90) / 180 * len(bands) * 1.5 + (n(px, py * 2) - 0.5)
        i = int(math.floor(t)) % len(bands)
        return mixc(bands[i], bands[(i + 1) % len(bands)], t - math.floor(t))
    body = sphere(size, surf, tilt=0.0, night=0.12)
    ox, oy = (w - size) // 2, (h - size) // 2
    for y in range(size):
        for x in range(size):
            c = body.get(x, y)
            if c[3]:
                img.set(x + ox, y + oy, c)
    draw_ring(True)
    return img


def mars(size=14):
    n = fbm(41, 4)

    def surf(lon, lat, px, py):
        col = mixc((190, 95, 55), (140, 70, 45), n(px, py))
        if n(px + 20, py + 9) > 0.62:
            col = mixc(col, (95, 55, 45), 0.7)
        if abs(lat) > 76:
            col = (245, 240, 235)
        return col
    return sphere(size, surf, tilt=0.2, atmosphere=(220, 150, 110), night=0.1)


def venus(size=16):
    n = fbm(51, 4)

    def surf(lon, lat, px, py):
        t = n(px * 0.8 + math.sin(py * 0.7) * 2, py * 1.6)
        return mixc((235, 205, 130), (250, 235, 180), t)
    return sphere(size, surf, atmosphere=(255, 230, 170), night=0.15)


def mercury(size=9):
    n = fbm(61, 3)

    def surf(lon, lat, px, py):
        v = 110 + 50 * n(px * 1.5, py * 1.5)
        return (v, v * 0.97, v * 0.93)
    return sphere(size, surf, night=0.1)


def neptune(size=14):
    n = fbm(71, 5)

    def surf(lon, lat, px, py):
        col = mixc((40, 70, 190), (70, 120, 230), n(px * 0.6, py * 2))
        if abs(n(px + 9, py + 3) - 0.5) < 0.05:
            col = mixc(col, (200, 225, 255), 0.6)
        return col
    return sphere(size, surf, atmosphere=(120, 170, 255), night=0.12)


def gen_all():
    OUT.mkdir(parents=True, exist_ok=True)
    earth(48).save(OUT / "earth.png")
    jupiter(30).save(OUT / "jupiter.png")
    saturn().save(OUT / "saturn.png")
    mars(14).save(OUT / "mars.png")
    venus(16).save(OUT / "venus.png")
    mercury(9).save(OUT / "mercury.png")
    neptune(14).save(OUT / "neptune.png")
