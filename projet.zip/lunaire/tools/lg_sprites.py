"""Peintre de sprites 16x16 : silhouettes colorées + biseau + contour = icônes propres."""
import math
import random
from lg_core import Img, shade, clamp

OUT = (18, 18, 28, 255)


def mix(a, b, t):
    return tuple(clamp(a[i] * (1 - t) + b[i] * t) for i in range(3)) + (255,)


def lighter(c, n=40):
    return shade(c, n)


def darker(c, n=40):
    return shade(c, -n)


def circle(img, cx, cy, r, c):
    for y in range(16):
        for x in range(16):
            if (x - cx) ** 2 + (y - cy) ** 2 <= r * r + 0.3:
                img.set(x, y, c)


def line(img, x0, y0, x1, y1, c):
    n = max(abs(x1 - x0), abs(y1 - y0), 1)
    for i in range(n + 1):
        img.set(round(x0 + (x1 - x0) * i / n), round(y0 + (y1 - y0) * i / n), c)


def opaque(img, x, y):
    return 0 <= x < 16 and 0 <= y < 16 and img.get(x, y)[3] > 0


def finish(img, outline=True, bevel=True):
    """Biseau (haut clair / bas sombre) puis contour sombre."""
    src = Img(16, 16)
    src.px = list(img.px)
    if bevel:
        for y in range(16):
            for x in range(16):
                if not opaque(src, x, y):
                    continue
                c = src.get(x, y)
                if not opaque(src, x, y - 1) or not opaque(src, x - 1, y):
                    img.set(x, y, lighter(c, 38))
                elif not opaque(src, x, y + 1) or not opaque(src, x + 1, y):
                    img.set(x, y, darker(c, 38))
    if outline:
        base = Img(16, 16)
        base.px = list(img.px)
        for y in range(16):
            for x in range(16):
                if opaque(base, x, y):
                    continue
                if any(opaque(base, x + dx, y + dy) for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1))):
                    img.set(x, y, OUT)
    return img


# ------------------------------------------------------------------ formes de matériaux

def ingot(c):
    i = Img(16, 16)
    for k in range(5):
        for x in range(3 + k, 12 + k):
            i.set(x, 10 - k + 1 if False else 10 - k, c) if False else None
    rows = [(4, 11), (3, 12), (3, 12), (2, 11), (2, 11), (1, 10)]
    y0 = 5
    for n, (a, b) in enumerate(rows):
        for x in range(a, b + 1):
            i.set(x + 1, y0 + n, c)
    for x in range(3, 12):
        i.set(x, 5, lighter(c, 25))
    return finish(i)


def plate(c):
    i = Img(16, 16)
    i.rect(3, 4, 10, 9, c)
    i.rect(5, 6, 6, 5, darker(c, 20))
    for p in ((4, 5), (11, 5), (4, 12), (11, 12)):
        i.set(*p, lighter(c, 50))
    return finish(i)


def gear(c):
    i = Img(16, 16)
    circle(i, 7.5, 7.5, 4.6, c)
    for a in range(8):
        ang = a * math.pi / 4
        cx, cy = 7.5 + 5.6 * math.cos(ang), 7.5 + 5.6 * math.sin(ang)
        circle(i, cx, cy, 1.4, c)
    circle(i, 7.5, 7.5, 1.8, (0, 0, 0, 0))
    for y in range(16):
        for x in range(16):
            if (x - 7.5) ** 2 + (y - 7.5) ** 2 <= 3.2:
                i.px[y * 16 + x] = (0, 0, 0, 0)
    return finish(i)


def wire(c):
    i = Img(16, 16)
    for k in range(4):
        y = 3 + k * 3
        line(i, 3, y, 12, y + 1, c)
        line(i, 3, y + 1, 12, y + 2, darker(c, 25))
    return finish(i)


def rod(c):
    i = Img(16, 16)
    line(i, 3, 12, 12, 3, c)
    line(i, 4, 12, 12, 4, darker(c, 20))
    line(i, 3, 11, 11, 3, lighter(c, 25))
    return finish(i)


def gem(c):
    i = Img(16, 16)
    pts = [(7, 2), (8, 2), (6, 3), (9, 3), (5, 4), (10, 4), (4, 5), (11, 5)]
    for y in range(3, 13):
        w = (y - 3) if y < 7 else (12 - y)
        for x in range(8 - w - 1, 8 + w + 1):
            i.set(x, y, c)
    for y in range(3, 8):
        i.set(7, y, lighter(c, 70))
        i.set(6, y - 1, lighter(c, 45))
    return finish(i)


def pile(c):
    i = Img(16, 16)
    rng = random.Random(sum(c[:3]))
    for y in range(7, 13):
        for x in range(3 + (y - 7), 13 - (y - 7) if False else 13):
            if abs(x - 7.5) <= 2 + (y - 7) * 1.1:
                i.set(x, y, shade(c, rng.randint(-14, 14)))
    return finish(i)


# ------------------------------------------------------------------ outils

HANDLE = (140, 110, 80, 255)


def tool(kind, head):
    i = Img(16, 16)
    hd, hl = darker(head, 20), lighter(head, 30)
    if kind == "pickaxe":
        line(i, 3, 13, 11, 5, HANDLE)
        line(i, 4, 13, 12, 5, darker(HANDLE, 25))
        for x in range(3, 13):
            i.set(x, 3 + abs(x - 8) // 2 + (1 if x in (3, 12) else 0), head)
        i.set(2, 5, head), i.set(13, 5, head)
        i.rect(5, 3, 6, 1, hl)
    elif kind == "axe":
        line(i, 3, 13, 10, 4, HANDLE)
        line(i, 4, 13, 11, 4, darker(HANDLE, 25))
        i.rect(8, 2, 4, 6, head)
        i.rect(11, 3, 2, 4, head)
        i.rect(8, 2, 4, 1, hl)
    elif kind == "shovel":
        line(i, 4, 13, 10, 7, HANDLE)
        line(i, 5, 13, 11, 7, darker(HANDLE, 25))
        for y in range(2, 8):
            i.rect(10 - (1 if y in (2, 7) else 0), y, 3 + (0 if y not in (2, 7) else -1), 1, head)
        i.rect(10, 2, 2, 1, hl)
    elif kind == "sword":
        line(i, 3, 12, 12, 3, head)
        line(i, 4, 12, 12, 4, hd)
        line(i, 3, 11, 11, 3, hl)
        line(i, 2, 13, 4, 11, HANDLE)
        line(i, 4, 9, 6, 11, darker(head, 30))
        i.set(2, 14, HANDLE)
    elif kind == "hoe":
        line(i, 3, 13, 10, 5, HANDLE)
        line(i, 4, 13, 11, 5, darker(HANDLE, 25))
        i.rect(8, 3, 5, 2, head)
        i.rect(8, 5, 2, 2, head)
        i.rect(8, 3, 5, 1, hl)
    return finish(i)


# ------------------------------------------------------------------ armures

def armor(kind, c, accent):
    i = Img(16, 16)
    if kind == "helmet":
        i.rect(3, 3, 10, 8, c)
        i.rect(2, 5, 12, 6, c)
        i.rect(4, 6, 8, 3, accent)
        i.rect(5, 6, 6, 1, lighter(accent, 60))
        i.rect(3, 11, 3, 2, darker(c, 25)), i.rect(10, 11, 3, 2, darker(c, 25))
    elif kind == "chestplate":
        i.rect(3, 3, 10, 10, c)
        i.rect(1, 3, 3, 5, c), i.rect(12, 3, 3, 5, c)
        i.rect(6, 2, 4, 2, (0, 0, 0, 0))
        i.rect(5, 6, 6, 4, accent)
        i.rect(7, 7, 2, 2, lighter(accent, 70))
        i.rect(3, 12, 10, 1, darker(c, 30))
    elif kind == "leggings":
        i.rect(3, 2, 10, 4, c)
        i.rect(3, 6, 4, 8, c), i.rect(9, 6, 4, 8, c)
        i.rect(3, 3, 10, 1, accent)
        i.rect(3, 12, 4, 2, darker(c, 25)), i.rect(9, 12, 4, 2, darker(c, 25))
    else:
        i.rect(2, 7, 4, 6, c), i.rect(10, 7, 4, 6, c)
        i.rect(1, 11, 5, 3, c), i.rect(10, 11, 5, 3, c)
        i.rect(2, 7, 4, 1, accent), i.rect(10, 7, 4, 1, accent)
        i.rect(1, 13, 5, 1, darker(c, 35)), i.rect(10, 13, 5, 1, darker(c, 35))
    return finish(i)


# ------------------------------------------------------------------ objets spéciaux

METAL = (150, 155, 165, 255)
DARK = (60, 64, 76, 255)


def box(i, x, y, w, h, c):
    i.rect(x, y, w, h, c)


def painters():
    """nom -> fonction() -> Img (objets spéciaux dessinés à la main)."""
    P = {}

    def battery():
        i = Img(16, 16)
        box(i, 5, 3, 6, 11, (60, 170, 90, 255)), box(i, 7, 1, 2, 2, METAL)
        box(i, 5, 3, 6, 3, (230, 230, 80, 255))
        i.set(8, 9, (255, 255, 255, 255)), i.set(7, 10, (255, 255, 255, 255)), i.set(8, 11, (255, 255, 255, 255))
        return finish(i)
    P["lithium_battery"] = battery

    def solar_cell():
        i = Img(16, 16)
        box(i, 2, 3, 12, 10, (30, 55, 130, 255))
        for k in (6, 10):
            i.rect(k, 3, 1, 10, (190, 195, 205, 255))
        i.rect(2, 8, 12, 1, (190, 195, 205, 255))
        i.rect(3, 4, 2, 2, (110, 150, 230, 255))
        return finish(i)
    P["solar_cell"] = solar_cell

    def circuit(c, chip):
        def f():
            i = Img(16, 16)
            box(i, 2, 3, 12, 10, c)
            box(i, 6, 6, 4, 4, chip)
            for k in range(4):
                i.set(5 - 1, 5 + k, (225, 190, 70, 255)), i.set(10 + 1, 5 + k, (225, 190, 70, 255))
            line(i, 3, 4, 6, 4, lighter(c, 70)), line(i, 10, 11, 13, 11, lighter(c, 70))
            return finish(i)
        return f
    P["advanced_circuit"] = circuit((30, 80, 160, 255), (30, 30, 40, 255))
    P["processor"] = circuit((120, 40, 140, 255), (200, 200, 210, 255))

    def silicon():
        i = Img(16, 16)
        for y, (a, b) in enumerate([(5, 10), (4, 11), (3, 12), (3, 12), (4, 11), (5, 10)]):
            for x in range(a, b + 1):
                i.set(x, 4 + y, (70, 75, 95, 255))
        i.set(5, 5, (140, 150, 180, 255)), i.set(6, 5, (140, 150, 180, 255))
        return finish(i)
    P["silicon"] = silicon

    def wafer():
        i = Img(16, 16)
        circle(i, 7.5, 7.5, 5.5, (90, 100, 150, 255))
        circle(i, 7.5, 7.5, 3.5, (120, 140, 200, 255))
        for k in range(-2, 3):
            i.set(7 + k, 7, (200, 220, 255, 255)), i.set(7, 7 + k, (200, 220, 255, 255))
        return finish(i)
    P["silicon_wafer"] = wafer

    def tank(c, big):
        def f():
            i = Img(16, 16)
            w = 8 if big else 6
            x = 8 - w // 2
            box(i, x, 3, w, 11, c)
            box(i, x, 3, w, 2, lighter(c, 40))
            box(i, 6, 1, 4, 2, METAL)
            box(i, x, 9, w, 1, darker(c, 40))
            return finish(i)
        return f
    P["oxygen_tank"] = tank((190, 200, 215, 255), False)
    P["oxygen_tank_full"] = tank((80, 170, 240, 255), False)
    P["oxygen_tank_large"] = tank((90, 180, 250, 255), True)
    P["hydrogen_tank"] = tank((230, 230, 120, 255), True)

    def thruster():
        i = Img(16, 16)
        box(i, 5, 2, 6, 6, METAL)
        for y in range(8, 13):
            box(i, 5 - (y - 8) // 2, y, 6 + (y - 8), 1, DARK)
        box(i, 6, 12, 4, 2, (255, 170, 50, 255))
        box(i, 7, 13, 2, 2, (255, 240, 120, 255))
        return finish(i)
    P["thruster"] = thruster

    def engine():
        i = Img(16, 16)
        box(i, 3, 2, 10, 4, METAL)
        for k in range(3):
            box(i, 3 + k * 4, 6, 3, 6, DARK)
            box(i, 4 + k * 4, 12, 1, 2, (255, 170, 50, 255))
        return finish(i)
    P["rocket_engine"] = engine

    def nose():
        i = Img(16, 16)
        for y in range(2, 14):
            w = (y - 2) // 2 + 1
            box(i, 8 - w, y, 2 * w, 1, (225, 228, 235, 255))
        box(i, 3, 13, 10, 1, (200, 50, 50, 255))
        box(i, 7, 6, 2, 2, (80, 160, 230, 255))
        return finish(i)
    P["nose_cone"] = nose

    def fueltank():
        i = Img(16, 16)
        circle(i, 7.5, 8, 5.5, (210, 215, 225, 255))
        box(i, 3, 6, 10, 4, (210, 215, 225, 255))
        box(i, 3, 7, 10, 2, (230, 130, 40, 255))
        return finish(i)
    P["fuel_tank"] = fueltank

    def canister(c):
        def f():
            i = Img(16, 16)
            box(i, 4, 4, 8, 10, c)
            box(i, 6, 2, 4, 2, METAL), box(i, 10, 3, 2, 1, METAL)
            box(i, 4, 8, 8, 2, lighter(c, 60))
            return finish(i)
        return f
    P["rocket_fuel"] = canister((220, 110, 40, 255))
    P["coolant_canister"] = canister((80, 200, 220, 255))

    def parachute():
        i = Img(16, 16)
        for y in range(2, 8):
            w = 6 - abs(y - 7) // 2 if False else 7 - (7 - y)
            box(i, 8 - min(6, 2 + y), y, 2 * min(6, 2 + y), 1, (240, 240, 245, 255) if y % 2 else (230, 90, 60, 255))
        for k in (-4, 0, 4):
            line(i, 8 + k, 8, 8, 13, (200, 200, 200, 255))
        box(i, 7, 13, 2, 2, DARK)
        return finish(i)
    P["parachute"] = parachute

    def tile():
        i = Img(16, 16)
        box(i, 3, 3, 10, 10, (40, 40, 48, 255))
        box(i, 4, 4, 8, 8, (70, 66, 62, 255))
        for k in range(3):
            line(i, 4, 6 + k * 2, 11, 6 + k * 2, (95, 90, 84, 255))
        return finish(i)
    P["heat_shield_tile"] = tile

    def insulation():
        i = Img(16, 16)
        box(i, 2, 4, 12, 8, (240, 200, 70, 255))
        for k in range(6):
            i.set(3 + k * 2, 5 + (k % 2), (255, 235, 130, 255))
            i.set(3 + k * 2, 9 + (k % 2), (210, 160, 40, 255))
        return finish(i)
    P["insulation"] = insulation

    def life_support():
        i = Img(16, 16)
        box(i, 2, 3, 12, 10, (200, 205, 215, 255))
        box(i, 3, 4, 10, 8, (40, 48, 70, 255))
        box(i, 7, 5, 2, 6, (90, 230, 140, 255)), box(i, 5, 7, 6, 2, (90, 230, 140, 255))
        return finish(i)
    P["life_support_unit"] = life_support

    def core():
        i = Img(16, 16)
        circle(i, 7.5, 7.5, 5.5, (60, 70, 110, 255))
        circle(i, 7.5, 7.5, 3.5, (110, 220, 255, 255))
        circle(i, 7.5, 7.5, 1.6, (255, 255, 255, 255))
        return finish(i)
    P["power_core"] = core

    def valve():
        i = Img(16, 16)
        box(i, 2, 7, 12, 3, METAL)
        circle(i, 7.5, 5, 3, (200, 60, 60, 255))
        box(i, 6, 3, 3, 1, (240, 120, 120, 255))
        return finish(i)
    P["pressure_valve"] = valve

    def lens():
        i = Img(16, 16)
        circle(i, 7.5, 7.5, 5.5, (50, 55, 70, 255))
        circle(i, 7.5, 7.5, 4, (255, 200, 90, 255))
        i.set(6, 5, (255, 255, 230, 255)), i.set(7, 5, (255, 255, 230, 255)), i.set(6, 6, (255, 255, 230, 255))
        return finish(i)
    P["visor_lens"] = lens

    def hull():
        i = Img(16, 16)
        box(i, 2, 3, 12, 10, (215, 218, 226, 255))
        for p in ((3, 4), (12, 4), (3, 11), (12, 11)):
            i.set(*p, (130, 135, 145, 255))
        box(i, 4, 7, 8, 2, (210, 70, 60, 255))
        return finish(i)
    P["hull_panel"] = hull

    def food_pack(c, c2):
        def f():
            i = Img(16, 16)
            box(i, 3, 4, 10, 8, c)
            box(i, 3, 4, 10, 2, lighter(c, 30))
            box(i, 6, 7, 4, 3, c2)
            i.set(2, 5, c), i.set(13, 5, c), i.set(2, 10, c), i.set(13, 10, c)
            return finish(i)
        return f
    P["protein_ration"] = food_pack((200, 150, 90, 255), (240, 230, 200, 255))
    P["energy_gel"] = food_pack((90, 200, 130, 255), (250, 250, 250, 255))

    def tube():
        i = Img(16, 16)
        line(i, 3, 12, 10, 5, (200, 120, 180, 255)), line(i, 4, 12, 11, 5, (170, 90, 150, 255))
        box(i, 10, 3, 3, 3, METAL)
        i.set(2, 13, (230, 160, 210, 255)), i.set(3, 13, (230, 160, 210, 255))
        return finish(i)
    P["nutrient_paste"] = tube

    def bar():
        i = Img(16, 16)
        box(i, 3, 6, 10, 5, (70, 160, 70, 255))
        box(i, 3, 6, 10, 2, (120, 210, 110, 255))
        for k in range(4):
            i.set(4 + k * 3, 9, (40, 110, 50, 255))
        return finish(i)
    P["algae_bar"] = bar

    def bowl(c, c2):
        def f():
            i = Img(16, 16)
            for y in range(8, 13):
                box(i, 3 + (y - 8) // 2, y, 10 - (y - 8), 1, (200, 200, 210, 255))
            box(i, 3, 7, 10, 2, c)
            for k in range(4):
                i.set(4 + k * 2, 6, c2), i.set(5 + k * 2, 5, c2)
            return finish(i)
        return f
    P["space_stew"] = bowl((170, 90, 50, 255), (220, 140, 80, 255))
    P["hydroponic_salad"] = bowl((90, 190, 80, 255), (160, 230, 110, 255))

    def scanner():
        i = Img(16, 16)
        box(i, 4, 2, 8, 12, (90, 95, 110, 255))
        box(i, 5, 3, 6, 5, (80, 230, 150, 255))
        line(i, 5, 6, 7, 4, (20, 80, 50, 255)), line(i, 7, 4, 9, 7, (20, 80, 50, 255)), line(i, 9, 7, 10, 5, (20, 80, 50, 255))
        box(i, 5, 10, 2, 2, (230, 80, 80, 255)), box(i, 9, 10, 2, 2, (230, 220, 80, 255))
        return finish(i)
    P["oxygen_scanner"] = scanner

    def jet():
        i = Img(16, 16)
        box(i, 3, 3, 4, 8, (150, 155, 170, 255)), box(i, 9, 3, 4, 8, (150, 155, 170, 255))
        box(i, 7, 5, 2, 3, DARK)
        for x in (4, 10):
            box(i, x, 11, 2, 2, (255, 170, 50, 255))
            i.set(x, 13, (255, 240, 120, 255))
        return finish(i)
    P["jet_booster"] = jet

    def repair():
        i = Img(16, 16)
        box(i, 2, 5, 12, 8, (200, 70, 60, 255))
        box(i, 6, 3, 4, 2, (160, 40, 40, 255))
        line(i, 5, 11, 10, 7, (230, 230, 235, 255))
        circle(i, 10.5, 7, 1.5, (230, 230, 235, 255))
        return finish(i)
    P["repair_kit"] = repair

    def medkit():
        i = Img(16, 16)
        box(i, 2, 4, 12, 9, (235, 235, 240, 255))
        box(i, 7, 5, 2, 7, (215, 50, 50, 255)), box(i, 5, 7, 6, 3, (215, 50, 50, 255))
        box(i, 6, 3, 4, 1, METAL)
        return finish(i)
    P["medkit"] = medkit

    def pack(c):
        def f():
            i = Img(16, 16)
            box(i, 3, 3, 10, 10, (210, 215, 225, 255))
            box(i, 4, 4, 8, 8, c)
            box(i, 6, 6, 4, 4, lighter(c, 60))
            return finish(i)
        return f
    P["thermal_pack"] = pack((240, 110, 50, 255))
    P["cooling_pack"] = pack((70, 190, 240, 255))

    def blueprint(c):
        def f():
            i = Img(16, 16)
            box(i, 2, 2, 12, 12, c)
            for k in range(4):
                box(i, 4, 4 + k * 2, 8 - (k % 2) * 3, 1, (230, 245, 255, 255))
            return finish(i)
        return f
    P["blueprint_tier1"] = blueprint((60, 120, 90, 255))
    P["blueprint_tier2"] = blueprint((140, 110, 40, 255))
    P["rocket_blueprint"] = blueprint((30, 70, 170, 255))

    def helium():
        i = Img(16, 16)
        pts = [(8, 2), (11, 5), (11, 10), (8, 13), (5, 10), (5, 5)]
        for y in range(3, 13):
            w = 3 if 5 <= y <= 10 else 2
            box(i, 8 - w, y, 2 * w, 1, (230, 200, 90, 255))
        box(i, 7, 4, 2, 7, (255, 245, 190, 255))
        return finish(i)
    P["helium3_crystal"] = helium

    def purifier(dmg):
        def f():
            i = Img(16, 16)
            box(i, 3, 3, 10, 10, (200, 205, 215, 255))
            circle(i, 7.5, 7.5, 3.2, DARK)
            line(i, 5, 7, 10, 8, (130, 135, 150, 255)), line(i, 7, 5, 8, 10, (130, 135, 150, 255))
            i.set(11, 11, (200, 60, 60, 255) if dmg else (80, 230, 120, 255))
            if dmg:
                line(i, 4, 4, 7, 7, (30, 30, 40, 255))
            return finish(i)
        return f
    P["damaged_air_purifier"] = purifier(True)
    P["air_purifier"] = purifier(False)

    def reentry():
        i = Img(16, 16)
        for y in range(2, 11):
            w = 1 + (y - 2) * 0.55
            box(i, round(8 - w), y, round(2 * w), 1, (225, 228, 235, 255))
        box(i, 3, 10, 10, 2, (110, 40, 40, 255))
        box(i, 7, 6, 2, 2, (80, 160, 230, 255))
        box(i, 4, 12, 2, 2, (255, 160, 40, 255)), box(i, 10, 12, 2, 2, (255, 160, 40, 255)), box(i, 7, 12, 2, 3, (255, 210, 80, 255))
        return finish(i)
    P["reentry_module"] = reentry

    def shard():
        i = Img(16, 16)
        for y in range(2, 13):
            w = 1 + min(y - 2, 12 - y) * 0.6
            box(i, round(8 - w), y, round(2 * w) + 1, 1, (110, 60, 190, 255))
        box(i, 7, 4, 2, 5, (210, 170, 255, 255))
        return finish(i)
    P["meteorite_shard"] = shard

    def scrap():
        i = Img(16, 16)
        for (x, y, w, h) in ((3, 8, 5, 4), (6, 5, 4, 5), (9, 8, 4, 3)):
            box(i, x, y, w, h, (150, 150, 158, 255))
        box(i, 7, 6, 2, 1, (210, 210, 218, 255))
        return finish(i)
    P["iron_scrap"] = scrap

    def circuit_board():
        i = Img(16, 16)
        box(i, 2, 3, 12, 10, (30, 120, 60, 255))
        box(i, 6, 6, 3, 3, (30, 30, 30, 255))
        line(i, 3, 4, 6, 4, (110, 220, 130, 255)), line(i, 9, 11, 13, 11, (110, 220, 130, 255)), line(i, 3, 9, 5, 9, (110, 220, 130, 255))
        i.set(11, 5, (225, 190, 70, 255)), i.set(4, 11, (225, 190, 70, 255))
        return finish(i)
    P["circuit_board"] = circuit_board

    def bottle(c):
        def f():
            i = Img(16, 16)
            box(i, 6, 1, 4, 2, (70, 70, 80, 255))
            box(i, 7, 3, 2, 2, (200, 220, 235, 255))
            box(i, 5, 5, 6, 8, (200, 220, 235, 255))
            if c:
                box(i, 6, 7, 4, 5, c)
            return finish(i)
        return f
    P["oxygen_bottle"] = bottle(None)
    P["oxygen_bottle_full"] = bottle((90, 190, 255, 255))

    def hcell():
        i = Img(16, 16)
        box(i, 4, 3, 8, 10, (200, 200, 90, 255))
        box(i, 4, 3, 8, 2, (240, 240, 130, 255))
        box(i, 7, 6, 2, 5, (255, 255, 255, 255))
        return finish(i)
    P["hydrogen_cell"] = hcell
    return P


# ------------------------------------------------------------------ v0.4 : objets utiles

def sprite_extra(it):
    """Sprites des objets utiles (pilule, seringue, fusée…) ; None si l'objet n'en est pas un."""
    i = Img(16, 16)
    if "pill" in it:
        c = it["pill"] + (255,)
        # boîtier + gélule inclinée
        box(i, 3, 9, 10, 5, (70, 74, 90, 255)), box(i, 3, 9, 10, 1, (110, 116, 135, 255))
        for k in range(7):
            circle_px = (4 + k, 8 - k // 2)
            box(i, circle_px[0], circle_px[1], 3, 2, c if k < 4 else (240, 240, 245, 255))
        i.set(6, 4, (255, 255, 255, 255))
        return finish(i)
    if "vial" in it:
        c = it["vial"] + (255,)
        box(i, 7, 1, 2, 3, (200, 200, 210, 255))          # piston
        box(i, 5, 4, 6, 1, (120, 125, 140, 255))
        box(i, 6, 5, 4, 8, (215, 230, 240, 255))
        box(i, 7, 7, 2, 5, c)
        box(i, 7, 13, 2, 2, (190, 190, 200, 255))        # aiguille
        i.set(7, 6, (255, 255, 255, 255))
        return finish(i)
    if "flare" in it:
        c = it.get("color", (230, 60, 50)) + (255,)
        box(i, 7, 6, 3, 9, c), box(i, 7, 6, 1, 9, lighter(c, 50)), box(i, 6, 5, 5, 2, (230, 230, 235, 255))
        for (x, y, col) in ((8, 3, (255, 240, 120)), (8, 2, (255, 200, 60)), (7, 3, (255, 160, 40)), (9, 3, (255, 160, 40)),
                            (8, 1, (255, 255, 200)), (8, 4, (255, 200, 60))):
            i.set(x, y, col + (255,))
        return finish(i)
    if "radar" in it:
        box(i, 7, 11, 2, 3, METAL), box(i, 4, 14, 8, 1, DARK)
        for y in range(2, 11):
            for x in range(2, 14):
                d = (x - 8) ** 2 + (y - 11) ** 2
                if 16 <= d <= 49 and y <= 10:
                    i.set(x, y, (170, 180, 195, 255) if d < 36 else (110, 118, 135, 255))
        line(i, 8, 10, 11, 4, (255, 120, 90, 255))
        i.set(11, 3, (255, 220, 120, 255))
        return finish(i)
    if "compass" in it:
        circle(i, 8, 8, 6, (180, 185, 195, 255))
        circle(i, 8, 8, 5, (30, 40, 70, 255))
        line(i, 8, 8, 11, 4, (255, 90, 90, 255)), line(i, 8, 8, 5, 12, (230, 230, 240, 255))
        for (x, y) in ((8, 3), (8, 13), (3, 8), (13, 8)):
            i.set(x, y, (255, 230, 120, 255))
        i.set(8, 8, (255, 255, 255, 255))
        return finish(i)
    if "food" in it:
        c = it["food"] + (255,)
        for y in range(4, 13):
            for x in range(2, 14):
                if (x - 8) ** 2 / 36 + (y - 8) ** 2 / 20 <= 1:
                    i.set(x, y, c)
        for (x, y) in ((5, 7), (9, 6), (7, 10), (10, 9), (4, 9)):
            box(i, x, y, 2, 1, darker(c, 45))
        box(i, 4, 5, 6, 1, lighter(c, 45))
        return finish(i)
    return None
