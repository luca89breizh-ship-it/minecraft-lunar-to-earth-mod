"""Formes génériques d'objets (16x16) : puces, réservoirs, cristaux, œufs, nourriture…"""
import math
import random
from lg_core import Img
from lg_sprites import box, circle, line, lighter, darker, finish, METAL, DARK


def _c(c):
    return tuple(c[:3]) + (255,)


def spot(i, x, y, c):
    i.set(x, y, c)


def chip(c, c2):
    i = Img(16, 16)
    box(i, 2, 3, 12, 10, _c(c))
    for y in (5, 8, 11):
        line(i, 3, y, 7, y, lighter(c, 55)), line(i, 9, y, 12, y, lighter(c, 55))
    box(i, 6, 6, 4, 4, _c(c2)), box(i, 7, 7, 2, 2, darker(c2, 50))
    for x in (4, 7, 10, 13):
        i.set(x, 2, (215, 190, 80, 255)), i.set(x, 13, (215, 190, 80, 255))
    return finish(i)


def tank(c, c2):
    i = Img(16, 16)
    box(i, 5, 3, 6, 11, _c(c)), box(i, 6, 2, 4, 1, _c(c2)), box(i, 7, 1, 2, 1, METAL)
    box(i, 5, 3, 1, 11, lighter(c, 50)), box(i, 10, 3, 1, 11, darker(c, 45))
    box(i, 5, 7, 6, 1, _c(c2)), box(i, 5, 10, 6, 1, _c(c2))
    return finish(i)


def orb(c, c2):
    i = Img(16, 16)
    circle(i, 7.5, 8, 6, _c(c))
    circle(i, 6, 6, 2, lighter(c, 70))
    for (x, y) in ((10, 10), (9, 11), (11, 9)):
        i.set(x, y, darker(c, 40))
    i.set(5, 5, (255, 255, 255, 255))
    return finish(i)


def crystal(c, c2):
    i = Img(16, 16)
    rows = [(7, 8), (6, 9), (5, 10), (5, 10), (4, 11), (4, 11), (5, 10), (5, 10), (6, 9), (6, 9), (7, 8), (7, 8)]
    for k, (a, b) in enumerate(rows):
        for x in range(a, b + 1):
            i.set(x, 2 + k, _c(c))
    for k, (a, b) in enumerate(rows):
        i.set(a, 2 + k, lighter(c, 60)), i.set(a + 1, 2 + k, lighter(c, 30))
        i.set(b, 2 + k, darker(c, 45))
    line(i, 8, 2, 8, 13, _c(c2))
    i.set(6, 6, (255, 255, 255, 255))
    return finish(i)


def crate(c, c2):
    i = Img(16, 16)
    box(i, 2, 3, 12, 11, _c(c))
    box(i, 2, 3, 12, 2, _c(c2)), box(i, 2, 12, 12, 2, _c(c2)), box(i, 2, 3, 2, 11, _c(c2)), box(i, 12, 3, 2, 11, _c(c2))
    line(i, 4, 5, 11, 12, darker(c, 40)), line(i, 11, 5, 4, 12, darker(c, 40))
    return finish(i)


def coil(c, c2):
    i = Img(16, 16)
    for r in (6, 5):
        for a in range(0, 360, 6):
            i.set(round(7.5 + r * math.cos(math.radians(a))), round(8 + r * 0.85 * math.sin(math.radians(a))), _c(c))
    for r in (4, 3):
        for a in range(0, 360, 8):
            i.set(round(7.5 + r * math.cos(math.radians(a))), round(8 + r * 0.85 * math.sin(math.radians(a))), lighter(c, 45))
    box(i, 12, 8, 3, 1, _c(c2))
    return finish(i)


def lens(c, c2):
    i = Img(16, 16)
    circle(i, 7.5, 8, 6, METAL), circle(i, 7.5, 8, 4.4, _c(c))
    circle(i, 6, 6, 1.5, lighter(c, 80))
    i.set(10, 10, darker(c, 45))
    return finish(i)


def tile(c, c2):
    i = Img(16, 16)
    box(i, 2, 2, 12, 12, _c(c))
    for k in (2, 8):
        box(i, k, 2, 1, 12, darker(c, 40)), box(i, 2, k, 12, 1, darker(c, 40))
    for (x, y) in ((4, 4), (10, 4), (4, 10), (10, 10)):
        box(i, x, y, 2, 2, _c(c2))
    return finish(i)


def fin(c, c2):
    i = Img(16, 16)
    for k in range(12):
        w = max(1, 11 - k)
        box(i, 4, 2 + k, w, 1, _c(c))
    line(i, 4, 2, 4, 13, lighter(c, 55)), line(i, 4, 13, 14, 13, darker(c, 45))
    box(i, 5, 7, 2, 3, _c(c2))
    return finish(i)


def nozzle(c, c2):
    i = Img(16, 16)
    box(i, 5, 2, 6, 3, METAL)
    for k in range(9):
        box(i, 6 - k // 2 - 1, 5 + k, 4 + k + 1 if k < 6 else 12, 1, _c(c)) if False else None
    rows = [(6, 9), (6, 9), (5, 10), (5, 10), (4, 11), (4, 11), (3, 12), (3, 12), (2, 13)]
    for k, (a, b) in enumerate(rows):
        for x in range(a, b + 1):
            i.set(x, 5 + k, _c(c))
        i.set(a, 5 + k, lighter(c, 50)), i.set(b, 5 + k, darker(c, 45))
    box(i, 5, 14, 6, 1, _c(c2))
    return finish(i)


def card(c, c2):
    i = Img(16, 16)
    box(i, 2, 4, 12, 9, _c(c)), box(i, 2, 6, 12, 2, DARK)
    box(i, 3, 9, 4, 3, _c(c2)), box(i, 9, 10, 4, 1, lighter(c, 60))
    return finish(i)


def capsule(c, c2):
    i = Img(16, 16)
    for k, (a, b) in enumerate([(6, 9), (5, 10), (4, 11), (3, 12), (3, 12), (3, 12), (3, 12), (3, 12)]):
        for x in range(a, b + 1):
            i.set(x, 3 + k, _c(c))
    box(i, 2, 11, 12, 3, _c(c2))
    circle(i, 7.5, 7, 1.6, (150, 220, 255, 255))
    i.set(7, 6, (255, 255, 255, 255))
    return finish(i)


def chunk(c, c2):
    i = Img(16, 16)
    pts = [(4, 5), (8, 3), (12, 5), (13, 9), (11, 13), (6, 13), (3, 10)]
    for y in range(16):
        for x in range(16):
            # polygone simple par distance au centre perturbée
            a = math.atan2(y - 8, x - 8)
            r = 5 + 1.6 * math.sin(a * 3 + 1) + 0.8 * math.cos(a * 5)
            if math.hypot(x - 8, y - 8) <= r:
                i.set(x, y, _c(c))
    rng = random.Random(len(c) + c[0])
    for _ in range(6):
        x, y = rng.randint(4, 11), rng.randint(4, 11)
        if i.get(x, y)[3]:
            i.set(x, y, _c(c2))
    return finish(i)


def shell(c, c2):
    i = Img(16, 16)
    for y in range(16):
        for x in range(16):
            if ((x - 8) / 6.2) ** 2 + ((y - 9) / 4.6) ** 2 <= 1:
                i.set(x, y, _c(c))
    for k in range(3, 14, 3):
        line(i, k, 5, k, 13, _c(c2))
    line(i, 3, 9, 13, 9, _c(c2))
    return finish(i)


def dust(c, c2):
    i = Img(16, 16)
    rng = random.Random(c[0] + c[1])
    for _ in range(26):
        a = rng.random() * 6.28
        r = rng.random() * 5.2
        x, y = round(8 + r * math.cos(a)), round(10 + r * 0.6 * math.sin(a))
        i.set(x, y, _c(c) if rng.random() < 0.7 else _c(c2))
    for x in range(4, 12):
        i.set(x, 12, _c(c))
    return finish(i, True, False)


def jar(c, c2):
    i = Img(16, 16)
    box(i, 4, 5, 8, 9, (210, 225, 235, 255)), box(i, 5, 7, 6, 6, _c(c)), box(i, 5, 3, 6, 2, _c(c2)), box(i, 6, 2, 4, 1, METAL)
    i.set(5, 6, (255, 255, 255, 255))
    return finish(i)


def bar(c, c2):
    i = Img(16, 16)
    box(i, 2, 5, 12, 6, _c(c)), box(i, 2, 5, 12, 1, lighter(c, 40)), box(i, 4, 7, 8, 2, _c(c2))
    box(i, 1, 6, 1, 4, darker(c, 30)), box(i, 14, 6, 1, 4, darker(c, 30))
    return finish(i)


def can(c, c2):
    i = Img(16, 16)
    box(i, 4, 3, 8, 10, _c(c)), box(i, 4, 2, 8, 1, METAL), box(i, 4, 13, 8, 1, METAL), box(i, 4, 6, 8, 3, _c(c2))
    box(i, 5, 3, 1, 10, lighter(c, 50))
    return finish(i)


def meat(c, c2):
    i = Img(16, 16)
    for y in range(16):
        for x in range(16):
            if ((x - 7) / 5.5) ** 2 + ((y - 8) / 4.2) ** 2 <= 1:
                i.set(x, y, _c(c))
    box(i, 3, 6, 6, 1, _c(c2)), box(i, 5, 9, 6, 1, _c(c2))
    box(i, 11, 3, 2, 2, (240, 235, 220, 255)), line(i, 10, 5, 11, 4, (240, 235, 220, 255))
    return finish(i)


def egg(c, c2):
    i = Img(16, 16)
    for y in range(1, 15):
        w = [2, 3, 4, 5, 5, 6, 6, 6, 6, 6, 5, 5, 4, 3][y - 1]
        for x in range(8 - w + 0, 8 + w):
            i.set(x, y, _c(c))
    for (x, y, w, h) in ((4, 5, 3, 2), (8, 4, 2, 2), (6, 8, 3, 2), (10, 8, 2, 2), (4, 11, 2, 2), (9, 11, 3, 1)):
        box(i, x, y, w, h, _c(c2))
    i.set(5, 4, (255, 255, 255, 230))
    return finish(i)


def nugget(c, c2):
    i = Img(16, 16)
    for (cx, cy) in ((5, 10), (10, 10), (8, 6)):
        circle(i, cx, cy, 2.1, _c(c))
        i.set(cx - 1, cy - 1, lighter(c, 70))
    return finish(i)


def fluff(c, c2):
    i = Img(16, 16)
    for (cx, cy, r) in ((5, 9, 3), (9, 7, 4), (11, 10, 3), (7, 11, 3)):
        circle(i, cx, cy, r, _c(c))
    i.set(8, 5, lighter(c, 50)), i.set(6, 7, lighter(c, 50)), i.set(10, 9, darker(c, 25))
    return finish(i, True, False)


def core(c, c2):
    i = Img(16, 16)
    circle(i, 7.5, 7.5, 6, DARK)
    circle(i, 7.5, 7.5, 4.3, _c(c))
    circle(i, 7.5, 7.5, 2.2, lighter(c, 90))
    for k in (1, 14):
        i.set(k, 7, _c(c2)), i.set(7, k, _c(c2))
    i.set(6, 6, (255, 255, 255, 255))
    return finish(i)


def ring(c, c2):
    i = Img(16, 16)
    for a in range(0, 360, 5):
        for r in (5.6, 4.6):
            i.set(round(7.5 + r * math.cos(math.radians(a))), round(7.5 + r * math.sin(math.radians(a))), _c(c))
    box(i, 6, 1, 4, 2, _c(c2))
    return finish(i)


def cube(c, c2):
    i = Img(16, 16)
    box(i, 3, 5, 9, 9, _c(c)), box(i, 3, 5, 9, 2, lighter(c, 45)), box(i, 3, 5, 2, 9, lighter(c, 25)), box(i, 10, 5, 2, 9, darker(c, 35))
    box(i, 5, 8, 4, 3, _c(c2))
    return finish(i)


def gadget(c, c2):
    i = Img(16, 16)
    box(i, 4, 2, 8, 12, DARK), box(i, 5, 3, 6, 5, _c(c)), box(i, 5, 9, 2, 2, _c(c2)), box(i, 8, 9, 3, 2, lighter(c2, 40))
    box(i, 5, 12, 6, 1, METAL)
    return finish(i)


SHAPES = {"chip": chip, "tank": tank, "orb": orb, "crystal": crystal, "crate": crate, "coil": coil, "lens": lens, "tile": tile,
          "fin": fin, "nozzle": nozzle, "card": card, "capsule": capsule, "chunk": chunk, "shell": shell, "dust": dust, "jar": jar,
          "bar": bar, "can": can, "meat": meat, "egg": egg, "nugget": nugget, "fluff": fluff, "core": core, "ring": ring,
          "cube": cube, "gadget": gadget}


import lg_vanilla as _VN
SHAPES["fish"] = lambda c, c2: _VN.fish(c, c2)
SHAPES["book"] = lambda c, c2: _VN.book(c)


def paint(shape, c, c2=None):
    if shape == "egg":
        import lg_vanilla
        return lg_vanilla.egg(c, c2 or c)
    return SHAPES[shape](c, c2 or darker(c, 40)[:3])
