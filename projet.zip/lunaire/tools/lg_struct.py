"""Structures de Lunaire (modèles NBT) : capsule, laboratoire, temple, avant-poste, cratère."""
import math
import random
from lg_core import Template, DATA

AIR = "minecraft:air"
PL = "lunaire:lab_plating"
FL = "lunaire:lab_floor"
GL = "lunaire:reinforced_glass"
LT = "lunaire:lab_light"
VT = "lunaire:lab_vent"
AS = "lunaire:ancient_stone"
AB = "lunaire:ancient_bricks"
AG = "lunaire:ancient_glyph"
RK = "minecraft:air"  # placeholder
LROCK = "lunaire:lunar_rock"
REGO = "lunaire:regolith"
SOLAR = "lunaire:solar_panel"


def dome(t, cx, cy, cz, r, rng, decay=0.0, gap=None, glass_band=(1, 3)):
    """Dôme (coque + nervures). gap(dx,dy,dz)->True : ouverture."""
    for x in range(cx - r, cx + r + 1):
        for z in range(cz - r, cz + r + 1):
            for y in range(cy, cy + r + 1):
                dx, dy, dz = x - cx, y - cy, z - cz
                d = math.sqrt(dx * dx + dy * dy + dz * dz)
                if r - 1.0 < d <= r + 0.2:
                    if gap and gap(dx, dy, dz):
                        continue
                    if decay and rng.random() < decay:
                        continue
                    rib = dx == 0 or dz == 0 or abs(dx) == abs(dz) or dy == 0
                    t.set(x, y, z, PL if rib else GL)


def disc(t, cx, cz, y, r, block):
    for x in range(cx - r, cx + r + 1):
        for z in range(cz - r, cz + r + 1):
            if (x - cx) ** 2 + (z - cz) ** 2 <= r * r + 1:
                t.set(x, y, z, block)


def debris(t, rng, n, size, y, blocks, avoid=None):
    for _ in range(n):
        x, z = rng.randint(0, size - 1), rng.randint(0, size - 1)
        if avoid and avoid(x, z):
            continue
        t.set(x, y, z, rng.choice(blocks))


def build_capsule():
    rng = random.Random(1)
    S = 15
    t = Template(S, 9, S)
    t.fill(0, 0, 0, S - 1, 8, S - 1, AIR)
    # cratère d'impact peu profond : anneau de régolithe
    for x in range(S):
        for z in range(S):
            r = math.hypot(x - 7, z - 7)
            if 6.5 < r < 7.6:
                t.set(x, 0, z, REGO)
                if rng.random() < 0.5:
                    t.set(x, 1, z, REGO)
    disc(t, 7, 7, 0, 6, FL)
    gap = lambda dx, dy, dz: (dz >= 4 and abs(dx) <= 1 and dy <= 3) or (rng.random() < 0.05)
    dome(t, 7, 0, 7, 6, rng, 0.04, gap)
    # hublots : bande de verre à y=2 (déjà verre/nervures)
    t.set(7, 1, 7, AIR)
    t.chest(5, 1, 7, "east", "lunaire:chests/capsule")
    t.set(9, 1, 5, SOLAR)
    t.set(9, 1, 9, "lunaire:oxygen_compressor")
    t.set(7, 5, 7, LT)
    t.set(6, 5, 7, PL), t.set(8, 5, 7, PL)
    # débris éparpillés autour
    debris(t, rng, 14, S, 1, [PL, PL, GL, "minecraft:iron_block"], lambda x, z: math.hypot(x - 7, z - 7) < 8)
    t.write(DATA / "structure" / "capsule.nbt")


def build_lab():
    rng = random.Random(2)
    S = 25
    t = Template(S, 14, S)
    c = 12
    t.fill(0, 0, 0, S - 1, 13, S - 1, AIR)
    # fondation
    disc(t, c, c, 0, 11, LROCK)
    disc(t, c, c, 1, 11, LROCK)
    disc(t, c, c, 2, 10, FL)
    for r in range(3, 10, 3):  # anneaux décoratifs
        for a in range(0, 360, 4):
            x, z = round(c + r * math.cos(math.radians(a))), round(c + r * math.sin(math.radians(a)))
            t.set(x, 2, z, PL)
    # coque
    gap = lambda dx, dy, dz: dz >= 8 and abs(dx) <= 1 and dy <= 4  # sas d'entrée au sud
    dome(t, c, 3, c, 9, rng, 0.10, gap)
    # sas d'entrée (couloir)
    for z in range(c + 8, c + 12):
        for x in range(c - 2, c + 3):
            t.set(x, 2, z, FL)
            t.set(x, 7 if False else 6, z, PL)
            for y in range(3, 6):
                t.set(x, y, z, AIR)
        for y in range(3, 6):
            t.set(c - 2, y, z, PL), t.set(c + 2, y, z, PL)
        t.set(c - 2, 6, z, PL), t.set(c + 2, 6, z, PL)
    # console centrale
    t.fill(c - 1, 3, c - 1, c + 1, 3, c + 1, PL)
    t.set(c, 4, c, LT)
    t.fill(c, 4, c, c, 7, c, PL)
    t.set(c, 8, c, LT)
    # machines et alcôves de coffres
    t.set(c - 6, 3, c - 3, "lunaire:electrolyzer")
    t.set(c - 6, 3, c - 1, "lunaire:atmosphere_sealer")
    for i in range(4):
        t.set(c + 5, 3, c - 4 + i, SOLAR)
    t.set(c - 4, 3, c - 6, "lunaire:hydrogen_generator")
    t.chest(c - 4, 3, c + 5, "north", "lunaire:chests/lab")
    t.chest(c + 4, 3, c + 5, "north", "lunaire:chests/lab")
    t.chest(c + 6, 3, c - 6, "west", "lunaire:chests/lab_rare")
    for x in range(c - 5, c + 6, 2):
        t.set(x, 3, c - 8, VT)
    for x, z in ((c - 7, c - 7), (c + 7, c + 7), (c - 7, c + 7), (c + 7, c - 7)):
        t.set(x, 3, z, LT)
    # mât d'antenne extérieur
    t.fill(c + 11, 2, c - 10, c + 11, 11, c - 10, PL)
    t.set(c + 11, 12, c - 10, LT)
    # débris
    debris(t, rng, 30, S, 2, [PL, GL, "minecraft:iron_block"], lambda x, z: math.hypot(x - c, z - c) < 11)
    t.write(DATA / "structure" / "lab.nbt")


def build_temple():
    rng = random.Random(3)
    S = 27
    t = Template(S, 17, S)
    c = 13
    # pyramide à degrés, pleine
    for y in range(0, 10):
        half = 13 - y
        t.fill(c - half, y, c - half, c + half, y, c + half, AS if y % 3 else AB)
    # obélisque qui dépasse du sol
    t.fill(c - 1, 10, c - 1, c + 1, 14, c + 1, AB)
    t.fill(c, 15, c, c, 16, c, AG)
    for y in range(10, 15):
        t.set(c, y, c - 2, AG if y % 2 else AB), t.set(c, y, c + 2, AG if y % 2 else AB)
    # salle centrale
    t.fill(c - 5, 1, c - 5, c + 5, 6, c + 5, AIR)
    t.fill(c - 5, 0, c - 5, c + 5, 0, c + 5, AB)
    t.fill(c - 4, 7, c - 4, c + 4, 7, c + 4, AIR)  # voûte
    for dx in range(-5, 6):
        for dz in range(-5, 6):
            if abs(dx) <= 3 and abs(dz) <= 3 and (dx + dz) % 2 == 0:
                t.set(c + dx, 0, c + dz, AG if (abs(dx) == 3 or abs(dz) == 3) else AS)
    # piliers à glyphes
    for sx in (-4, 4):
        for sz in (-4, 4):
            t.fill(c + sx, 1, c + sz, c + sx, 5, c + sz, AB)
            t.set(c + sx, 3, c + sz, AG)
            t.set(c + sx, 6, c + sz, AG)
    # autel et coffre
    t.fill(c - 1, 1, c - 1, c + 1, 1, c + 1, AS)
    t.set(c, 2, c, AG)
    t.chest(c, 2, c + 1, "south", "lunaire:chests/temple")
    t.set(c, 2, c - 1, AG)
    # galerie d'accès (ouest) : tunnel de 3 de haut
    t.fill(0, 1, c - 1, c - 6, 3, c + 1, AIR)
    for x in range(1, c - 6, 3):
        t.set(x, 3, c, AG)
    # alcôves secondaires avec coffres
    t.fill(c + 6, 1, c - 1, c + 8, 3, c + 1, AIR)
    t.chest(c + 8, 1, c, "west", "lunaire:chests/temple_minor")
    t.write(DATA / "structure" / "temple.nbt")


def build_outpost():
    rng = random.Random(4)
    S = 17
    t = Template(S, 12, S)
    c = 8
    t.fill(0, 0, 0, S - 1, 11, S - 1, AIR)
    disc(t, c, c, 0, 8, LROCK)
    disc(t, c, c, 1, 7, FL)
    # abri 5x5
    t.fill(c - 2, 2, c - 2, c + 2, 5, c + 2, PL)
    t.fill(c - 1, 2, c - 1, c + 1, 4, c + 1, AIR)
    t.fill(c, 2, c + 2, c, 3, c + 2, AIR)
    t.set(c - 2, 3, c, GL)
    t.set(c, 3, c, LT) if False else None
    t.set(c, 4, c, LT)
    t.chest(c - 1, 2, c - 1, "east", "lunaire:chests/outpost")
    # champ de panneaux solaires
    for x in (2, 4, 12, 14):
        for z in (3, 5):
            t.set(x, 2, z, SOLAR)
    # mât radio
    t.fill(c + 5, 2, c + 5, c + 5, 8, c + 5, PL)
    t.set(c + 5, 9, c + 5, LT)
    t.set(c + 4, 2, c + 5, "lunaire:atmosphere_sealer")
    debris(t, rng, 12, S, 2, [PL, GL, "minecraft:iron_block"], lambda x, z: math.hypot(x - c, z - c) < 4)
    t.write(DATA / "structure" / "outpost.nbt")


def build_crater():
    rng = random.Random(5)
    S = 23
    t = Template(S, 9, S)
    c = 11
    R = 11
    for x in range(S):
        for z in range(S):
            r = math.hypot(x - c, z - c)
            if r > R:
                continue
            floor = int(6 * (r / R) ** 2)
            for y in range(0, floor):
                t.set(x, y, z, LROCK)
            t.set(x, floor, z, REGO)
            if r > R - 1.5:
                t.set(x, floor + 1, z, REGO)  # lèvre du cratère
            else:
                for y in range(floor + 1, 8):
                    t.set(x, y, z, AIR)
            if r < 4:
                t.set(x, floor, z, "lunaire:lunar_ice")
    t.fill(c - 1, 0, c - 1, c + 1, 1, c + 1, "lunaire:meteorite_ore")
    t.set(c, 2, c, "lunaire:meteorite_block")
    t.write(DATA / "structure" / "crater.nbt")


def build_all():
    build_capsule()
    build_lab()
    build_temple()
    build_outpost()
    build_crater()
