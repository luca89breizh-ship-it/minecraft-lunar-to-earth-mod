"""Structures de Lunaire (modèles NBT) : capsule, laboratoire, temple, avant-poste, cratère, lac.

Principes (pour éviter trous / aplatissements) :
  * AUCUN remplissage d'air dans une grande boîte : on ne creuse que l'intérieur des dômes / abris.
  * Chaque structure de surface repose sur une « jupe » de roche conique enterrée (fondations),
    donc aucun vide sous elle, même sur une pente.
  * start_height = -FOUND[nom] : le plancher remplace la dernière couche du sol.
  * Toujours de l'air au-dessus des coffres (géré par Template.write).
"""
import math
import random
from lg_core import Template, DATA

AIR = "minecraft:air"
PL = "lunaire:lab_plating"
FL = "lunaire:lab_floor"
GL = "lunaire:reinforced_glass"
LT = "lunaire:lab_light"
VT = "lunaire:lab_vent"
AS = "lunaire:ancient_stone"
AB = "lunaire:ancient_bricks"
AG = "lunaire:ancient_glyph"
LROCK = "lunaire:lunar_rock"
REGO = "lunaire:regolith"
SOLAR = "lunaire:solar_panel"
ICE = "lunaire:lunar_ice"
FROZEN = "lunaire:frozen_regolith"
HYDRO = "lunaire:hydrated_regolith"

# profondeur des fondations (nb de couches sous le sol) => start_height = -FOUND
FOUND = {"capsule": 4, "lab": 7, "outpost": 5, "crater": 5, "pond": 5, "temple": 13}


class Off:
    """Décale tout en y (permet d'écrire avec des y négatifs = sous le sol)."""

    def __init__(self, t, dy):
        self.t, self.dy = t, dy

    def set(self, x, y, z, name, props=None, nbt=None):
        self.t.set(x, y + self.dy, z, name, props, nbt)

    def fill(self, x1, y1, z1, x2, y2, z2, name, props=None):
        self.t.fill(x1, y1 + self.dy, z1, x2, y2 + self.dy, z2, name, props)

    def chest(self, x, y, z, facing, loot):
        self.t.chest(x, y + self.dy, z, facing, loot)


def dome(t, cx, cy, cz, r, rng, decay=0.0, gap=None):
    """Coque de dôme (verre + nervures de plaque). gap(dx,dy,dz)->True : ouverture."""
    for x in range(cx - r, cx + r + 1):
        for z in range(cz - r, cz + r + 1):
            for y in range(cy, cy + r + 1):
                dx, dy, dz = x - cx, y - cy, z - cz
                d = math.sqrt(dx * dx + dy * dy + dz * dz)
                if r - 1.0 < d <= r + 0.2:
                    if gap and gap(dx, dy, dz):
                        continue
                    if decay and rng.random() < decay:
                        continue
                    rib = dx == 0 or dz == 0 or abs(dx) == abs(dz) or dy == 0
                    t.set(x, y, z, PL if rib else GL)


def carve_dome(t, cx, cy, cz, r):
    """Vide l'intérieur du dôme (uniquement la demi-sphère intérieure)."""
    for x in range(cx - r, cx + r + 1):
        for z in range(cz - r, cz + r + 1):
            for y in range(cy, cy + r + 1):
                d = math.sqrt((x - cx) ** 2 + (y - cy) ** 2 + (z - cz) ** 2)
                if d <= r - 1.0:
                    t.set(x, y, z, AIR)


def disc(t, cx, cz, y, r, block):
    for x in range(cx - r, cx + r + 1):
        for z in range(cz - r, cz + r + 1):
            if (x - cx) ** 2 + (z - cz) ** 2 <= r * r + 1:
                t.set(x, y, z, block)


def skirt(t, cx, cz, y_top, r_top, depth, taper=0.8):
    """Jupe de roche conique sous la structure (jamais de vide dessous)."""
    for k in range(depth):
        r = max(2, int(round(r_top - k * taper)))
        disc(t, cx, cz, y_top - k, r, LROCK)


def ring_top(t, cx, cz, y, r_in, r_out, rng, blocks=(REGO, REGO, REGO, LROCK)):
    for x in range(cx - r_out - 1, cx + r_out + 2):
        for z in range(cz - r_out - 1, cz + r_out + 2):
            d = math.hypot(x - cx, z - cz)
            if r_in < d <= r_out + 0.3:
                t.set(x, y, z, rng.choice(blocks))


def scatter(t, rng, cx, cz, r_lo, r_hi, n, y, blocks, avoid=None):
    """Débris posés SUR la plate-forme (jamais dans le vide)."""
    for _ in range(n * 4):
        if n <= 0:
            break
        a = rng.random() * 6.2832
        r = rng.uniform(r_lo, r_hi)
        x, z = round(cx + r * math.cos(a)), round(cz + r * math.sin(a))
        if avoid and avoid(x - cx, z - cz):
            continue
        t.set(x, y, z, rng.choice(blocks))
        n -= 1


# ----------------------------------------------------------------------------- capsule

def build_capsule():
    rng = random.Random(1)
    F = FOUND["capsule"]
    S = 17
    c = 8
    T = Template(S, F + 9, S)
    t = Off(T, F)
    skirt(t, c, c, -1, 8, F, 1.0)
    disc(t, c, c, 0, 6, FL)
    ring_top(t, c, c, 0, 6, 8, rng)
    gap = lambda dx, dy, dz: dz >= 4 and abs(dx) <= 1 and dy <= 2
    dome(t, c, 1, c, 6, rng, 0.03, gap)
    carve_dome(t, c, 1, c, 6)
    # sas d'entrée (chemin plat au sud)
    for z in range(c + 5, c + 9):
        for x in range(c - 1, c + 2):
            t.set(x, 0, z, FL)
            for y in range(1, 4):
                t.set(x, y, z, AIR)
    t.chest(c - 2, 1, c, "east", "lunaire:chests/capsule")
    t.set(c + 2, 1, c - 2, SOLAR)
    t.set(c + 2, 1, c + 2, "lunaire:oxygen_compressor")
    t.set(c, 6, c, LT)
    scatter(t, rng, c, c, 6.6, 7.6, 7, 1, [PL, PL, GL, "minecraft:iron_block"],
            lambda dx, dz: dz > 2 and abs(dx) <= 2)
    T.write(DATA / "structure" / "capsule.nbt")


# ----------------------------------------------------------------------------- laboratoire

def build_lab():
    rng = random.Random(2)
    F = FOUND["lab"]
    SX, SZ = 25, 32
    c = 12
    T = Template(SX, F + 12, SZ)
    t = Off(T, F)
    # fondations + plate-forme + plancher
    skirt(t, c, c, -1, 12, F, 0.8)
    disc(t, c, c, 0, 9, FL)
    ring_top(t, c, c, 0, 9, 12, rng)
    for r in (3, 6):
        for a in range(0, 360, 4):
            t.set(round(c + r * math.cos(math.radians(a))), 0, round(c + r * math.sin(math.radians(a))), PL)
    # coque + intérieur
    gap = lambda dx, dy, dz: dz >= 8 and abs(dx) <= 1 and dy <= 3
    dome(t, c, 1, c, 9, rng, 0.08, gap)
    carve_dome(t, c, 1, c, 9)
    # sas d'entrée
    for z in range(c + 8, c + 12):
        for x in range(c - 2, c + 3):
            t.set(x, 0, z, FL)
            for y in range(1, 4):
                t.set(x, y, z, AIR)
            t.set(x, 4, z, PL)
        for y in range(1, 4):
            t.set(c - 2, y, z, PL)
            t.set(c + 2, y, z, PL)
    # allée plate vers l'extérieur (plancher + air dégagé pour pouvoir sortir)
    for z in range(c + 12, c + 20):
        for x in range(c - 2, c + 3):
            t.set(x, 0, z, FL if (z + x) % 2 else REGO)
            for y in range(1, 5):
                t.set(x, y, z, AIR)
        for k, w in ((1, 2), (2, 1), (3, 0)):
            for x in range(c - w, c + w + 1):
                t.set(x, -k, z, LROCK)
    # console centrale
    t.fill(c - 1, 1, c - 1, c + 1, 1, c + 1, PL)
    t.fill(c, 2, c, c, 5, c, PL)
    t.set(c, 3, c, LT)
    t.set(c, 6, c, LT)
    # machines et coffres
    t.set(c - 6, 1, c - 3, "lunaire:electrolyzer")
    t.set(c - 6, 1, c - 1, "lunaire:atmosphere_sealer")
    for i in range(4):
        t.set(c + 5, 1, c - 4 + i, SOLAR)
    t.set(c - 4, 1, c - 6, "lunaire:hydrogen_generator")
    t.chest(c - 4, 1, c + 5, "north", "lunaire:chests/lab")
    t.chest(c + 4, 1, c + 5, "north", "lunaire:chests/lab")
    t.chest(c + 6, 1, c - 4, "west", "lunaire:chests/lab_rare")
    for x in range(c - 3, c + 4, 2):
        t.set(x, 1, c - 7, VT)
    for x, z in ((c - 6, c + 3), (c + 6, c + 3), (c - 2, c - 6), (c + 2, c - 6)):
        t.set(x, 1, z, LT)
    # mât d'antenne SUR la plate-forme
    t.fill(c + 8, 1, c - 8, c + 8, 10, c - 8, PL)
    t.set(c + 8, 11, c - 8, LT)
    # débris posés sur la plate-forme
    scatter(t, rng, c, c, 9.6, 11.4, 16, 1, [PL, GL, "minecraft:iron_block"],
            lambda dx, dz: dz > 0 and abs(dx) <= 3 or (dx == 8 and dz == -8))
    T.write(DATA / "structure" / "lab.nbt")


# ----------------------------------------------------------------------------- temple

def build_temple():
    rng = random.Random(3)
    S = 27
    T = Template(S, 17, S)
    t = T
    c = 13
    # pyramide à degrés, pleine (aucun vide : les salles sont creusées dedans)
    for y in range(0, 10):
        half = 13 - y
        t.fill(c - half, y, c - half, c + half, y, c + half, AS if y % 3 else AB)
    # obélisque creux (puits d'accès) qui dépasse du sol
    t.fill(c - 1, 10, c - 1, c + 1, 14, c + 1, AB)
    t.set(c, 15, c, AG)
    t.set(c - 1, 15, c, AB), t.set(c + 1, 15, c, AB)
    for y in range(10, 15):
        t.set(c - 2, y, c, AG if y % 2 else AB)
        t.set(c + 2, y, c, AG if y % 2 else AB)
    # puits : air + échelle (attachée au mur nord), porte au niveau du sol (y=13..14 côté sud)
    for y in range(7, 15):
        t.set(c, y, c, AIR)
    for y in range(8, 15):
        t.set(c, y, c, "minecraft:ladder", {"facing": "south", "waterlogged": "false"})
    t.set(c, 13, c + 1, AIR), t.set(c, 14, c + 1, AIR)
    t.set(c, 13, c + 2, AIR), t.set(c, 13, c + 3, AIR)  # petite marche d'accès
    # salle centrale
    t.fill(c - 5, 1, c - 5, c + 5, 6, c + 5, AIR)
    t.fill(c - 5, 0, c - 5, c + 5, 0, c + 5, AB)
    t.fill(c - 4, 7, c - 4, c + 4, 7, c + 4, AIR)  # voûte
    for dx in range(-5, 6):
        for dz in range(-5, 6):
            if abs(dx) <= 3 and abs(dz) <= 3 and (dx + dz) % 2 == 0:
                t.set(c + dx, 0, c + dz, AG if (abs(dx) == 3 or abs(dz) == 3) else AS)
    for sx in (-4, 4):
        for sz in (-4, 4):
            t.fill(c + sx, 1, c + sz, c + sx, 5, c + sz, AB)
            t.set(c + sx, 3, c + sz, AG)
            t.set(c + sx, 6, c + sz, AG)
    # autel et coffre
    t.fill(c - 1, 1, c - 1, c + 1, 1, c + 1, AS)
    t.set(c, 2, c, AG)
    t.chest(c, 2, c + 1, "south", "lunaire:chests/temple")
    t.set(c, 2, c - 1, AG)
    # galerie ouest + alcôve est avec coffre
    t.fill(0, 1, c - 1, c - 6, 3, c + 1, AIR)
    for x in range(1, c - 6, 3):
        t.set(x, 3, c, AG)
    t.fill(c + 6, 1, c - 1, c + 8, 3, c + 1, AIR)
    t.chest(c + 8, 1, c, "west", "lunaire:chests/temple_minor")
    T.write(DATA / "structure" / "temple.nbt")


# ----------------------------------------------------------------------------- avant-poste

def build_outpost():
    rng = random.Random(4)
    F = FOUND["outpost"]
    S = 17
    c = 8
    T = Template(S, F + 11, S)
    t = Off(T, F)
    skirt(t, c, c, -1, 8, F, 0.9)
    disc(t, c, c, 0, 5, FL)
    ring_top(t, c, c, 0, 5, 8, rng)
    # abri 5x5 (porte au sud)
    t.fill(c - 2, 1, c - 2, c + 2, 4, c + 2, PL)
    t.fill(c - 1, 1, c - 1, c + 1, 3, c + 1, AIR)
    t.fill(c, 1, c + 2, c, 2, c + 2, AIR)
    t.set(c - 2, 2, c, GL)
    t.set(c, 3, c, LT)
    t.chest(c - 1, 1, c - 1, "east", "lunaire:chests/outpost")
    # chemin plat devant la porte
    for z in range(c + 3, c + 9):
        for x in range(c - 1, c + 2):
            t.set(x, 0, z, FL)
            for y in range(1, 4):
                t.set(x, y, z, AIR)
    # champ de panneaux solaires (sur la plate-forme)
    for x in (3, 5, 11, 13):
        for z in (4, 6):
            t.set(x, 1, z, SOLAR)
    # mât radio
    t.fill(c + 5, 1, c + 4, c + 5, 7, c + 4, PL)
    t.set(c + 5, 8, c + 4, LT)
    t.set(c + 4, 1, c + 5, "lunaire:atmosphere_sealer")
    scatter(t, rng, c, c, 5.6, 7.3, 8, 1, [PL, GL, "minecraft:iron_block"],
            lambda dx, dz: dz > 1 and abs(dx) <= 2)
    T.write(DATA / "structure" / "outpost.nbt")


# ----------------------------------------------------------------------------- cratère

def build_crater():
    rng = random.Random(5)
    F = FOUND["crater"]
    S = 29
    c = 14
    R = 13.0
    DEPTH = 3.4
    T = Template(S, F + 6, S)
    t = Off(T, F)
    for x in range(S):
        for z in range(S):
            r = math.hypot(x - c, z - c)
            if r > R + 1.5:
                continue
            if r <= R:
                d = max(0, int(round(DEPTH * (1 - (r / R) ** 2.2) + rng.uniform(-0.3, 0.3))))
            else:
                d = 0
            top = -d  # dernière couche solide du fond
            for y in range(-F, top):
                t.set(x, y, z, LROCK)
            blk = ICE if r < 3.2 else (REGO if rng.random() < 0.85 else LROCK)
            t.set(x, top, z, blk)
            # on dégage seulement au-dessus du fond, jusqu'au niveau du sol
            for y in range(top + 1, 1):
                t.set(x, y, z, AIR)
            # lèvre du cratère (petit bourrelet)
            if R - 1.5 <= r <= R + 1.0:
                t.set(x, 0, z, REGO)
                if rng.random() < 0.45:
                    t.set(x, 1, z, REGO)
    # météorite au fond (le centre est à -DEPTH)
    dc = int(round(DEPTH))
    t.set(c, -dc, c, "lunaire:meteorite_block")
    for dx, dz in ((1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (-1, -1)):
        t.set(c + dx, -dc, c + dz, "lunaire:meteorite_ore")
    T.write(DATA / "structure" / "crater.nbt")


# ----------------------------------------------------------------------------- lac

def build_pond():
    rng = random.Random(6)
    F = FOUND["pond"]
    S = 19
    c = 9
    T = Template(S, F + 5, S)
    t = Off(T, F)

    def reff(a):
        return 4.3 + 1.0 * math.sin(3 * a + 1.0) + 0.6 * math.sin(5 * a + 2.0)

    for x in range(S):
        for z in range(S):
            dx, dz = x - c, z - c
            r = math.hypot(dx, dz)
            a = math.atan2(dz, dx)
            re = reff(a)
            if r > re + 2.2:
                continue
            if r <= re:
                depth = 1 + int(min(2, (re - r) / 1.3))  # 1 à 3 de profondeur
                bed = -1 - depth
                for y in range(-F, bed):
                    t.set(x, y, z, LROCK)
                t.set(x, bed, z, HYDRO if (x + z) % 2 else "minecraft:gravel")
                for y in range(bed + 1, 0):
                    t.set(x, y, z, "minecraft:water", {"level": "0"})
                for y in range(0, 3):
                    t.set(x, y, z, AIR)
            else:
                # rive : gravier / régolithe gelée, au niveau du sol
                for y in range(-F, 0):
                    t.set(x, y, z, LROCK)
                t.set(x, 0, z, rng.choice(["minecraft:gravel", FROZEN, FROZEN, REGO]))
    T.write(DATA / "structure" / "pond.nbt")


def build_all():
    build_capsule()
    build_lab()
    build_temple()
    build_outpost()
    build_crater()
    build_pond()
