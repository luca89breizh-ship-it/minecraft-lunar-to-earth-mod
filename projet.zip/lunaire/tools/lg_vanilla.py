"""Sprites dans le style du jeu de base : outils, armures, œufs, minerais (silhouette + 4 tons + contour foncé)."""
import math
import random
from lg_core import Img, shade

HANDLE = [(88, 62, 34), (132, 96, 52)]


def tones(c):
    c = tuple(c[:3])
    return {"o": shade(c, -85), "d": shade(c, -38), "m": c, "l": shade(c, 32), "h": shade(c, 78)}


def _bres(x0, y0, x1, y1):
    pts = []
    dx, dy = abs(x1 - x0), -abs(y1 - y0)
    sx, sy = (1 if x0 < x1 else -1), (1 if y0 < y1 else -1)
    err = dx + dy
    while True:
        pts.append((x0, y0))
        if x0 == x1 and y0 == y1:
            break
        e2 = 2 * err
        if e2 >= dy:
            err += dy
            x0 += sx
        if e2 <= dx:
            err += dx
            y0 += sy
    return pts


def _thick(points, r):
    out = set()
    for (px, py) in points:
        for y in range(int(py - r - 1), int(py + r + 2)):
            for x in range(int(px - r - 1), int(px + r + 2)):
                if (x - px) ** 2 + (y - py) ** 2 <= r * r + 0.2 and 0 <= x < 16 and 0 <= y < 16:
                    out.add((x, y))
    return out


def _paint_mask(img, mask, c):
    t = tones(c)
    for (x, y) in mask:
        up, left = (x, y - 1) in mask, (x - 1, y) in mask
        down, right = (x, y + 1) in mask, (x + 1, y) in mask
        if not (up and down and left and right):
            img.set(x, y, t["o"])
            continue
        ul = (x - 1, y - 1) in mask
        edge_u = not all(((x, y - 2) in mask, (x, y - 1) in mask))
        edge_l = not all(((x - 2, y) in mask, (x - 1, y) in mask))
        edge_d = not all(((x, y + 2) in mask, (x, y + 1) in mask))
        edge_r = not all(((x + 2, y) in mask, (x + 1, y) in mask))
        if edge_u and edge_l:
            img.set(x, y, t["h"])
        elif edge_u or edge_l:
            img.set(x, y, t["l"])
        elif edge_d or edge_r:
            img.set(x, y, t["d"])
        else:
            img.set(x, y, t["m"])


def _handle(img, pts):
    for (x, y) in pts:
        img.set(x, y, HANDLE[0])
    for (x, y) in pts:
        if (x, y - 1) not in pts and img.get(x, y - 1)[3] == 0:
            pass
    for (x, y) in pts[1::2]:
        img.set(x, y, HANDLE[1])


def tool(kind, color):
    img = Img(16, 16)
    hp = _bres(1, 14, 10, 5)
    if kind == "pickaxe":
        _handle(img, hp)
        pts = []
        for k in range(-13, 14):
            t = k / 2.0
            bx, by = 10.5 + t * 0.707, 5.5 + t * 0.707
            s = 0.075 * t * t
            pts.append((round(bx - s * 0.707), round(by + s * 0.707)))
        _paint_mask(img, _thick(pts, 1.0), color)
    elif kind == "axe":
        _handle(img, hp)
        m = set()
        for y in range(0, 10):
            for x in range(6, 16):
                if ((x - 10.8) / 4.0) ** 2 + ((y - 4.6) / 3.8) ** 2 <= 1 and (x - 10) + (4 - y) * 0.0 >= -4 and not (x < 9 and y > 6):
                    m.add((x, y))
        _paint_mask(img, m, color)
    elif kind == "shovel":
        _handle(img, _bres(1, 14, 9, 6))
        m = set()
        for y in range(0, 9):
            for x in range(7, 16):
                if ((x - 11.6) / 2.5) ** 2 + ((y - 4.4) / 3.7) ** 2 <= 1:
                    m.add((x, y))
        _paint_mask(img, m, color)
    elif kind == "sword":
        blade = _thick(_bres(5, 11, 13, 3), 1.25)
        _paint_mask(img, blade, color)
        guard = _thick(_bres(3, 9, 7, 13), 0.75)
        _paint_mask(img, guard, tuple(int(v * 0.8) for v in color))
        _handle(img, _bres(1, 14, 4, 11))
        img.set(0, 15, HANDLE[0])
    else:  # hoe
        _handle(img, hp)
        m = _thick(_bres(7, 4, 13, 4), 1.1) | _thick(_bres(7, 4, 7, 8), 1.0)
        _paint_mask(img, m, color)
    return img


ARMOR = {
    "helmet": ["................", "................", "................", "....XXXXXXXX....", "...XXXXXXXXXX...", "..XXXXXXXXXXXX..",
               "..XXXXXXXXXXXX..", "..XXXXXXXXXXXX..", "..XXXX....XXXX..", "..XXX......XXX..", "..XXX......XXX..", "................",
               "................", "................", "................", "................"],
    "chestplate": ["................", "..XXXX....XXXX..", ".XXXXXX..XXXXXX.", ".XXXXXXXXXXXXXX.", ".XXXXXXXXXXXXXX.", ".XXXXXXXXXXXXXX.",
                   ".XXXXXXXXXXXXXX.", ".XXXX.XXXX.XXXX.", ".XXXX.XXXX.XXXX.", ".XXXX.XXXX.XXXX.", "......XXXX......",
                   "......XXXX......", "......XXXX......", "......XXXX......", "................", "................"],
    "leggings": ["................", "................", "..XXXXXXXXXXXX..", "..XXXXXXXXXXXX..", "..XXXXXXXXXXXX..", "..XXXXXXXXXXXX..",
                 "..XXXX....XXXX..", "..XXXX....XXXX..", "..XXXX....XXXX..", "..XXXX....XXXX..", "..XXXX....XXXX..", "..XXXX....XXXX..",
                 "..XXXX....XXXX..", "..XXXX....XXXX..", "................", "................"],
    "boots": ["................", "................", "................", "................", "................", "................",
              "................", "................", "...XXXX..XXXX...", "...XXXX..XXXX...", "...XXXX..XXXX...", "..XXXXX..XXXXX..",
              "..XXXXX..XXXXX..", ".XXXXXX..XXXXXX.", "................", "................"],
}


def armor(kind, color, accent=None):
    img = Img(16, 16)
    mask = {(x, y) for y, row in enumerate(ARMOR[kind]) for x, ch in enumerate(row) if ch == "X"}
    _paint_mask(img, mask, color)
    t = tones(accent or color)
    if kind == "helmet":
        for x in range(5, 11):
            img.set(x, 7, t["m"])  # visière
        img.set(5, 7, t["h"])
    elif kind == "chestplate":
        for (x, y) in ((7, 4), (8, 4), (7, 5), (8, 5)):
            img.set(x, y, t["m"])
        img.set(7, 4, t["h"])
    elif kind == "leggings":
        for x in range(4, 12):
            img.set(x, 3, tones(color)["d"])
    return img


# ------------------------------------------------------------------ œufs
HW = [2, 3, 4, 4, 5, 5, 5, 5, 5, 5, 4, 4, 3, 2]


def egg(c, c2):
    c, c2 = tuple(c[:3]), tuple(c2[:3])
    img = Img(16, 16)
    pat = (c[0] * 3 + c[1] + c2[2] * 2) % 8
    rng = random.Random(c[0] * 7 + c2[1])
    spots = [(rng.randint(5, 10), rng.randint(3, 12)) for _ in range(6)]
    for yi, hw in enumerate(HW):
        y = yi + 1
        for x in range(8 - hw, 8 + hw):
            nx, ny = (x + 0.5 - 8) / 5.4, (y + 0.5 - 8) / 7.2
            z = math.sqrt(max(0.0, 1 - nx * nx - ny * ny))
            lit = -0.45 * nx - 0.55 * ny + 0.7 * z
            base = c
            on = False
            if pat == 0:
                on = (x, y) in spots or (x + 1, y) in spots
            elif pat == 1:
                on = (x + y) % 5 == 0
            elif pat == 2:
                on = 7 <= y <= 8
            elif pat == 3:
                on = y <= 5
            elif pat == 4:
                on = (y % 4 == 0 and (x + y // 4) % 3 != 0)
            elif pat == 5:
                on = abs(x - 8 + 0.5) < 1.1 or (y == 10 and 4 < x < 12)
            elif pat == 6:
                on = (x * 3 + y * 5) % 11 < 2
            else:
                on = (abs((x + 0.5 - 8)) + abs(y - 8)) % 5 < 1.2
            if on:
                base = c2
            d = (lit - 0.55) * 120
            col = shade(base, d)
            if x == 8 - hw or x == 8 + hw - 1 or yi == 0 or yi == len(HW) - 1:
                col = shade(c, -95)
            img.set(x, y, col)
    for x in range(4, 12):
        if img.get(x, 15)[3] == 0:
            img.set(x, 15, (0, 0, 0, 70))
    img.set(6, 4, (255, 255, 255, 235))
    img.set(5, 5, (255, 255, 255, 150))
    return img


# ------------------------------------------------------------------ minerais
def ore_tex(color, seed, base=(110, 110, 118)):
    rng = random.Random(seed * 31 + 7)
    img = Img(16, 16)
    # pierre piquetée comme le jeu de base : 3-4 tons mélangés au pixel près
    pal = [shade(base, -22), shade(base, -10), base, shade(base, 10), shade(base, 22)]
    coarse = [[rng.random() for _ in range(5)] for _ in range(5)]
    for y in range(16):
        for x in range(16):
            r = rng.random() * 0.7 + coarse[y // 4 + (1 if x % 4 > 2 else 0) if y // 4 < 4 else 4][x // 4] * 0.3
            img.set(x, y, pal[min(4, int(r * 5))])
    taken = set()
    centers = []
    tries = 0
    while len(centers) < 5 and tries < 80:
        tries += 1
        cx, cy = rng.randint(2, 13), rng.randint(2, 13)
        if all((cx - a) ** 2 + (cy - b) ** 2 > 18 for a, b in centers):
            centers.append((cx, cy))
    t = tones(color)
    for (cx, cy) in centers:
        blob = {(cx, cy), (cx + 1, cy), (cx, cy + 1), (cx + 1, cy + 1)}
        for _ in range(rng.randint(1, 3)):
            bx, by = rng.choice(sorted(blob))
            dx, dy = rng.choice([(1, 0), (-1, 0), (0, 1), (0, -1)])
            blob.add((min(15, max(0, bx + dx)), min(15, max(0, by + dy))))
        for (x, y) in blob:
            if (x, y - 1) not in blob and (x - 1, y) not in blob:
                tone = t["h"]
            elif (x, y + 1) not in blob or (x + 1, y) not in blob:
                tone = t["d"]
            else:
                tone = t["m"] if rng.random() < 0.6 else t["l"]
            img.set(x, y, tone)
        for (x, y) in blob:
            for ox, oy in ((1, 1), (0, 1), (1, 0)):
                p = (x + ox, y + oy)
                if p not in blob and 0 <= p[0] < 16 and 0 <= p[1] < 16:
                    img.set(p[0], p[1], shade(base, -38))
    return img
