"""Sprites dans le style du jeu de base : outils, armures, œufs, minerais (silhouette + 4 tons + contour foncé)."""
import math
import random
from lg_core import Img, shade

HANDLE = [(88, 62, 34), (132, 96, 52)]


def tones(c):
    c = tuple(c[:3])
    return {"o": shade(c, -85), "d": shade(c, -38), "m": c, "l": shade(c, 32), "h": shade(c, 78)}


def _bres(x0, y0, x1, y1):
    pts = []
    dx, dy = abs(x1 - x0), -abs(y1 - y0)
    sx, sy = (1 if x0 < x1 else -1), (1 if y0 < y1 else -1)
    err = dx + dy
    while True:
        pts.append((x0, y0))
        if x0 == x1 and y0 == y1:
            break
        e2 = 2 * err
        if e2 >= dy:
            err += dy
            x0 += sx
        if e2 <= dx:
            err += dx
            y0 += sy
    return pts


def _thick(points, r):
    out = set()
    for (px, py) in points:
        for y in range(int(py - r - 1), int(py + r + 2)):
            for x in range(int(px - r - 1), int(px + r + 2)):
                if (x - px) ** 2 + (y - py) ** 2 <= r * r + 0.2 and 0 <= x < 16 and 0 <= y < 16:
                    out.add((x, y))
    return out


def _paint_mask(img, mask, c):
    t = tones(c)
    for (x, y) in mask:
        up, left = (x, y - 1) in mask, (x - 1, y) in mask
        down, right = (x, y + 1) in mask, (x + 1, y) in mask
        if not (up and down and left and right):
            img.set(x, y, t["o"])
            continue
        ul = (x - 1, y - 1) in mask
        edge_u = not all(((x, y - 2) in mask, (x, y - 1) in mask))
        edge_l = not all(((x - 2, y) in mask, (x - 1, y) in mask))
        edge_d = not all(((x, y + 2) in mask, (x, y + 1) in mask))
        edge_r = not all(((x + 2, y) in mask, (x + 1, y) in mask))
        if edge_u and edge_l:
            img.set(x, y, t["h"])
        elif edge_u or edge_l:
            img.set(x, y, t["l"])
        elif edge_d or edge_r:
            img.set(x, y, t["d"])
        else:
            img.set(x, y, t["m"])



def _poly(points):
    """Pixels dont le centre est dans le polygone."""
    m = set()
    n = len(points)
    for y in range(16):
        for x in range(16):
            px, py = x + 0.5, y + 0.5
            inside = False
            j = n - 1
            for i in range(n):
                xi, yi = points[i]
                xj, yj = points[j]
                if (yi > py) != (yj > py) and px < (xj - xi) * (py - yi) / (yj - yi + 1e-9) + xi:
                    inside = not inside
                j = i
            if inside:
                m.add((x, y))
    return m


def _ell(cx, cy, a, b, ang):
    ca, sa = math.cos(ang), math.sin(ang)
    m = set()
    for y in range(16):
        for x in range(16):
            dx, dy = x + 0.5 - cx, y + 0.5 - cy
            u, v = dx * ca + dy * sa, -dx * sa + dy * ca
            if (u / a) ** 2 + (v / b) ** 2 <= 1:
                m.add((x, y))
    return m


def _bez(p0, p1, p2, n=40):
    out = []
    for i in range(n + 1):
        t = i / n
        x = (1 - t) ** 2 * p0[0] + 2 * t * (1 - t) * p1[0] + t * t * p2[0]
        y = (1 - t) ** 2 * p0[1] + 2 * t * (1 - t) * p1[1] + t * t * p2[1]
        out.append((t, x, y))
    return out


def _stroke(pts_t, r0, r1):
    """Trait épaissi, plus fin aux extrémités (r0) et plus épais au milieu (r1)."""
    m = set()
    for (t, x, y) in pts_t:
        r = r0 + (r1 - r0) * math.sin(math.pi * t)
        for yy in range(16):
            for xx in range(16):
                if (xx + 0.5 - x) ** 2 + (yy + 0.5 - y) ** 2 <= r * r:
                    m.add((xx, yy))
    return m


def _line_t(a, b, n=30):
    return [(i / n, a[0] + (b[0] - a[0]) * i / n, a[1] + (b[1] - a[1]) * i / n) for i in range(n + 1)]


def _handle(img, x0=1, y0=14, x1=10, y1=5):
    pts = _bres(x0, y0, x1, y1)
    for (x, y) in pts:
        img.set(x, y, HANDLE[1])
        img.set(x + 1, y, HANDLE[0]) if img.get(min(15, x + 1), y)[3] == 0 else None
    img.set(x0 - 1, y0 + 1, HANDLE[0])


def tool(kind, color):
    img = Img(16, 16)
    if kind == "pickaxe":
        _handle(img, 1, 14, 10, 5)
        arc = _bez((1.0, 8.0), (8.0, -2.5), (14.2, 10.0))
        _paint_mask(img, _stroke(arc, 1.0, 1.9), color)
    elif kind == "axe":
        _handle(img, 1, 14, 10, 5)
        head = _poly([(3.2, 5.6), (4.6, 2.6), (7.6, 0.9), (11.6, 0.9), (13.4, 2.6), (13.4, 6.0), (11.4, 8.6), (8.2, 8.8),
                      (7.4, 6.6)])
        _paint_mask(img, head, color)
    elif kind == "shovel":
        _handle(img, 1, 14, 10, 5)
        _paint_mask(img, _ell(11.2, 4.4, 4.1, 2.9, -math.pi / 4), color)
    elif kind == "sword":
        blade = _stroke(_line_t((5.5, 10.5), (14.2, 1.8)), 1.3, 2.1) | {(14, 1), (13, 1), (14, 2), (15, 0), (14, 0)}
        _paint_mask(img, blade, color)
        guard = _stroke(_line_t((3.0, 8.2), (8.2, 13.4)), 0.8, 1.1)
        for (x, y) in guard:
            img.set(x, y, HANDLE[1])
        for (x, y) in guard:
            if (x + 1, y) not in guard and (x, y + 1) not in guard:
                img.set(x, y, HANDLE[0])
        for (x, y) in ((3, 12), (2, 13), (1, 14)):
            img.set(x, y, HANDLE[1])
            img.set(x + 1, y, HANDLE[0]) if img.get(x + 1, y)[3] == 0 else None
        img.set(0, 15, HANDLE[0])
        img.set(1, 15, HANDLE[0])
    else:  # hoe
        _handle(img, 1, 14, 10, 5)
        bar = _stroke(_line_t((5.5, 3.2), (13.2, 2.2)), 1.2, 1.6)
        hook = _stroke(_line_t((6.0, 3.0), (6.4, 7.0)), 0.9, 1.2)
        _paint_mask(img, bar | hook, color)
    return img


# ------------------------------------------------------------------ armures (silhouettes du jeu de base)
ARMOR = {
    "helmet": ["................", "................", "................", "....XXXXXXXX....", "...XXXXXXXXXX...", "..XXXXXXXXXXXX..",
               "..XXXXXXXXXXXX..", "..XXXXXXXXXXXX..", "..XXXXXXXXXXXX..", "..XXXX....XXXX..", "..XXXX....XXXX..",
               "..XXXX....XXXX..", "................", "................", "................", "................"],
    "chestplate": ["................", "..XXXX....XXXX..", ".XXXXXX..XXXXXX.", ".XXXXXXXXXXXXXX.", ".XXXXXXXXXXXXXX.",
                   ".XXXXXXXXXXXXXX.", ".XXXXXXXXXXXXXX.", ".XXXXXXXXXXXXXX.", ".XXXXXXXXXXXXXX.", ".XXXXXXXXXXXXXX.",
                   "....XXXXXXXX....", "....XXXXXXXX....", "....XXXXXXXX....", "....XXXXXXXX....", "................", "................"],
    "leggings": ["................", "................", "..XXXXXXXXXXXX..", "..XXXXXXXXXXXX..", "..XXXXXXXXXXXX..", "..XXXXXXXXXXXX..",
                 "..XXXXX..XXXXX..", "..XXXXX..XXXXX..", "..XXXX....XXXX..", "..XXXX....XXXX..", "..XXXX....XXXX..", "..XXXX....XXXX..",
                 "..XXXX....XXXX..", "..XXXX....XXXX..", "................", "................"],
    "boots": ["................", "................", "................", "................", "................", "................",
              "................", "................", "..XXXX....XXXX..", "..XXXX....XXXX..", "..XXXX....XXXX..", "..XXXX....XXXX..",
              ".XXXXX....XXXXX.", ".XXXXXX..XXXXXX.", ".XXXXXX..XXXXXX.", "................"],
}


def armor(kind, color, accent=None):
    img = Img(16, 16)
    mask = {(x, y) for y, row in enumerate(ARMOR[kind]) for x, ch in enumerate(row) if ch == "X"}
    _paint_mask(img, mask, color)
    t = tones(color)
    a = tones(accent or color)
    if kind == "helmet":
        for x in range(5, 11):
            img.set(x, 9, t["o"])  # intérieur sombre sous la visière
        for x in range(4, 12):
            img.set(x, 7, t["d"])  # arête de la visière
        img.set(4, 7, t["l"])
        img.set(7, 5, a["h"]), img.set(8, 5, a["m"])
    elif kind == "chestplate":
        for y in range(4, 10):  # séparation manches / torse
            img.set(4, y, t["d"])
            img.set(11, y, t["d"])
        for x in range(6, 10):
            img.set(x, 2, t["o"])  # col
        for (x, y) in ((7, 6), (8, 6), (7, 7), (8, 7)):
            img.set(x, y, a["m"])
        img.set(7, 6, a["h"])
        img.set(8, 7, a["d"])
        for x in range(4, 12):
            img.set(x, 12, t["d"])  # ceinture
    elif kind == "leggings":
        for x in range(2, 14):
            img.set(x, 3, t["d"])  # ceinture
        img.set(7, 3, a["h"]), img.set(8, 3, a["m"])
        for y in range(7, 14):
            img.set(5, y, t["l"]) if (y % 2) else None
    elif kind == "boots":
        for x in (2, 3, 4, 5, 10, 11, 12, 13):
            img.set(x, 8, t["h"])  # revers
    return img


# ------------------------------------------------------------------ lingots
def ingot(c):
    c = tuple(c[:3])
    t = tones(c)
    img = Img(16, 16)
    for y in range(3, 12):
        left = 9 - (y - 3) * 7 // 8
        right = left + 6
        for x in range(left, right + 1):
            edge = y == 3 or y == 11 or x == left or x == right
            if edge:
                col = t["o"]
            elif y == 4:
                col = t["h"]
            elif y == 5:
                col = t["l"] if x < right - 1 else t["m"]
            elif y in (6, 7):
                col = t["m"]
            elif y == 8:
                col = t["d"]
            else:
                col = shade(c, -52)
            if x >= right - 1 and not edge and y > 4:
                col = shade(c, -45)
            img.set(x, y, col)
    img.set(7, 4, t["h"]), img.set(8, 4, t["h"]), img.set(6, 5, t["h"])
    return img


# ------------------------------------------------------------------ poisson et livre
def fish(c, c2):
    c, c2 = tuple(c[:3]), tuple(c2[:3])
    t, u = tones(c), tones(c2)
    img = Img(16, 16)
    body = _ell(9.0, 8.0, 5.6, 3.3, 0.0)
    tail = _poly([(4.2, 8.0), (0.6, 4.2), (1.6, 8.0), (0.6, 11.8)])
    fin = _poly([(7.0, 5.0), (10.0, 5.0), (9.0, 2.6), (7.5, 2.8)])
    _paint_mask(img, body | tail | fin, c)
    for (x, y) in body:  # ventre clair
        if y >= 9 and (x, y + 1) in body | tail:
            img.set(x, y, u["l"])
    for x in range(6, 14):
        if (x, 9) in body and (x, 8) in body:
            img.set(x, 9, u["m"])
    img.set(12, 7, (255, 255, 255))
    img.set(13, 7, (15, 15, 20))
    for y in range(6, 11):
        img.set(11, y, t["d"])  # branchie
    return img


def book(c):
    c = tuple(c[:3])
    t = tones(c)
    img = Img(16, 16)
    for y in range(2, 14):
        for x in range(3, 13):
            edge = x in (3, 12) or y in (2, 13)
            img.set(x, y, t["o"] if edge else (t["l"] if x == 4 else t["m"]))
    for y in range(3, 13):
        img.set(4, y, t["d"])
    for y in range(4, 12):
        img.set(11, y, (235, 228, 205))  # tranche des pages
    for (x, y) in ((7, 5), (8, 5), (9, 5), (7, 6), (8, 6), (9, 6), (6, 8), (7, 8), (8, 8), (9, 8), (10, 8)):
        img.set(x, y, shade((240, 210, 120), -10) if y < 7 else (240, 220, 140))
    return img


# ------------------------------------------------------------------ œufs
HW = [2, 3, 4, 5, 5, 6, 6, 6, 6, 6, 5, 5, 4, 3]


def egg(c, c2):
    c, c2 = tuple(c[:3]), tuple(c2[:3])
    rng = random.Random(c[0] * 7 + c[1] * 3 + c2[1] + c2[2])
    pat = rng.randint(0, 2)
    spots = set()
    for _ in range(rng.randint(5, 8)):
        sx, sy = rng.randint(4, 11), rng.randint(3, 12)
        spots |= {(sx, sy), (sx + 1, sy)} if pat != 1 else {(sx, sy), (sx, sy + 1)}
        if rng.random() < 0.5:
            spots.add((sx, sy + 1))
    img = Img(16, 16)
    for yi, hw in enumerate(HW):
        y = yi + 1
        for x in range(8 - hw, 8 + hw):
            nx, ny = (x + 0.5 - 8) / 6.2, (y + 0.5 - 8) / 7.4
            z = math.sqrt(max(0.0, 1 - nx * nx - ny * ny))
            lit = -0.5 * nx - 0.5 * ny + 0.7 * z
            on = (x, y) in spots
            if pat == 2:
                on = on or y == 8
            base = c2 if on else c
            col = shade(base, (lit - 0.5) * 90)
            if x == 8 - hw or x == 8 + hw - 1 or yi == 0 or yi == len(HW) - 1:
                col = shade(c, -60)
            img.set(x, y, col)
    img.set(5, 4, (255, 255, 255, 220))
    img.set(4, 5, (255, 255, 255, 140))
    img.set(5, 5, (255, 255, 255, 120))
    return img


# ------------------------------------------------------------------ minerais
def _stone(img, base, rng):
    pal = [shade(base, -20), shade(base, -9), base, shade(base, 9), shade(base, 20)]
    grid = [[rng.choice((0, 1, 2, 2, 3, 4)) for _ in range(8)] for _ in range(8)]
    for y in range(16):
        for x in range(16):
            k = grid[y // 2][x // 2]
            if rng.random() < 0.3:
                k = max(0, min(4, k + rng.choice((-1, 1))))
            img.set(x, y, pal[k])


def ore_tex(color, seed, base=(110, 110, 118)):
    rng = random.Random(seed * 31 + 7)
    img = Img(16, 16)
    _stone(img, base, rng)
    t = tones(color)
    centers = []
    tries = 0
    while len(centers) < 6 and tries < 200:
        tries += 1
        cx, cy = rng.randint(1, 13), rng.randint(1, 13)
        if all((cx - a) ** 2 + (cy - b) ** 2 > 12 for a, b in centers):
            centers.append((cx, cy))
    for (cx, cy) in centers:
        blob = {(cx, cy), (cx + 1, cy), (cx, cy + 1), (cx + 1, cy + 1)}
        for _ in range(rng.randint(2, 4)):
            bx, by = rng.choice(sorted(blob))
            dx, dy = rng.choice([(1, 0), (-1, 0), (0, 1), (0, -1)])
            blob.add((min(15, max(0, bx + dx)), min(15, max(0, by + dy))))
        for (x, y) in blob:
            up, left = (x, y - 1) in blob, (x - 1, y) in blob
            down, right = (x, y + 1) in blob, (x + 1, y) in blob
            if not up and not left:
                tone = t["h"]
            elif not down or not right:
                tone = t["d"] if rng.random() < 0.8 else t["o"]
            else:
                tone = t["m"] if rng.random() < 0.65 else t["l"]
            img.set(x, y, tone)
    return img


# ------------------------------------------------------------------ œufs « visage » (comme les œufs de la version 26.x)
def face_egg(face, fw, fh, W=12, H=14, ears=None):
    """Œuf dont la coquille porte le visage du mob (oreilles / cornes qui dépassent, contour sombre)."""
    img = Img(16, 16)
    top = 15 - H
    mask = set()
    for i in range(H):
        t = (i + 0.5) / H
        d = 0.6
        k = (t - d) / (d if t < d else 1 - d)
        hw = (W / 2) * math.sqrt(max(0.0, 1 - k * k))
        for x in range(16):
            if abs(x + 0.5 - 8) <= hw:
                mask.add((x, top + i))
    # couleur moyenne du visage (repli pour les pixels transparents)
    acc, n = [0, 0, 0], 0
    for row in face:
        for px in row:
            if px[3] > 128:
                acc = [acc[0] + px[0], acc[1] + px[1], acc[2] + px[2]]
                n += 1
    avg = tuple(a // max(1, n) for a in acc)
    x0 = 8 - W / 2
    for (x, y) in mask:
        u = (x + 0.5 - x0) / W
        v = (y - top + 0.5) / H
        fx = min(fw - 1, max(0, int(u * fw)))
        fy = min(fh - 1, max(0, int(v * fh)))
        px = face[fy][fx]
        col = tuple(px[:3]) if px[3] > 128 else avg
        img.set(x, y, col + (255,))
    # oreilles / cornes qui dépassent de l'œuf
    extra = set()
    if ears == "rabbit":
        for (ex, h) in ((4, 4), (5, 4), (10, 4), (11, 4)):
            for yy in range(top - 1, top + h - 1):
                extra.add((ex, yy))
    elif ears in ("cat", "dog"):
        for ex in (3, 4, 11, 12):
            for yy in (top, top + 1):
                extra.add((ex, yy))
    elif ears == "goat":
        for ex in (4, 11):
            for yy in (top - 1, top, top + 1):
                extra.add((ex, yy))
    for (x, y) in extra:
        if (x, y) in mask or not (0 <= y < 16):
            continue
        base = (232, 226, 205) if ears == "goat" else shade(avg, -10)
        img.set(x, y, tuple(base[:3]) + (255,))
        mask.add((x, y))
    # contour sombre
    out = []
    for (x, y) in mask:
        if any((x + dx, y + dy) not in mask for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1))):
            out.append((x, y))
    for (x, y) in out:
        c = img.get(x, y)
        img.set(x, y, shade(tuple(c[:3]), -85))
    # petit reflet en haut à gauche
    for (x, y) in ((5, top + 3), (4, top + 4)):
        if (x, y) in mask and (x, y) not in out:
            c = img.get(x, y)
            img.set(x, y, shade(tuple(c[:3]), 38))
    return img
